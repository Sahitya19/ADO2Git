---
description: Turn the Azure Artifacts inventory into a migration plan with a target for every feed and package
mode: agent
---

Write the Azure Artifacts migration plan. Follow `.github/copilot-instructions.md`.

## Inputs
- The newest `docs/artifacts/inventory/*-inventory.md` and the raw CSVs next to it. If there is no inventory, stop and tell me to run `/artifacts-inventory`.
- `docs/artifacts/migration-options.md` for targets, version cut policy, consumer changes and bridge rules.
- `docs/migration/baseline-plan.md` if it exists, for phase dates (Foundation, Pilot, Waves, Cutover, Decommission).

## Work out
1. **Target per package**: apply the recommendation table. For each package give target, option letter (A to G), new name or URL (for npm the `@adhplatform/` name), and versions to move vs archive.
2. **Exceptions**: anything that does not fit (Maven, PyPI, large binaries, packages with no consumers, names that clash after npm scoping). For each, give two options and a recommendation.
3. **Consumer changes per repo**: from consumers.csv, the files that change and the change type (nuget.config source, .npmrc scope, ADO auth task to Actions setup step, Universal download to release/oras/git ref, Terraform source to `ADHPlatform-Modules` tag).
4. **Order**: packages with no internal dependencies first. A package moves before or with its first consumer's wave, never after. Use the bridge (dual publish) for any package with consumers in more than one wave.
5. **Fit to phases**: Foundation sets up the targets (package permissions, PAT policy, module repos, release-please, the dual publish workflow). Pilot moves the packages the pilot repos need. Each wave moves what its repos need. Decommission removes the bridge and archives the rest.
6. **Effort**: rough size per package (S under 1 hour, M half a day, L more), with the reason.

## Write
Create `docs/artifacts/migration-plan.md` with these sections:
1. **Summary**: 5 bullets a manager can read in 30 seconds, including the recommendation (hybrid or third-party) and the decisions needed.
2. **Targets by type**: table of type, package count, target, option.
3. **Package plan**: table of feed, package, type, category, target, new name/URL, versions to move, versions to archive, first consumer wave, effort.
4. **Consumer changes**: table per repo.
5. **Timeline**: Mermaid `gantt`, `dateFormat YYYY-MM-DD`, using baseline phase dates if present.
6. **Bridge**: which packages are dual-published and when each bridge ends.
7. **Risks**: at most 6, each with impact and mitigation (npm rename, classic PAT for local dev, Maven/PyPI gap, lost history, retention, ownership).
8. **Decisions needed**: from the options file plus anything new.
9. **Data notes**.

Then show me the summary and the decisions in chat.
