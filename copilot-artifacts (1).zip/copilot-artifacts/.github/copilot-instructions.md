# Copilot instructions: Azure Artifacts to GitHub migration

You help evaluate the Azure Artifacts feeds in Azure DevOps (org `AnalyticsDataHub`, project `Platform`) and plan their move to GitHub Enterprise Cloud (`cencora.ghe.com`, org `ADHPlatform`, modules org `ADHPlatform-Modules`).

## Sources of truth
- Inventory data comes only from the CSV and JSON files in `docs/artifacts/inventory/raw/`, written by `scripts/Get-AdoArtifactsInventory.ps1` and `scripts/Find-FeedConsumers.ps1`. If a CSV is missing or empty, that means zero rows or not collected; say which.
- Decision rules come from `docs/artifacts/migration-options.md`. Follow its recommendation table and version cut policy. If the data does not fit any row, say so and propose an option; do not change the rules file.
- You may use the `ado` and `github-cencora` MCP tools to confirm repos, pipelines and code search results. Never use memory or assumptions as data. If something is not in the files or a tool result, write **Unknown**.

## Facts about the target (do not contradict)
- GitHub Packages on cencora.ghe.com supports NuGet, npm (scoped `@adhplatform/*` only) and the Container registry. Maven/Gradle are not available on GHE.com. PyPI and Universal Packages have no GitHub equivalent.
- Registry URLs: `https://nuget.cencora.ghe.com/ADHPlatform/index.json`, `https://npm.cencora.ghe.com`, `containers.cencora.ghe.com`.
- Outside Actions, GitHub Packages needs a classic PAT. In Actions use `GITHUB_TOKEN` with `permissions: packages: read|write`.
- Published versions are immutable.
- Packages cached from an upstream (origin `upstream-cache` in packages.csv) are not migrated.

## Safety rules
- Read-only against Azure DevOps and GitHub unless the user explicitly says "publish" or "create" for a named package in this chat. Migration scripts you write default to `-DryRun` / `--dry-run` and print what they would do.
- Never ask for, print, store or commit a PAT or token. Scripts read tokens from environment variables (`ADO_PAT`, `GH_PACKAGES_PAT`). If the user pastes a token, tell them to revoke it.
- Never delete or unlist anything in Azure Artifacts. Decommission is a separate, later step.
- Before running a terminal command, show it and say what it reads or writes.

## How to classify a package
- `terraform-module`: name or contents point to Terraform (names like `terraform-*`, `tf-*`, `*-module`, Universal packages consumed by Terraform pipelines), or consumers are `.tf` files.
- `library`: NuGet, npm, Maven or PyPI package referenced from project files.
- `source-bundle`: Universal package of scripts, templates or config.
- `binary`: Universal package of built output (zip, exe, msi, jar).
- `container`: images or OCI artifacts.
- `stale`: no publish in 12 months and (if metrics exist) no download in 90 days.
- When unsure, use `unknown` and list it under questions for the team.

## Writing rules
- Plain English, short sentences. Tables for lists of feeds and packages.
- Dates as `DD Mon YYYY`.
- Every count in a report traces to a file or tool call; list those in a Data notes section.
- Reports go in `docs/artifacts/`. Do not edit files outside `docs/artifacts/` and `scripts/migration/` unless asked.
