# Azure Artifacts inventory: <YYYY-MM-DD>

> Copilot fills this from `docs/artifacts/inventory/raw/*.csv`. Every number must come from those files. Unknown means not collected or the call failed.

- Data pulled (UTC): <from summary.json>
- Organization / projects scanned: <org> / <n>
- Collected: feeds yes · metrics <yes/no> · provenance <yes/no> · build artifacts <yes/no> · consumer scan <yes/no, n repos>
- Failed calls: <n> (see Data notes)

## 1. Headline
<One or two sentences: how many feeds, how many internal packages by type, how much is upstream cache, and the biggest migration issue.>

## 2. Feeds

| Feed | Scope / project | Protocols | Internal pkgs | Upstream-cache pkgs | Versions | Upstreams | Retention | Readers / publishers |
|------|-----------------|-----------|---------------|---------------------|----------|-----------|-----------|----------------------|

## 3. Internal packages by type

| Protocol | Packages | Versions | Published in last 12 months | Downloaded in last 90 days | Recommended target |
|----------|----------|----------|-----------------------------|----------------------------|--------------------|

## 4. Package detail

| Feed | Package | Type | Versions | Latest | Last published | Last downloaded | Consumers (repos) | Category | Target | Versions to move |
|------|---------|------|----------|--------|----------------|-----------------|-------------------|----------|--------|------------------|

Category is one of: `library`, `terraform-module`, `source-bundle`, `binary`, `container`, `upstream-cache`, `stale` (no publish and no download for 12 months), `unknown`.

## 5. Consumers

| Repo | Feeds used | Publishes | Consumes | Files to change |
|------|-----------|-----------|----------|-----------------|

## 6. Upstream sources

| Feed | Upstream | Type | Location | Needed after migration? |
|------|----------|------|----------|-------------------------|

## 7. Pipeline build artifacts (if collected)

| Project | Pipeline | Builds sampled | Artifact names | Typical size | Kept forever / by release | Recommendation |
|---------|----------|----------------|----------------|--------------|---------------------------|----------------|

## 8. Gaps and questions for the team
- <for example: package X has no consumers found in scanned repos; confirm it is unused before archiving>

## 9. Data notes
- <failed calls from errors.csv, missing CSVs, estimates>
