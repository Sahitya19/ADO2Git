<#
.SYNOPSIS
  Read-only inventory of Azure Artifacts feeds, packages and versions (and optionally pipeline build artifacts).

.DESCRIPTION
  Calls only GET (and one read-only POST for download metrics) on the Azure DevOps REST API.
  Nothing is created, changed or deleted. Writes CSV files that Copilot reads to build the inventory report.

  Auth, pick one:
    - $env:ADO_PAT set to a PAT with scopes: Packaging (Read), Build (Read), Project and Team (Read)
    - -UseAzCli : uses your `az login` session (Entra token for Azure DevOps), no PAT needed

  Works on Windows PowerShell 5.1 and PowerShell 7.

.EXAMPLE
  $env:ADO_PAT = Read-Host -AsSecureString | ConvertFrom-SecureString -AsPlainText   # PowerShell 7
  ./scripts/Get-AdoArtifactsInventory.ps1 -Organization AnalyticsDataHub

.EXAMPLE
  az login
  ./scripts/Get-AdoArtifactsInventory.ps1 -Organization AnalyticsDataHub -UseAzCli -IncludeMetrics -IncludeBuildArtifacts -Project Platform
#>
[CmdletBinding()]
param(
  [Parameter(Mandatory = $true)] [string]$Organization,
  # Projects to scan for project-scoped feeds and build artifacts. Empty = all projects in the org.
  [string[]]$Project = @(),
  [string]$OutDir = "docs/artifacts/inventory/raw",
  # Adds download counts and last-downloaded date per package (one extra call per feed).
  [switch]$IncludeMetrics,
  # Adds provenance (which pipeline run and commit published each version). One call per version: slow on big feeds.
  [switch]$IncludeProvenance,
  # Adds pipeline build artifacts from the most recent builds.
  [switch]$IncludeBuildArtifacts,
  [int]$BuildsPerProject = 100,
  [switch]$UseAzCli
)

$ErrorActionPreference = 'Stop'
$api = 'api-version=7.1'
$apiPreview = 'api-version=7.1-preview.1'

# ---------- auth ----------
if ($UseAzCli) {
  # 499b84ac-1321-427f-aa17-267ca6975798 is the fixed Entra resource id of Azure DevOps
  $token = az account get-access-token --resource 499b84ac-1321-427f-aa17-267ca6975798 --query accessToken -o tsv
  if (-not $token) { throw "az account get-access-token failed. Run 'az login' first." }
  $headers = @{ Authorization = "Bearer $token" }
} elseif ($env:ADO_PAT) {
  $b64 = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$($env:ADO_PAT)"))
  $headers = @{ Authorization = "Basic $b64" }
} else {
  throw "Set `$env:ADO_PAT or pass -UseAzCli. Never paste the PAT into Copilot Chat."
}

$errors = New-Object System.Collections.Generic.List[object]

function Invoke-Ado {
  param([string]$Uri, [string]$Method = 'GET', $Body = $null)
  for ($attempt = 1; $attempt -le 5; $attempt++) {
    try {
      if ($Body) {
        return Invoke-RestMethod -Uri $Uri -Method $Method -Headers $headers -ContentType 'application/json' -Body ($Body | ConvertTo-Json -Depth 5)
      }
      return Invoke-RestMethod -Uri $Uri -Method $Method -Headers $headers
    } catch {
      $code = $null
      if ($_.Exception.Response) { $code = [int]$_.Exception.Response.StatusCode }
      if (($code -eq 429 -or $code -ge 500) -and $attempt -lt 5) { Start-Sleep -Seconds ([math]::Pow(2, $attempt)); continue }
      $errors.Add([pscustomobject]@{ uri = $Uri; status = $code; message = $_.Exception.Message })
      Write-Warning "Call failed ($code): $Uri"
      return $null
    }
  }
}

function Get-Paged {
  # Azure Artifacts packages use $top/$skip paging
  param([string]$BaseUri, [int]$PageSize = 1000)
  $all = @(); $skip = 0
  while ($true) {
    $sep = if ($BaseUri.Contains('?')) { '&' } else { '?' }
    $r = Invoke-Ado "$BaseUri$sep`$top=$PageSize&`$skip=$skip"
    if (-not $r -or -not $r.value) { break }
    $all += $r.value
    if ($r.value.Count -lt $PageSize) { break }
    $skip += $PageSize
  }
  return $all
}

New-Item -ItemType Directory -Force -Path $OutDir | Out-Null
$org = $Organization
$feedsRoot = "https://feeds.dev.azure.com/$org"

# ---------- projects ----------
$projects = @()
$pr = Invoke-Ado "https://dev.azure.com/$org/_apis/projects?`$top=500&$api"
if ($pr) { $projects = $pr.value }
if ($Project.Count -gt 0) { $projects = $projects | Where-Object { $Project -contains $_.name } }
Write-Host "Projects in scope: $(@($projects).Count)"

# ---------- feeds (org-scoped + project-scoped) ----------
$feedMap = @{}
$orgFeeds = Invoke-Ado "$feedsRoot/_apis/packaging/feeds?$api"
if ($orgFeeds) { foreach ($f in $orgFeeds.value) { $feedMap[$f.id] = $f } }
foreach ($p in $projects) {
  $pf = Invoke-Ado "$feedsRoot/$($p.id)/_apis/packaging/feeds?$api"
  if ($pf) { foreach ($f in $pf.value) { $feedMap[$f.id] = $f } }
}
$feeds = @($feedMap.Values)
Write-Host "Feeds found: $($feeds.Count)"

$feedRows = @(); $upRows = @(); $viewRows = @(); $permRows = @(); $pkgRows = @(); $verRows = @()

foreach ($f in $feeds) {
  $scope = 'organization'; $projName = ''; $base = "$feedsRoot/_apis/packaging/Feeds/$($f.id)"
  if ($f.project) { $scope = 'project'; $projName = $f.project.name; $base = "$feedsRoot/$($f.project.id)/_apis/packaging/Feeds/$($f.id)" }
  Write-Host "Feed: $($f.name) ($scope $projName)"

  # upstream sources
  $upById = @{}
  foreach ($u in @($f.upstreamSources)) {
    if (-not $u) { continue }
    $upById[$u.id] = $u.name
    $upRows += [pscustomobject]@{ feed = $f.name; upstream = $u.name; protocol = $u.protocol; type = $u.upstreamSourceType; location = $u.location; status = $u.status }
  }

  # views (@Local, @Prerelease, @Release ...)
  $v = Invoke-Ado "$base/views?$api"
  if ($v) { foreach ($x in $v.value) { $viewRows += [pscustomobject]@{ feed = $f.name; view = $x.name; visibility = $x.visibility; type = $x.type } } }

  # permissions (who can read/publish)
  $pm = Invoke-Ado "$base/permissions?includeIds=false&$api"
  if ($pm) { foreach ($x in $pm.value) { $permRows += [pscustomobject]@{ feed = $f.name; role = $x.role; identity = $x.displayName } } }

  # retention
  $ret = Invoke-Ado "$base/retentionpolicies?$api"

  # packages with all versions
  $pkgs = Get-Paged "$base/packages?includeAllVersions=true&includeDeleted=false&$api"

  # optional download metrics
  $metrics = @{}
  if ($IncludeMetrics -and $pkgs.Count -gt 0) {
    $ids = @($pkgs | ForEach-Object { $_.id })
    for ($i = 0; $i -lt $ids.Count; $i += 100) {
      $chunk = $ids[$i..([math]::Min($i + 99, $ids.Count - 1))]
      $m = Invoke-Ado "$base/packagemetricsbatch?$apiPreview" 'POST' @{ packageIds = $chunk }
      if ($m) { foreach ($x in $m.value) { $metrics[$x.packageId] = $x } }
    }
  }

  $ownCount = 0; $cachedCount = 0
  foreach ($p in $pkgs) {
    $vers = @($p.versions)
    $own = @($vers | Where-Object { -not $_.directUpstreamSourceId })
    $fromUp = $vers.Count - $own.Count
    $isCached = ($own.Count -eq 0 -and $vers.Count -gt 0)
    if ($isCached) { $cachedCount++ } else { $ownCount++ }
    $dates = @($vers | Where-Object { $_.publishDate } | ForEach-Object { [datetime]$_.publishDate } | Sort-Object)
    $latest = $vers | Where-Object { $_.isLatest } | Select-Object -First 1
    $met = $metrics[$p.id]
    $pkgRows += [pscustomobject]@{
      feed = $f.name; feedScope = $scope; project = $projName
      protocol = $p.protocolType; package = $p.name
      versions = $vers.Count; publishedHere = $own.Count; cachedFromUpstream = $fromUp
      origin = $(if ($isCached) { 'upstream-cache' } else { 'internal' })
      latestVersion = $(if ($latest) { $latest.version } else { '' })
      firstPublished = $(if ($dates.Count) { $dates[0].ToString('yyyy-MM-dd') } else { '' })
      lastPublished = $(if ($dates.Count) { $dates[-1].ToString('yyyy-MM-dd') } else { '' })
      downloads = $(if ($met) { $met.downloadCount } else { '' })
      uniqueUsers = $(if ($met) { $met.downloadUniqueUsers } else { '' })
      lastDownloaded = $(if ($met -and $met.lastDownloaded) { ([datetime]$met.lastDownloaded).ToString('yyyy-MM-dd') } else { '' })
    }
    foreach ($ver in $vers) {
      $prov = ''
      if ($IncludeProvenance -and -not $ver.directUpstreamSourceId) {
        $pv = Invoke-Ado "$base/Packages/$($p.id)/Versions/$($ver.id)/provenance?$apiPreview"
        if ($pv -and $pv.provenance) { $prov = ($pv.provenance.data | ConvertTo-Json -Compress -Depth 3) }
      }
      $verRows += [pscustomobject]@{
        feed = $f.name; protocol = $p.protocolType; package = $p.name; version = $ver.version
        isLatest = $ver.isLatest; isListed = $ver.isListed
        publishDate = $(if ($ver.publishDate) { ([datetime]$ver.publishDate).ToString('yyyy-MM-dd') } else { '' })
        views = (@($ver.views) | ForEach-Object { $_.name }) -join ';'
        upstream = $(if ($ver.directUpstreamSourceId) { $upById[$ver.directUpstreamSourceId] } else { '' })
        provenance = $prov
      }
    }
  }

  $protocols = (@($pkgs | ForEach-Object { $_.protocolType }) | Sort-Object -Unique) -join ';'
  $feedRows += [pscustomobject]@{
    feed = $f.name; id = $f.id; scope = $scope; project = $projName
    protocols = $protocols; packagesInternal = $ownCount; packagesUpstreamCache = $cachedCount
    versionsTotal = @($pkgs | ForEach-Object { @($_.versions).Count } | Measure-Object -Sum).Sum
    upstreamEnabled = $f.upstreamEnabled; upstreamSources = @($f.upstreamSources).Count
    retentionCountLimit = $(if ($ret) { $ret.countLimit } else { '' })
    retentionDaysRecentlyDownloaded = $(if ($ret) { $ret.daysToKeepRecentlyDownloadedPackages } else { '' })
    badgesEnabled = $f.badgesEnabled; hideDeletedVersions = $f.hideDeletedPackageVersions
  }
}

# ---------- pipeline build artifacts (optional) ----------
$artRows = @()
if ($IncludeBuildArtifacts) {
  foreach ($p in $projects) {
    $builds = Invoke-Ado "https://dev.azure.com/$org/$($p.id)/_apis/build/builds?`$top=$BuildsPerProject&queryOrder=finishTimeDescending&$api"
    if (-not $builds) { continue }
    foreach ($b in $builds.value) {
      $a = Invoke-Ado "https://dev.azure.com/$org/$($p.id)/_apis/build/builds/$($b.id)/artifacts?$api"
      if (-not $a) { continue }
      foreach ($x in $a.value) {
        $artRows += [pscustomobject]@{
          project = $p.name; definition = $b.definition.name; buildId = $b.id; buildNumber = $b.buildNumber
          finishTime = $(if ($b.finishTime) { ([datetime]$b.finishTime).ToString('yyyy-MM-dd') } else { '' })
          sourceBranch = $b.sourceBranch; retainedByRelease = $b.retainedByRelease; keepForever = $b.keepForever
          artifact = $x.name; type = $x.resource.type
          sizeBytes = $(if ($x.resource.properties -and $x.resource.properties.artifactsize) { $x.resource.properties.artifactsize } else { '' })
        }
      }
    }
  }
}

# ---------- write ----------
$feedRows | Export-Csv -NoTypeInformation -Encoding UTF8 (Join-Path $OutDir 'feeds.csv')
$upRows   | Export-Csv -NoTypeInformation -Encoding UTF8 (Join-Path $OutDir 'upstreams.csv')
$viewRows | Export-Csv -NoTypeInformation -Encoding UTF8 (Join-Path $OutDir 'views.csv')
$permRows | Export-Csv -NoTypeInformation -Encoding UTF8 (Join-Path $OutDir 'permissions.csv')
$pkgRows  | Export-Csv -NoTypeInformation -Encoding UTF8 (Join-Path $OutDir 'packages.csv')
$verRows  | Export-Csv -NoTypeInformation -Encoding UTF8 (Join-Path $OutDir 'versions.csv')
if ($IncludeBuildArtifacts) { $artRows | Export-Csv -NoTypeInformation -Encoding UTF8 (Join-Path $OutDir 'build-artifacts.csv') }
$errors   | Export-Csv -NoTypeInformation -Encoding UTF8 (Join-Path $OutDir 'errors.csv')

$summary = [pscustomobject]@{
  organization = $org; pulledAtUtc = (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ')
  projectsScanned = @($projects).Count; feeds = $feeds.Count
  packagesInternal = @($pkgRows | Where-Object { $_.origin -eq 'internal' }).Count
  packagesUpstreamCache = @($pkgRows | Where-Object { $_.origin -eq 'upstream-cache' }).Count
  versions = $verRows.Count
  byProtocol = @($pkgRows | Where-Object { $_.origin -eq 'internal' } | Group-Object protocol | ForEach-Object { [pscustomobject]@{ protocol = $_.Name; packages = $_.Count } })
  buildArtifacts = $(if ($IncludeBuildArtifacts) { $artRows.Count } else { 'not collected' })
  failedCalls = $errors.Count
}
$summary | ConvertTo-Json -Depth 4 | Set-Content -Encoding UTF8 (Join-Path $OutDir 'summary.json')

Write-Host ""
Write-Host "Done. Files in $OutDir"
$summary | ConvertTo-Json -Depth 4
if ($errors.Count) { Write-Warning "$($errors.Count) calls failed. See errors.csv (usually a missing PAT scope or no access to a project feed)." }
