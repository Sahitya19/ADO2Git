<#
.SYNOPSIS
  Finds every place in local clones of your ADO repos that publishes to or consumes Azure Artifacts
  feeds or pipeline artifacts. Read-only.

.DESCRIPTION
  Clone the ADO repos into one folder first (for example C:\src\ado). The script scans pipeline YAML,
  package config files, project files and Terraform, and writes consumers.csv for Copilot to read.

.EXAMPLE
  ./scripts/Find-FeedConsumers.ps1 -RootPath C:\src\ado
#>
[CmdletBinding()]
param(
  [Parameter(Mandatory = $true)] [string]$RootPath,
  [string]$OutFile = "docs/artifacts/inventory/raw/consumers.csv"
)

$ErrorActionPreference = 'Stop'

# kind = what the match means for migration
$patterns = @(
  @{ kind = 'feed-url';            regex = 'pkgs\.dev\.azure\.com|pkgs\.visualstudio\.com|\.pkgs\.visualstudio\.com' }
  @{ kind = 'feed-url';            regex = 'feeds\.dev\.azure\.com' }
  @{ kind = 'auth-task';           regex = '(NuGetAuthenticate|npmAuthenticate|PipAuthenticate|TwineAuthenticate|MavenAuthenticate)@\d' }
  @{ kind = 'publish-or-restore';  regex = '(NuGetCommand|DotNetCoreCLI|Npm|Maven|Gradle)@\d' }
  @{ kind = 'feed-input';          regex = '(vstsFeed|feedsToUse|publishVstsFeed|feedRestore|feedPublish|vstsFeedPublish|internalFeed)\s*:' }
  @{ kind = 'universal-package';   regex = 'UniversalPackages@\d|az\s+artifacts\s+universal' }
  @{ kind = 'download-package';    regex = 'DownloadPackage@\d' }
  @{ kind = 'pipeline-artifact';   regex = '(PublishPipelineArtifact|DownloadPipelineArtifact|PublishBuildArtifacts|DownloadBuildArtifacts|CopyFilesOverSSH)@\d|^\s*-\s*(publish|download)\s*:' }
  @{ kind = 'release-artifact';    regex = '\$\(System\.ArtifactsDirectory\)|\$\(System\.DefaultWorkingDirectory\)/_' }
  @{ kind = 'terraform-ado-source'; regex = 'source\s*=\s*"git::https://(dev\.azure\.com|[^/]+\.visualstudio\.com)' }
)

$includeExt = @('.yml', '.yaml', '.config', '.npmrc', '.yarnrc', '.yarnrc.yml', '.csproj', '.fsproj', '.vbproj', '.props', '.targets',
                '.nuspec', '.json', '.xml', '.gradle', '.kts', '.toml', '.cfg', '.ini', '.txt', '.tf', '.ps1', '.sh', '.psm1', '.dockerfile')
$includeNames = @('nuget.config', 'NuGet.Config', '.npmrc', '.yarnrc', 'pip.conf', 'pip.ini', 'pom.xml', 'settings.xml', 'Dockerfile',
                  'requirements.txt', 'setup.cfg', 'pyproject.toml', 'build.gradle', 'settings.gradle')
$skipDirs = '\\(\.git|node_modules|bin|obj|\.terraform|dist)\\|/(\.git|node_modules|bin|obj|\.terraform|dist)/'

$root = (Resolve-Path $RootPath).Path
$rows = @()
$files = Get-ChildItem -Path $root -Recurse -File -Force -ErrorAction SilentlyContinue |
  Where-Object { $_.FullName -notmatch $skipDirs } |
  Where-Object { ($includeExt -contains $_.Extension.ToLower()) -or ($includeNames -contains $_.Name) }

Write-Host "Scanning $(@($files).Count) files under $root"
foreach ($file in $files) {
  $rel = $file.FullName.Substring($root.Length).TrimStart('\', '/')
  $repo = ($rel -split '[\\/]')[0]
  foreach ($p in $patterns) {
    $hits = Select-String -Path $file.FullName -Pattern $p.regex -AllMatches -ErrorAction SilentlyContinue
    foreach ($h in $hits) {
      $line = $h.Line.Trim()
      if ($line.Length -gt 240) { $line = $line.Substring(0, 240) }
      # strip anything that looks like a secret
      $line = $line -replace '(_authToken|_password|password|ClearTextPassword|apikey|api-key)\s*[=:]\s*\S+', '$1=<redacted>'
      $rows += [pscustomobject]@{ repo = $repo; file = $rel; line = $h.LineNumber; kind = $p.kind; text = $line }
    }
  }
}

# best-effort: pull the feed name out of feed URLs and task inputs
foreach ($r in $rows) {
  $feed = ''
  if ($r.text -match '_packaging/([^/@"\s]+)') { $feed = $Matches[1] }
  elseif ($r.text -match '(vstsFeed|publishVstsFeed|feedPublish|vstsFeedPublish|feedRestore|internalFeed)\s*:\s*[''"]?([^''"\s]+)') { $feed = $Matches[2] }
  $r | Add-Member -NotePropertyName feed -NotePropertyValue $feed
}

$dir = Split-Path $OutFile -Parent
if ($dir) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
$rows | Sort-Object repo, file, line | Export-Csv -NoTypeInformation -Encoding UTF8 $OutFile
Write-Host "Found $($rows.Count) references in $(@($rows | Select-Object -ExpandProperty repo -Unique).Count) repos. Written to $OutFile"
