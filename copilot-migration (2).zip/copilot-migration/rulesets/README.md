# Rulesets

- `main-protection.json`: org ruleset for the default branch of every repo. Starts in `evaluate` mode (logs what it would block, blocks nothing) so you can check it during the pilot; change to `active` before Wave 1.
  `gh api -X POST /orgs/ADHPlatform/rulesets --input rulesets/main-protection.json --hostname cencora.ghe.com`
- `module-tags.json`: in the modules org, version tags `v*` can't be deleted or moved once created.
  `gh api -X POST /orgs/ADHPlatform-Modules/rulesets --input rulesets/module-tags.json --hostname cencora.ghe.com`

Required status checks differ per repo, so add them per repo once the workflow has run at least once (the check names must exist). Org rulesets need an org owner; a repo admin can create the same rules at repo level with `/repos/ADHPlatform/<repo>/rulesets` (drop the `repository_name` condition).
