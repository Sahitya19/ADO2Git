<#
.SYNOPSIS
  Read-only inventory of the ADO project: repos with branch, tag and last-commit counts, pull requests, and everything
  around the repos that GitHub Enterprise Importer does not move:
  service connections, variable groups, secure files, environments and checks, branch policies,
  security groups, build and release definitions, task groups and agent pools.

.DESCRIPTION
  Only GET calls (plus one read-only POST for identity lookup). Secret values are never returned by ADO
  and never written. Plain (non-secret) variable values are written only with -IncludePlainValues.

  PAT scopes (all Read): Build, Release, Code, Service Connections, Variable Groups, Secure Files,
  Environment, Agent Pools, Task Groups, Project and Team, Graph, Identity.

.EXAMPLE
  ./scripts/Get-AdoMigrationInventory.ps1 -Organization AnalyticsDataHub -Project Platform
  ./scripts/Get-AdoMigrationInventory.ps1 -Organization AnalyticsDataHub -Project Platform -UseAzCli -IncludePlainValues
#>
[CmdletBinding()]
param(
  [Parameter(Mandatory = $true)] [string]$Organization,
  [Parameter(Mandatory = $true)] [string[]]$Project,
  [string]$OutDir = 'docs/inventory/raw',
  [switch]$IncludePlainValues,
  [switch]$SkipServiceConnectionHistory,
  [switch]$UseAzCli
)

. "$PSScriptRoot/AdoCommon.ps1"
$script:AdoHeaders = Get-AdoHeaders -UseAzCli:$UseAzCli
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null

$org = $Organization
$dev = "https://dev.azure.com/$org"
$vsrm = "https://vsrm.dev.azure.com/$org"
$vssps = "https://vssps.dev.azure.com/$org"
$api = 'api-version=7.1'
$pre = 'api-version=7.1-preview.1'

$repos = @(); $branches = @(); $prs = @(); $sc = @(); $scUse = @(); $vg = @(); $vgVals = @(); $sf = @(); $envs = @(); $checks = @()
$pol = @(); $grp = @(); $builds = @(); $rels = @(); $relTasks = @(); $tg = @(); $pools = @(); $caps = @()

foreach ($projName in $Project) {
  Write-Host "== Project $projName"
  $p = [uri]::EscapeDataString($projName)

  # ---- repos
  $r = Invoke-Ado "$dev/$p/_apis/git/repositories?$api"
  $repoById = @{}
  foreach ($x in @($r.value)) {
    if (-not $x) { continue }
    $repoById[$x.id] = $x.name
    $branchesList = @(); $tagCount = 0; $lastCommit = ''
    if (-not $x.isDisabled) {
      $branchesList = @(Invoke-AdoAll "$dev/$p/_apis/git/repositories/$($x.id)/refs?filter=heads/&`$top=1000&$api")
      $tagCount = @(Invoke-AdoAll "$dev/$p/_apis/git/repositories/$($x.id)/refs?filter=tags/&`$top=1000&$api").Count
      $c1 = Invoke-Ado "$dev/$p/_apis/git/repositories/$($x.id)/commits?searchCriteria.`$top=1&$api"
      if ($c1 -and $c1.value) { $lastCommit = Format-AdoDate (@($c1.value)[0].committer.date) }
      foreach ($br in $branchesList) { $branches += [pscustomobject]@{ project = $projName; repo = $x.name; branch = ($br.name -replace '^refs/heads/', ''); creator = $br.creator.displayName; isLocked = $br.isLocked } }
    }
    $repos += [pscustomobject]@{ project = $projName; repo = $x.name; id = $x.id; defaultBranch = $x.defaultBranch; sizeMB = [math]::Round($x.size / 1MB, 1); isDisabled = $x.isDisabled; branches = $branchesList.Count; tags = $tagCount; lastCommit = $lastCommit; url = $x.webUrl }
  }

  # ---- pull requests (all statuses, paged)
  $skip = 0
  while ($true) {
    $pr = Invoke-Ado "$dev/$p/_apis/git/pullrequests?searchCriteria.status=all&`$top=500&`$skip=$skip&$api"
    $items = @($pr.value | Where-Object { $_ })
    foreach ($y in $items) {
      $prs += [pscustomobject]@{ project = $projName; repo = $y.repository.name; id = $y.pullRequestId; status = $y.status; title = $y.title; source = ($y.sourceRefName -replace '^refs/heads/', ''); target = ($y.targetRefName -replace '^refs/heads/', ''); createdBy = $y.createdBy.displayName; created = Format-AdoDate $y.creationDate; closed = Format-AdoDate $y.closedDate; isDraft = $y.isDraft }
    }
    if ($items.Count -lt 500) { break }
    $skip += 500
  }

  # ---- service connections
  $e = Invoke-Ado "$dev/$p/_apis/serviceendpoint/endpoints?includeDetails=true&$api"
  foreach ($x in @($e.value)) {
    if (-not $x) { continue }
    $ap = $x.authorization.parameters
    $lastUsed = ''; $usedBy = ''
    if (-not $SkipServiceConnectionHistory) {
      $h = Invoke-Ado "$dev/$p/_apis/serviceendpoint/$($x.id)/executionhistory?top=50&$pre"
      $runs = @($h.value)
      if ($runs.Count -gt 0 -and $runs[0]) {
        $lastUsed = Format-AdoDate $runs[0].data.startTime
        $usedBy = (@($runs | ForEach-Object { $_.data.definition.name }) | Where-Object { $_ } | Sort-Object -Unique) -join ';'
        foreach ($run in $runs) { $scUse += [pscustomobject]@{ project = $projName; serviceConnection = $x.name; definition = $run.data.definition.name; planType = $run.data.planType; date = Format-AdoDate $run.data.startTime; result = $run.data.result } }
      }
    }
    $sc += [pscustomobject]@{
      project = $projName; name = $x.name; id = $x.id; type = $x.type; scheme = $x.authorization.scheme
      servicePrincipalId = $ap.serviceprincipalid; tenantId = $ap.tenantid
      subscriptionId = $x.data.subscriptionId; subscriptionName = $x.data.subscriptionName; scopeLevel = $x.data.scopeLevel
      managementGroupId = $x.data.managementGroupId; creationMode = $x.data.creationMode
      url = $x.url; isShared = $x.isShared; isReady = $x.isReady; lastUsed = $lastUsed; usedBy = $usedBy
    }
  }

  # ---- variable groups (names only; plain values only with -IncludePlainValues)
  $v = Invoke-Ado "$dev/$p/_apis/distributedtask/variablegroups?$api"
  foreach ($x in @($v.value)) {
    if (-not $x) { continue }
    $names = @(); $secretCount = 0
    if ($x.variables) {
      foreach ($prop in $x.variables.PSObject.Properties) {
        $isSecret = [bool]$prop.Value.isSecret
        if ($isSecret) { $secretCount++ }
        $names += $prop.Name
        $vgVals += [pscustomobject]@{
          project = $projName; group = $x.name; variable = $prop.Name; isSecret = $isSecret
          value = $(if ($IncludePlainValues -and -not $isSecret -and $x.type -ne 'AzureKeyVault') { $prop.Value.value } else { '' })
        }
      }
    }
    $vg += [pscustomobject]@{
      project = $projName; group = $x.name; id = $x.id; type = $x.type
      keyVault = $(if ($x.providerData) { $x.providerData.vault } else { '' })
      keyVaultServiceConnection = $(if ($x.providerData) { $x.providerData.serviceEndpointId } else { '' })
      variables = $names.Count; secrets = $secretCount; modifiedOn = Format-AdoDate $x.modifiedOn; description = $x.description
    }
  }

  # ---- secure files
  $s = Invoke-Ado "$dev/$p/_apis/distributedtask/securefiles?$pre"
  foreach ($x in @($s.value)) { if ($x) { $sf += [pscustomobject]@{ project = $projName; name = $x.name; id = $x.id; modifiedOn = Format-AdoDate $x.modifiedOn; modifiedBy = $x.modifiedBy.displayName } } }

  # ---- environments and their checks (approvals, branch control, business hours ...)
  $en = Invoke-Ado "$dev/$p/_apis/pipelines/environments?`$top=1000&$pre"
  foreach ($x in @($en.value)) {
    if (-not $x) { continue }
    $envs += [pscustomobject]@{ project = $projName; environment = $x.name; id = $x.id; createdOn = Format-AdoDate $x.createdOn; lastModifiedOn = Format-AdoDate $x.lastModifiedOn }
    $c = Invoke-Ado "$dev/$p/_apis/pipelines/checks/configurations?resourceType=environment&resourceId=$($x.id)&`$expand=settings&$pre"
    foreach ($y in @($c.value)) {
      if (-not $y) { continue }
      $approvers = ''
      if ($y.settings -and $y.settings.approvers) { $approvers = (@($y.settings.approvers) | ForEach-Object { $_.displayName }) -join ';' }
      $checks += [pscustomobject]@{ project = $projName; environment = $x.name; checkType = $y.type.name; approvers = $approvers; minRequiredApprovers = $(if ($y.settings) { $y.settings.minRequiredApprovers } else { '' }); timeoutMinutes = $y.timeout }
    }
  }

  # ---- branch policies
  $po = Invoke-Ado "$dev/$p/_apis/policy/configurations?$api"
  foreach ($x in @($po.value)) {
    if (-not $x) { continue }
    foreach ($scope in @($x.settings.scope)) {
      $pol += [pscustomobject]@{
        project = $projName; repo = $(if ($scope -and $scope.repositoryId) { $repoById[$scope.repositoryId] } else { '(all repos)' })
        branch = $(if ($scope) { $scope.refName } else { '' }); matchKind = $(if ($scope) { $scope.matchKind } else { '' })
        policy = $x.type.displayName; isEnabled = $x.isEnabled; isBlocking = $x.isBlocking
        minimumApproverCount = $x.settings.minimumApproverCount; creatorVoteCounts = $x.settings.creatorVoteCounts
        resetOnSourcePush = $x.settings.resetOnSourcePush; buildDefinitionId = $x.settings.buildDefinitionId
        requiredReviewerIds = (@($x.settings.requiredReviewerIds) -join ';'); filenamePatterns = (@($x.settings.filenamePatterns) -join ';')
      }
    }
  }

  # ---- build definitions
  $b = Invoke-AdoAll "$dev/$p/_apis/build/definitions?includeLatestBuilds=true&queryOrder=lastModifiedDescending&$api"
  foreach ($x in $b) {
    $builds += [pscustomobject]@{
      project = $projName; name = $x.name; id = $x.id; folder = $x.path
      kind = $(if ($x.process.type -eq 2) { 'yaml' } else { 'classic' }); yamlFile = $x.process.yamlFilename
      repo = $x.repository.name; repoType = $x.repository.type; queueStatus = $x.queueStatus; pool = $x.queue.name
      lastRun = Format-AdoDate $x.latestBuild.finishTime; lastResult = $x.latestBuild.result
    }
  }

  # ---- classic release definitions with their task sequence per stage (for /pipeline-patterns)
  $rl = Invoke-AdoAll "$vsrm/$p/_apis/release/definitions?$api"
  foreach ($d in $rl) {
    $full = Invoke-Ado "$vsrm/$p/_apis/release/definitions/$($d.id)?$api"
    if (-not $full) { continue }
    $artifacts = (@($full.artifacts) | ForEach-Object { "$($_.type):$($_.definitionReference.definition.name)" }) -join ';'
    $stageNames = @()
    foreach ($st in @($full.environments)) {
      if (-not $st) { continue }
      $stageNames += $st.name
      $taskNames = @()
      foreach ($ph in @($st.deployPhases)) { foreach ($t in @($ph.workflowTasks)) { if ($t -and $t.enabled) { $taskNames += $t.name } } }
      $appr = @($st.preDeployApprovals.approvals | Where-Object { -not $_.isAutomated })
      $relTasks += [pscustomobject]@{
        project = $projName; release = $full.name; releaseId = $full.id; stage = $st.name
        approvers = (@($appr | ForEach-Object { $_.approver.displayName }) -join ';')
        gates = $(if ($st.preDeploymentGates -and $st.preDeploymentGates.gates) { @($st.preDeploymentGates.gates).Count } else { 0 })
        pool = (@($st.deployPhases | ForEach-Object { $_.deploymentInput.queueId }) -join ';')
        tasks = ($taskNames -join ' > ')
      }
    }
    $rels += [pscustomobject]@{ project = $projName; release = $full.name; id = $full.id; folder = $full.path; stages = ($stageNames -join ' > '); artifacts = $artifacts; modifiedOn = Format-AdoDate $full.modifiedOn }
  }

  # ---- task groups
  $t = Invoke-Ado "$dev/$p/_apis/distributedtask/taskgroups?$pre"
  foreach ($x in @($t.value)) { if ($x) { $tg += [pscustomobject]@{ project = $projName; name = $x.name; id = $x.id; version = $x.version.major; tasks = (@($x.tasks) | ForEach-Object { $_.displayName }) -join ' > ' } } }

  # ---- security groups and members
  $desc = Invoke-Ado "$vssps/_apis/graph/descriptors/$((Invoke-Ado "$dev/_apis/projects/${p}?$api").id)?$pre"
  if ($desc) {
    $groups = Invoke-AdoAll "$vssps/_apis/graph/groups?scopeDescriptor=$($desc.value)&$pre"
    foreach ($g in $groups) {
      $mem = Invoke-Ado "$vssps/_apis/graph/Memberships/$($g.descriptor)?direction=down&$pre"
      $ids = @(@($mem.value) | Where-Object { $_ } | ForEach-Object { $_.memberDescriptor })
      $names = @()
      for ($i = 0; $i -lt $ids.Count; $i += 100) {
        $chunk = $ids[$i..([math]::Min($i + 99, $ids.Count - 1))]
        $look = Invoke-Ado "$vssps/_apis/graph/subjectlookup?$pre" 'POST' @{ lookupKeys = @($chunk | ForEach-Object { @{ descriptor = $_ } }) }
        if ($look -and $look.value) { foreach ($prop in $look.value.PSObject.Properties) { $names += "$($prop.Value.displayName) [$($prop.Value.subjectKind)]" } }
      }
      $grp += [pscustomobject]@{ project = $projName; group = $g.displayName; description = $g.description; members = $ids.Count; memberNames = ($names -join ';') }
    }
  }
}

# ---- agent pools (org level) and what a sample of agents have installed (for /runner-tools)
$pl = Invoke-Ado "$dev/_apis/distributedtask/pools?$api"
foreach ($x in @($pl.value)) {
  if (-not $x) { continue }
  $ag = Invoke-Ado "$dev/_apis/distributedtask/pools/$($x.id)/agents?includeCapabilities=true&$api"
  $agents = @($ag.value | Where-Object { $_ })
  $pools += [pscustomobject]@{ pool = $x.name; id = $x.id; isHosted = $x.isHosted; agents = $agents.Count; online = @($agents | Where-Object { $_.status -eq 'online' }).Count; os = (@($agents | ForEach-Object { $_.osDescription }) | Sort-Object -Unique) -join ';' }
  foreach ($a in @($agents | Select-Object -First 2)) {
    foreach ($bag in @($a.systemCapabilities, $a.userCapabilities)) {
      if (-not $bag) { continue }
      foreach ($prop in $bag.PSObject.Properties) {
        # keep tool-like capabilities, skip environment noise and anything secret-looking
        if ($prop.Name -match '(?i)token|secret|password|key|^env\.|^Agent\.|PATH$|^PSModulePath$|^USER|^HOME|^HOSTNAME') { continue }
        $caps += [pscustomobject]@{ pool = $x.name; agent = $a.name; capability = $prop.Name; value = "$($prop.Value)".Substring(0, [math]::Min(200, "$($prop.Value)".Length)) }
      }
    }
  }
}

Save-Csv $repos  $OutDir 'ado-repos.csv'
Save-Csv $branches $OutDir 'branches.csv'
Save-Csv $prs    $OutDir 'pull-requests.csv'
Save-Csv $sc     $OutDir 'service-connections.csv'
Save-Csv $scUse  $OutDir 'service-connection-usage.csv'
Save-Csv $vg     $OutDir 'variable-groups.csv'
Save-Csv $vgVals $OutDir 'variable-group-variables.csv'
Save-Csv $sf     $OutDir 'secure-files.csv'
Save-Csv $envs   $OutDir 'environments.csv'
Save-Csv $checks $OutDir 'environment-checks.csv'
Save-Csv $pol    $OutDir 'branch-policies.csv'
Save-Csv $grp    $OutDir 'security-groups.csv'
Save-Csv $builds $OutDir 'build-definitions.csv'
Save-Csv $rels   $OutDir 'release-definitions.csv'
Save-Csv $relTasks $OutDir 'release-stage-tasks.csv'
Save-Csv $tg     $OutDir 'task-groups.csv'
Save-Csv $pools  $OutDir 'agent-pools.csv'
Save-Csv $caps   $OutDir 'agent-capabilities.csv'
Save-Csv $script:AdoErrors $OutDir 'errors.csv'

$summary = [ordered]@{
  organization = $org; projects = ($Project -join ';'); pulledAtUtc = (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ')
  repos = $repos.Count; branches = $branches.Count; pullRequests = $prs.Count; activePullRequests = @($prs | Where-Object { $_.status -eq 'active' }).Count; serviceConnections = $sc.Count; variableGroups = $vg.Count; secretVariables = @($vgVals | Where-Object { $_.isSecret }).Count
  secureFiles = $sf.Count; environments = $envs.Count; environmentChecks = $checks.Count; branchPolicies = $pol.Count; securityGroups = $grp.Count
  buildDefinitions = $builds.Count; yamlBuilds = @($builds | Where-Object { $_.kind -eq 'yaml' }).Count; classicBuilds = @($builds | Where-Object { $_.kind -eq 'classic' }).Count
  releaseDefinitions = $rels.Count; taskGroups = $tg.Count; agentPools = $pools.Count; failedCalls = $script:AdoErrors.Count
}
$summary | ConvertTo-Json | Set-Content -Encoding UTF8 (Join-Path $OutDir 'summary.json')
$summary | ConvertTo-Json
if ($script:AdoErrors.Count) { Write-Warning "$($script:AdoErrors.Count) calls failed. See $OutDir/errors.csv (usually a missing PAT scope)." }
