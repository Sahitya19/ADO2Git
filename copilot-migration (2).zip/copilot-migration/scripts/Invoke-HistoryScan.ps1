<#
.SYNOPSIS
  Runs gitleaks over every cloned ADO repo (full history) before import, and writes one report per repo.
  Read-only on the repos. Requires gitleaks on PATH (get it approved for the VDI first).

.EXAMPLE
  ./scripts/Invoke-HistoryScan.ps1 -RootPath C:\src\ado
#>
[CmdletBinding()]
param(
  [Parameter(Mandatory = $true)] [string]$RootPath,
  [string]$OutDir = 'docs/security/history-scan'
)
$ErrorActionPreference = 'Stop'
if (-not (Get-Command gitleaks -ErrorAction SilentlyContinue)) { throw 'gitleaks is not installed or not on PATH.' }
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null
$summary = @()
foreach ($repo in Get-ChildItem -Path $RootPath -Directory) {
  if (-not (Test-Path (Join-Path $repo.FullName '.git'))) { continue }
  $report = Join-Path $OutDir "$($repo.Name).json"
  Write-Host "Scanning $($repo.Name)"
  # --redact keeps secret values out of the report
  & gitleaks detect --source $repo.FullName --report-format json --report-path $report --redact --no-banner --exit-code 0 | Out-Null
  $count = 0
  if (Test-Path $report) { $j = Get-Content $report -Raw | ConvertFrom-Json; $count = @($j | Where-Object { $_ }).Count }
  $summary += [pscustomobject]@{ repo = $repo.Name; findings = $count; report = $report }
}
$summary | Export-Csv -NoTypeInformation -Encoding UTF8 (Join-Path $OutDir 'summary.csv')
$summary | Format-Table -AutoSize
