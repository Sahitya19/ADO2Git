<#
.SYNOPSIS
  For every Azure service connection in service-connections.csv, lists what its identity can do in Azure today.
  Read-only. Uses your `az login` session; you need Reader on the subscriptions (or Directory Reader for app lookups).

.EXAMPLE
  az login
  ./scripts/Get-ServiceConnectionRoles.ps1
#>
[CmdletBinding()]
param(
  [string]$InFile = 'docs/inventory/raw/service-connections.csv',
  [string]$OutFile = 'docs/inventory/raw/service-connection-roles.csv'
)
$ErrorActionPreference = 'Stop'
if (-not (Test-Path $InFile)) { throw "Run Get-AdoMigrationInventory.ps1 first ($InFile not found)." }

$rows = @()
$azure = Import-Csv $InFile | Where-Object { $_.type -eq 'azurerm' -and $_.servicePrincipalId }
$seen = @{}
foreach ($c in $azure) {
  $appId = $c.servicePrincipalId
  if (-not $seen.ContainsKey($appId)) {
    $json = az role assignment list --assignee $appId --all -o json 2>$null
    $seen[$appId] = $(if ($json) { $json | ConvertFrom-Json } else { $null })
    $sp = az ad sp show --id $appId --query "{name:displayName, type:servicePrincipalType}" -o json 2>$null
    $seen["$appId-sp"] = $(if ($sp) { $sp | ConvertFrom-Json } else { $null })
    $cred = az ad app credential list --id $appId --query "[].endDateTime" -o tsv 2>$null
    $seen["$appId-cred"] = $(if ($cred) { (@($cred) | Sort-Object)[0] } else { '' })
  }
  $assign = @($seen[$appId])
  $spInfo = $seen["$appId-sp"]
  if ($assign.Count -eq 0 -or -not $assign[0]) {
    $rows += [pscustomobject]@{ serviceConnection = $c.name; project = $c.project; scheme = $c.scheme; appId = $appId; principalName = $(if ($spInfo) { $spInfo.name } else { 'UNKNOWN (no access or deleted)' }); role = ''; scope = ''; secretExpires = $seen["$appId-cred"]; lastUsed = $c.lastUsed; usedBy = $c.usedBy }
    continue
  }
  foreach ($a in $assign) {
    $rows += [pscustomobject]@{ serviceConnection = $c.name; project = $c.project; scheme = $c.scheme; appId = $appId; principalName = $(if ($spInfo) { $spInfo.name } else { '' }); role = $a.roleDefinitionName; scope = $a.scope; secretExpires = $seen["$appId-cred"]; lastUsed = $c.lastUsed; usedBy = $c.usedBy }
  }
}
$rows | Export-Csv -NoTypeInformation -Encoding UTF8 $OutFile
Write-Host "Wrote $($rows.Count) rows for $($azure.Count) Azure service connections to $OutFile"
