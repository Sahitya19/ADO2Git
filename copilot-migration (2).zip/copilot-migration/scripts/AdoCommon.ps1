# Shared helpers for the read-only ADO inventory scripts. Dot-source it: . "$PSScriptRoot/AdoCommon.ps1"
# Auth: $env:ADO_PAT, or -UseAzCli in the calling script (sets $script:AdoUseAzCli = $true before dot-sourcing).
# Works on Windows PowerShell 5.1 and PowerShell 7.

$ErrorActionPreference = 'Stop'
$script:AdoErrors = New-Object System.Collections.Generic.List[object]

function Get-AdoHeaders {
  param([switch]$UseAzCli)
  if ($UseAzCli) {
    # 499b84ac-1321-427f-aa17-267ca6975798 = Azure DevOps resource id in Entra
    $token = az account get-access-token --resource 499b84ac-1321-427f-aa17-267ca6975798 --query accessToken -o tsv
    if (-not $token) { throw "az account get-access-token failed. Run 'az login' first." }
    return @{ Authorization = "Bearer $token" }
  }
  if (-not $env:ADO_PAT) { throw "Set `$env:ADO_PAT in the terminal or use -UseAzCli. Never paste a token into Copilot Chat." }
  $b64 = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$($env:ADO_PAT)"))
  return @{ Authorization = "Basic $b64" }
}

function Invoke-Ado {
  # Returns the parsed body, or $null after logging the failure (the run continues).
  param([string]$Uri, [string]$Method = 'GET', $Body = $null, [switch]$Raw)
  for ($attempt = 1; $attempt -le 5; $attempt++) {
    try {
      $p = @{ Uri = $Uri; Method = $Method; Headers = $script:AdoHeaders; UseBasicParsing = $true }
      if ($Body) { $p.ContentType = 'application/json'; $p.Body = ($Body | ConvertTo-Json -Depth 8) }
      $resp = Invoke-WebRequest @p
      if ($Raw) { return $resp }
      if (-not $resp.Content) { return $null }
      return ($resp.Content | ConvertFrom-Json)
    } catch {
      $code = $null
      if ($_.Exception.Response) { $code = [int]$_.Exception.Response.StatusCode }
      if (($code -eq 429 -or $code -ge 500) -and $attempt -lt 5) { Start-Sleep -Seconds ([math]::Pow(2, $attempt)); continue }
      $script:AdoErrors.Add([pscustomobject]@{ uri = $Uri; status = $code; message = $_.Exception.Message })
      Write-Warning "Call failed ($code): $Uri"
      return $null
    }
  }
}

function Invoke-AdoAll {
  # Follows x-ms-continuationtoken paging and returns all .value items.
  param([string]$Uri)
  $all = @(); $token = $null
  do {
    $u = $Uri
    if ($token) { $sep = '?'; if ($Uri.Contains('?')) { $sep = '&' }; $u = "$Uri${sep}continuationToken=$([uri]::EscapeDataString($token))" }
    $resp = Invoke-Ado -Uri $u -Raw
    if (-not $resp) { break }
    $body = $resp.Content | ConvertFrom-Json
    if ($body.value) { $all += $body.value }
    $token = $resp.Headers['x-ms-continuationtoken']
    if ($token -is [array]) { $token = $token[0] }
  } while ($token)
  return $all
}

function Save-Csv {
  param($Rows, [string]$Dir, [string]$Name)
  $path = Join-Path $Dir $Name
  if (@($Rows).Count -eq 0) { Set-Content -Path $path -Value '' -Encoding UTF8; return }   # empty file = zero rows
  $Rows | Export-Csv -NoTypeInformation -Encoding UTF8 -Path $path
}

function Format-AdoDate { param($d) if ($d) { return ([datetime]$d).ToString('yyyy-MM-dd') } return '' }
