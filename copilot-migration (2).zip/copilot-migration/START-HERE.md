# Start here (VDI, VS Code, Copilot Chat)

## 1. Put the folders together (one workspace)

Make one folder, for example `C:\src\migration-hub`, and arrange the three kits like this:

```
migration-hub/
  .github/
    copilot-instructions.md               <- from copilot-migration
    instructions/
      artifacts.instructions.md           <- copilot-artifacts/.github/copilot-instructions.md, renamed
      timeline.instructions.md            <- copilot-timeline/.github/copilot-instructions.md, renamed
    prompts/                              <- every *.prompt.md from all three kits
    workflows/actions-importer-audit.yml  <- from copilot-migration
  .vscode/mcp.json                        <- from any kit (they are the same)
  scripts/                                <- scripts from copilot-migration and copilot-artifacts
  docs/                                   <- docs folders from all three kits, merged
  rulesets/  templates/                   <- from copilot-migration
```

At the very top of the two renamed `.instructions.md` files, add these three lines:

```
---
applyTo: "**"
---
```

The ADO organization is set to `AnalyticsDataHub`, project `Platform`.

The runner kit (`github-runner-aca`) is separate. You don't need it in this workspace today.

## 2. Open it in VS Code

1. File > Open Folder > `migration-hub`.
2. Settings (Ctrl+,) > search `github-enterprise.uri` > set `https://cencora.ghe.com`. Then sign in from the Accounts icon (bottom left) with your GHE.com account.
3. Open Copilot Chat (Ctrl+Alt+I). In the mode dropdown under the chat box, pick **Agent**.
4. Type `/` in the chat box. Your prompts (`/plan-chart`, `/inventory-all` ...) should appear in the list. If they don't: Settings > search `prompt files` > turn on **Chat: Prompt Files**, then reload the window.

## 3. Sign in for the scripts (VS Code terminal, Ctrl+`)

```powershell
# GitHub (cencora.ghe.com)
gh auth login --hostname cencora.ghe.com
gh auth status --hostname cencora.ghe.com

# Azure DevOps: create a PAT in ADO > User settings > Personal access tokens,
# Read on: Code, Build, Release, Service Connections, Variable Groups, Secure Files, Environment,
# Agent Pools, Task Groups, Packaging, Project and Team, Graph, Identity. Then:
$env:ADO_PAT = Read-Host 'Paste ADO PAT'

# Azure (for service connection roles), optional today
az login
az account show
```

Never paste a token into Copilot Chat. `$env:ADO_PAT` lasts only for this terminal; set it again if you open a new one.

The MCP servers in `.vscode/mcp.json` are optional. If your admin hasn't enabled MCP for Copilot, skip them: the prompts use the scripts and `gh` instead.

## 4. Prompts to run, in order

**a. Check the setup** (paste into Copilot Chat, Agent mode)

> Check my setup for the migration kit. In the terminal, run `git --version`, `gh --version`, `gh auth status --hostname cencora.ghe.com`, `az --version`, `$PSVersionTable.PSVersion`, `docker --version`, and check `$env:ADO_PAT` is set without printing it. Then call `https://dev.azure.com/<org>/_apis/projects?api-version=7.1` with the PAT and list the project names. Give me a table of what works and what is missing, and what to install or ask for.

**b. Timeline chart for tonight's call** (no ADO access needed)

> /plan-chart

**c. Talking points for tonight**

> Read docs/migration/plan-12-week.md and the "Tonight's call" and "Access to request this week" sections I paste below. Write docs/migration/status/<today>-call-notes.md with: what was done last week, what is blocked (runners need org-level rights), the access asks with who must grant each, and the next 2 weeks from the plan. One page, plain English.

(Paste those two sections from the guide after the prompt.)

**d. Inventory** (needs the ADO PAT; takes a while, can run after the call)

> /inventory-all

Then `/plan-waves`, then `/artifacts-inventory`. After that, follow the steps in the guide in order.

**Every week from now on**

> /weekly-update
> /plan-chart with status

Note: `/migration-timeline` (from the older timeline kit) still uses the old 32-week dates in `docs/migration/baseline-plan.md`. Use `/plan-chart` until that file is updated.
