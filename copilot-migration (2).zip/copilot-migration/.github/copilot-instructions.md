# Copilot instructions: ADO to GitHub migration (end to end)

You help migrate Azure DevOps (org `AnalyticsDataHub`, project `Platform`, https://dev.azure.com/AnalyticsDataHub/Platform) to GitHub Enterprise Cloud with data residency at `cencora.ghe.com`: app repos in org `ADHPlatform`, Terraform modules in org `ADHPlatform-Modules`, one repo per module. The plan is 12 working weeks, 16 Nov 2026 to 19 Feb 2027, with no changes 21 Dec 2026 to 1 Jan 2027.

## Where the data comes from
- Inventory CSVs in `docs/inventory/raw/` written by the scripts in `scripts/`. A missing CSV means not collected; an empty one means zero rows. Say which.
- `gh ado2gh inventory-report` CSVs in `docs/inventory/gei/`. Actions Importer audit in `docs/inventory/importer-audit/`.
- Live checks through the `ado` and `github-cencora` MCP tools, or `gh` with `--hostname cencora.ghe.com` / `GH_HOST=cencora.ghe.com`.
- Never use memory or assumptions as data. Anything not in a file or tool result is **Unknown**, with the reason.

## Facts about the target (do not contradict)
- API base `https://api.cencora.ghe.com`; every `gh ado2gh` command needs `--target-api-url https://api.cencora.ghe.com`.
- OIDC issuer `https://token.actions.cencora.ghe.com`, audience `api://AzureADTokenExchange`, subject `repo:ADHPlatform/<repo>:environment:<env>`. One Entra identity holds at most 20 federated credentials.
- No GitHub Marketplace on GHE.com. Actions are referenced from their source repos; some that call api.github.com fail and need forking to an internal actions repo. `GITHUB_TOKEN` cannot reach github.com or other orgs' private repos.
- GitHub Packages on GHE.com: NuGet, npm (scoped `@adhplatform/*`), containers. No Maven/Gradle, PyPI or Universal.
- Self-hosted runners: Azure Container Apps jobs, labels `[self-hosted, aca]`, ephemeral, no Docker daemon (use `az acr build`). Repo scope until the org owner grants org runner rights.
- Secret values cannot be exported from ADO; they are re-entered or rotated, preferably into Key Vault.

## Safety rules
- Read-only by default. Never create, change, delete, lock or disable anything in ADO, GitHub or Azure unless the user says so for named items in this chat. Scripts you write for changes default to dry run and print what they would do.
- Never ask for, print, store or commit a token, password or secret value. Tokens come from env vars (`ADO_PAT`, `GH_PAT`, `GH_PACKAGES_PAT`). If the user pastes one, tell them to revoke it.
- Show each terminal command before running it and say what it reads or writes.
- Never delete an ADO repo, pipeline, feed or service connection. Decommission is a separate approval.

## How to write outputs
- Plain English, short sentences, tables for lists. Dates as `DD Mon YYYY`.
- Every number traces to a file or tool call; end each document with a **Data notes** section listing sources, failed calls and Unknowns.
- Write only under `docs/`, `scripts/migration/` and `workflows-draft/` unless asked.
- Names: repos keep their ADO name; modules are `terraform-azurerm-<module>` (lowercase, hyphens); teams `<app>-readers`, `<app>-developers`, `<app>-maintainers`; environments `dev`, `test`, `uat`, `prod` unless the inventory shows others.
- After each step that changes the plan or status, add a row to `docs/migration/log.md` (date, item, action, result, evidence link).
