---
description: List the tools pipelines need on runners and update the runner Dockerfile
mode: agent
---

Work out what the ACA runner image must contain. Follow the instructions file.

1. Read `docs/inventory/raw/agent-capabilities.csv` (tools on today's ADO agents) and `agent-pools.csv`.
2. Read the Actions Importer audit and the pipeline YAML (ask me for the clone folder) and list every tool the pipelines call: Terraform (versions), az CLI, Bicep, kubectl, helm, dotnet SDKs, node, Java, Python, PowerShell, sqlpackage, others.
3. Compare with the `Dockerfile` in the runner kit (ask me where it is). Write `docs/migration/runner-tools.md`: tool, version needed, used by (pipelines), in image yes/no, how to install.
4. Propose the Dockerfile changes as a diff. Pin versions. Do not add Docker-in-Docker; image builds use `az acr build`.
5. List pipelines that need Windows or a GUI; those need a different runner and a decision.
