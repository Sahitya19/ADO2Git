---
description: Draw the migration plan as a timeline chart (Mermaid gantt) from the plan file, optionally with live progress
mode: agent
---

Draw the migration timeline. Follow `.github/copilot-instructions.md`.

1. Read the stages table in `docs/migration/plan-12-week.md` (or `${input:planFile:plan file path, blank for the default}`). Use only the dates in that file; never invent stages or dates.
2. Write a Mermaid `gantt` chart in the same style as the one in that file:
   - `title` = one sentence with the finding, for example "Cutover by 19 Feb 2027: pilot before the break, three waves after". If live data shows a slip, say so in the title.
   - `dateFormat YYYY-MM-DD`, `axisFormat %b %d`, `tickInterval 2week`, a `todayMarker`.
   - One row per stage. End dates are exclusive: add one day to each stage's last day.
   - Holiday freeze styled `done` (grey). Final cutover styled `crit`.
3. If I ask for progress ("with status"), check `docs/migration/log.md` and the GitHub and ADO tools: mark finished stages `done`, the current one `active`, stages past their end with open work `crit`, and add a second section "Forecast" with any moved end date beside the plan.
4. Save to `docs/migration/status/<YYYY-MM-DD>-timeline.md` with the chart and a 3-line summary under it (where we are, on track or not, the one decision needed). Show me the chart in chat.

To view: open the file and press Ctrl+Shift+V (Markdown preview), or open it on cencora.ghe.com. If VS Code shows the code instead of a chart, install the "Markdown Preview Mermaid Support" extension, or view it on GitHub.
