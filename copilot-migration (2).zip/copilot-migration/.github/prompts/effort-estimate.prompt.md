---
description: Estimate migration effort in person-days from the live inventory
mode: agent
---

Estimate the migration effort from real counts. Follow `.github/copilot-instructions.md`.

1. Read the newest `docs/migration/status/*-snapshot.md` or `docs/inventory/*-inventory.md`, and `docs/inventory/raw/summary.json`. If none exists, tell me to run `/ado-snapshot` first.
2. Use these unit rates (person-days, low to high). Write them into the output so they can be challenged:
   | Item | Unit | Low | High |
   |---|---|---|---|
   | Inventory, wave plan | project | 4 | 6 |
   | GitHub org setup (teams, rulesets, policies, security config) | org | 4 | 6 |
   | Org runners (image, tools, groups, load test) | once | 6 | 10 |
   | Repo migration incl. verify and CODEOWNERS | repo | 0.3 | 0.6 |
   | Active PR recreated | PR | 0.1 | 0.2 |
   | OIDC identity (create, roles, federated creds, test) | identity (about 1 per app per environment) | 0.3 | 0.6 |
   | Variable group to variables / Key Vault | group | 0.2 | 0.4 |
   | Environment with approvals | environment | 0.05 | 0.1 |
   | YAML build to Actions (importer + fixes + green run) | build | 0.3 | 0.75 |
   | Classic build to Actions | build | 0.75 | 1.5 |
   | Shared deploy workflow (build and test once) | pattern | 2 | 4 |
   | Classic release wired to a shared workflow | release | 0.15 | 0.4 |
   | Terraform module split with history, tags, CI | module | 0.5 | 1 |
   | Module consumer updates | consumer reference | 0.05 | 0.1 |
   | Feed migration (internal packages) | feed | 1 | 3 |
   | Security scanning setup and history scan | project | 3 | 5 |
   | Cutover and hypercare | wave | 3 | 5 |
3. Multiply by the counts (patterns: use `/pipeline-patterns` output if present, else assume releases ÷ 20). State every assumption.
4. Compare with capacity: team size and allocation (ask me; default 4 people at 80%) × working days from 16 Nov 2026 to 19 Feb 2027 excluding 21 Dec to 1 Jan (60 days). Show the gap and two options to close it (extra people, or moving Wave 3 later).
5. Write `docs/migration/effort-estimate.md` with the table (item, count, low, high), totals, capacity, gap, options. Show me the totals in chat.
