---
description: Quick read of dev.azure.com/AnalyticsDataHub/Platform (repos, branches, PRs, pipelines, service connections, feeds) for a call
mode: agent
---

Take a quick, read-only snapshot of Azure DevOps project https://dev.azure.com/AnalyticsDataHub/Platform. Follow `.github/copilot-instructions.md`.

1. Check `$env:ADO_PAT` is set (do not print it). If not, tell me to run `$env:ADO_PAT = Read-Host 'Paste ADO PAT'` and stop.
2. Show me, then run (it takes a few minutes):
   `./scripts/Get-AdoMigrationInventory.ps1 -Organization AnalyticsDataHub -Project Platform -SkipServiceConnectionHistory`
   and, if `scripts/Get-AdoArtifactsInventory.ps1` exists:
   `./scripts/Get-AdoArtifactsInventory.ps1 -Organization AnalyticsDataHub -Project Platform -OutDir docs/inventory/raw/artifacts`
3. From `docs/inventory/raw/summary.json` and the CSVs, write `docs/migration/status/<YYYY-MM-DD>-snapshot.md` with one table:
   repos (and disabled), branches, tags, PRs total and active, YAML builds, classic builds, classic release definitions and stages, task groups, service connections by type and auth scheme, variable groups and secret variables, secure files, environments and how many have approvals, branch policies, agent pools and agents, feeds, internal packages by type.
   Under it: the 5 biggest repos, repos with no commit in 180 days, pipelines not run in 90 days, active PRs per repo.
4. If any call failed, list it from `errors.csv` with the likely missing PAT scope; mark those numbers Unknown.
5. Show me the table in chat. Compare with the 28 Oct assessment (23 repos, 125 YAML + 17 classic builds, 302 releases, 103 service connections, 57 variable groups, 106 environments, 5 feeds, 67 PRs / 10 active) and point out differences.
