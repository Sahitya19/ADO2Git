---
description: Plan each Terraform module as its own repo with history, tags and consumers
mode: agent
---

Plan the module split. Follow the instructions file.

1. Ask me for the clone folder. Find module folders: directories with `variables.tf` and `outputs.tf` that are referenced by `source = ` elsewhere, or under `modules/`. Also read the Artifacts inventory for Terraform modules published as Universal packages.
2. Find every consumer: `source =` lines in all clones (git URLs, relative paths `../modules/x`, Universal package downloads in pipelines). Record repo, file, line, current ref or version.
3. Per module: new name `terraform-azurerm-<module>`, source repo and path, commit count touching the path, existing versions (tags or package versions), consumers count, dependencies on other modules (split order: leaf modules first).
4. Write `docs/modules/module-plan.md` with that table, the split order, and per module the commands:
   `git clone <ado url> split-<module>` · `cd split-<module>` · `git filter-repo --subdirectory-filter <path>` · `gh repo create ADHPlatform-Modules/terraform-azurerm-<module> --internal --template ADHPlatform-Modules/terraform-azurerm-template` · `git remote add origin https://cencora.ghe.com/ADHPlatform-Modules/terraform-azurerm-<module>.git` · `git push -u origin main`
5. Per consumer, the new `source` line pinned to the first tag, as a diff. Relative-path consumers inside the same repo get a note: they now need a version.
6. Flag modules with no clear owner, no versions yet (start at v1.0.0 only after I confirm the interface is stable, otherwise v0.1.0), or circular dependencies.
