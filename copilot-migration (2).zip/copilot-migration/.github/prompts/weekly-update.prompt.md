---
description: Write a short status update for the weekly call
mode: agent
---

Write the weekly update for the migration call. Read-only.

1. Read `docs/migration/log.md` rows from the last 7 days, the newest inventory, `docs/migration/waves.md`, and any plan files changed in the last 7 days (git log).
2. Check live counts with the tools: repos in ADHPlatform matched to ADO repos, workflows with a green run on main, ADO pipelines disabled.
3. Write `docs/migration/status/<YYYY-MM-DD>-weekly.md` with: Done this week (bullets with evidence) · Next week · Blocked and asks (who must act) · On track for 19 Feb 2027? (one line, with the reason) · Numbers (repos, builds, releases, service connections, modules: done / total).
Keep it under one page. Show it to me in chat.
