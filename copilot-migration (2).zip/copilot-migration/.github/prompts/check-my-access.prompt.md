---
description: Check my own permissions in GitHub (cencora.ghe.com) and Azure DevOps, and draft the access request
mode: agent
---

Check what access I have today and what I still need for the migration. Read-only: never change any setting or permission. Follow `.github/copilot-instructions.md`.

## GitHub (show each command, then run it)
1. `gh auth status --hostname cencora.ghe.com` → my login and token scopes.
2. `gh api user --hostname cencora.ghe.com --jq '{login, type, site_admin}'`
3. For each org `ADHPlatform` and `ADHPlatform-Modules`: `gh api /user/memberships/orgs/<org> --hostname cencora.ghe.com --jq '{state, role}'` (role is `admin` for org owner, `member` otherwise; 404 = not a member or the org does not exist).
4. `gh api /user/teams --hostname cencora.ghe.com --paginate --jq '.[] | select(.organization.login=="ADHPlatform") | {team: .name, permission}'`
5. Repos I can administer: `gh api /orgs/ADHPlatform/repos --hostname cencora.ghe.com --paginate --jq '.[] | {name, admin: .permissions.admin, maintain: .permissions.maintain, push: .permissions.push}'`
6. Probe org-level rights (a 403 or 404 means I do not have it; that is expected, not an error):
   - runners: `gh api /orgs/ADHPlatform/actions/runners --hostname cencora.ghe.com --jq .total_count`
   - runner groups: `gh api /orgs/ADHPlatform/actions/runner-groups --hostname cencora.ghe.com --jq .total_count`
   - rulesets: `gh api /orgs/ADHPlatform/rulesets --hostname cencora.ghe.com --jq length`
   - org secrets: `gh api /orgs/ADHPlatform/actions/secrets --hostname cencora.ghe.com --jq .total_count`
   - custom org roles: `gh api /orgs/ADHPlatform/organization-roles --hostname cencora.ghe.com --jq '.roles[].name'`
   - create repos: `gh api /orgs/ADHPlatform --hostname cencora.ghe.com --jq '{members_can_create_repositories, members_can_create_internal_repositories, members_can_create_private_repositories}'`

## Azure DevOps
7. With `$env:ADO_PAT`: `GET https://dev.azure.com/AnalyticsDataHub/_apis/connectionData` → my identity. Then try, and record allowed / 401 / 403 for: list repos, list build definitions, list release definitions (`vsrm.dev.azure.com`), list service connections, list variable groups, list feeds (`feeds.dev.azure.com`), read the audit log (`auditservice.dev.azure.com/AnalyticsDataHub/_apis/audit/auditlog?batchSize=1`). Use `-Method Get` only.

## Write the result
Create `docs/security/<YYYY-MM-DD>-my-access.md` with:
1. A table: Capability | Needed for (guide step) | I have it? (Yes / No / Unknown) | Evidence (command and result).
   Capabilities: org owner; manage org runners and runner groups; install GitHub Apps on the org; migrator role (GEI); create repos; create teams; org rulesets; org secrets and variables; repo admin on pilot repo; GitHub Advanced Security enabled; ADO read on all the areas above; ADO audit log.
2. **Access request**: a short email to the ADHPlatform org owner (name Unknown) listing only the No items, why each is needed, and the exact setting or command (for example the custom org role with "Manage organization runners and runner groups", the GitHub App install, `gh ado2gh grant-migrator-role --github-org ADHPlatform --actor <my login> --actor-type USER --target-api-url https://api.cencora.ghe.com`). Polite, under 200 words.
Show me the table and the email in chat. Do not try to grant or work around any permission.
