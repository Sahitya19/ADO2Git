---
description: Append verified results to the migration log
mode: agent
---

Update `docs/migration/log.md`. Create it if missing with columns: Date | Wave | Item type | Item | Action | Result | Evidence.

Look at what changed since the last row: new `docs/` files, repo-verify results, workflows with first green runs on main (github tools), ADO definitions disabled (ado tools), packages and module tags published. Add one row per item with evidence (file path, run URL, or tool call). Do not add rows for things you could not confirm; list those under "Unconfirmed" at the end of your chat reply.
