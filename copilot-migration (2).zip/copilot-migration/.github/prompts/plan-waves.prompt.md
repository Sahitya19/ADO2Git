---
description: Group repos into pilot and waves and write the wave plan
mode: agent
---

Write the wave plan from the newest `docs/inventory/*-inventory.md`. Follow the instructions file.

Rules:
- Pilot (weeks 4-5, done by 18 Dec 2026): `Custodian_Infra_KeyVault` plus one small app repo, unless the inventory shows a better candidate; say why.
- Wave 1 (4-15 Jan 2027): about 10 repos with fewest pipelines, no shared modules published, low prod risk.
- Wave 2 (18-29 Jan): the Custodian repos.
- Wave 3 (1-12 Feb): `Modernization_Terraform` and the repos most coupled to it.
- A repo moves no earlier than the modules, packages and service connections it needs; list those prerequisites per repo.
- Repos sharing a release definition or a variable group go in the same wave.
- Drop candidates are listed, not migrated, pending my confirmation.

Write `docs/migration/waves.md`: one table per wave (repo, builds, releases, service connections, environments, prerequisites, owner = Unknown until I fill it, cutover date), a Mermaid `gantt` of pilot and waves, and a "Needs a decision" list. Show me the per-wave counts in chat.
