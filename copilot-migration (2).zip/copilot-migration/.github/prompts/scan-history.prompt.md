---
description: Scan ADO repo history for secrets before import and summarise
mode: agent
---

Scan the cloned ADO repos for secrets before they are imported. Read-only.

1. Ask me for the clone folder. Show and run `./scripts/Invoke-HistoryScan.ps1 -RootPath <folder>`. If gitleaks is not installed, stop and tell me it needs approval for the VDI; offer to use GitHub secret scanning after import instead, noting that push protection does not cover imported history.
2. Read `docs/security/history-scan/summary.csv` and the per-repo reports (values are redacted).
3. Write `docs/security/history-scan.md`: per repo, findings by rule type, file, commit date; mark likely false positives (test data, examples) separately; for each real-looking finding, the system it belongs to and "rotate before import" as the action.
4. Never print secret values, even partial.
