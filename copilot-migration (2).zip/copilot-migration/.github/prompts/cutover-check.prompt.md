---
description: Check a wave is ready for cutover
mode: agent
---

Check wave `${input:wave:pilot, 1, 2 or 3}` against the cutover checklist. Read-only.

For each repo in that wave (from `docs/migration/waves.md`), check with the tools:
1. Repo imported and verified (log row from /repo-verify).
2. Teams, ruleset and CODEOWNERS applied.
3. Every planned workflow has a green run on main.
4. Each environment has a successful deployment from GitHub with an approval, and the pilot had one rollback.
5. OIDC login works per environment (a successful `azure/login` step).
6. Variables and secrets present (names only) per the library plan.
7. Packages and module tags it needs exist.
8. Security configuration applied; no open critical alerts.
9. ADO: pipelines still enabled (list them, to be disabled at cutover), active PRs count.
Write `docs/migration/cutover-<wave>.md` with a pass/fail table and the remaining actions with owners Unknown. Show me the fails.
