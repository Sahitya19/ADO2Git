---
description: Map ADO variable groups and secure files to GitHub variables, secrets and Key Vault
mode: agent
---

Plan the Library migration. Follow the instructions file.

Inputs: `variable-groups.csv`, `variable-group-variables.csv`, `secure-files.csv`, the pipeline YAML or importer audit for which pipelines reference which group, `docs/migration/waves.md`.

For every variable decide the target:
- plain, one repo, one stage → environment variable
- plain, many repos → org variable with selected repos
- secret → Key Vault secret (preferred; name `<app>-<env>-<variable>` in lowercase with hyphens) read after `azure/login`, or environment secret if no Key Vault exists yet
- Key Vault-linked group → same vault, read from the workflow
- secure file → Key Vault certificate or secret
- not referenced by any pipeline → drop candidate
Note name collisions and names GitHub rejects (secret names allow only letters, digits and `_`, cannot start with `GITHUB_` or a digit) and propose renames.

Write `docs/security/library-plan.md` (table per wave: group, variable, secret?, target, new name, owner Unknown) and `scripts/migration/set-variables-<wave>.ps1` that sets only the plain values with `gh variable set` (dry run by default). For secrets, write a checklist for the owner; never values.
