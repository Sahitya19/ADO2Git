---
description: Map ADO service connections to OIDC identities and write the commands
mode: agent
---

Plan the move from service connections to OIDC. Follow the instructions file.

Inputs: `service-connections.csv`, `service-connection-usage.csv`, `service-connection-roles.csv`, `docs/migration/waves.md`.

1. Classify each connection: Azure RM (secret, certificate, workload identity, managed identity), ACR, Kubernetes, generic/SaaS, GitHub/Azure Repos, other. Unused for 90 days → drop candidate.
2. Propose identities: one user-assigned managed identity per app and environment (`id-gh-<app>-<env>`), never one per subscription shared by many repos (20 federated credential limit). Merge connections that point at the same subscription and environment for the same app.
3. Roles: copy the current role and scope from `service-connection-roles.csv`. Flag Owner, Contributor at subscription scope, and User Access Administrator as "too broad, propose narrower".
4. For each identity write the commands, filled in:
   - `az identity create -g rg-github-oidc -n <name>`
   - `az role assignment create --assignee <principalId> --role <role> --scope <scope>`
   - `az identity federated-credential create -g rg-github-oidc --identity-name <name> -n gh-<repo>-<env> --issuer https://token.actions.cencora.ghe.com --subject repo:ADHPlatform/<repo>:environment:<env> --audiences api://AzureADTokenExchange`
   - `gh variable set AZURE_CLIENT_ID --env <env> --repo ADHPlatform/<repo> --body <clientId> --hostname cencora.ghe.com` (also AZURE_TENANT_ID, AZURE_SUBSCRIPTION_ID)
5. Non-Azure connections: say where each credential goes (Key Vault secret name, or environment secret) and who owns it.
6. Write `docs/security/oidc-plan.md` (tables + commands grouped by wave) and `scripts/migration/oidc-<wave>.ps1` with every command commented out behind a `-DryRun` switch that defaults on.
7. Add a sample workflow job to the plan: `permissions: id-token: write, contents: read`, `azure/login` with the three variables, then `az account show`.
