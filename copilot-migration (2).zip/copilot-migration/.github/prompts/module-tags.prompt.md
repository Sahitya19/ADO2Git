---
description: Backfill version tags for a module from its published package versions
mode: agent
---

Backfill tags for module `${input:module:module name}`. Read-only: print commands, run nothing.

1. Read the Artifacts inventory `versions.csv` rows for this module (and provenance, if collected). If provenance is missing, tell me to run `Get-AdoArtifactsInventory.ps1 -IncludeProvenance` for that feed.
2. For each version: build id → that build's `sourceVersion` commit (ado tools). After `git filter-repo`, SHAs change: map the old commit to the new one by matching author, date and message in `git log` of the split repo.
3. Print `git tag -a v<version> <new sha> -m "Backfilled from Azure Artifacts <feed>/<package> <version>"` for each version with a confident match, then `git push origin --tags`.
4. List versions with no or ambiguous match separately; do not tag them until I pick a commit.
5. Set `.release-please-manifest.json` to the highest backfilled version.
