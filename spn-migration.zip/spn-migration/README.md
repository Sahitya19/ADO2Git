# SPN module: Azure DevOps to GitHub, script first

One script, `Invoke-SpnMigration.ps1`, does the whole SPN move in 13 resumable phases. Copilot is not in the loop, so it costs no tokens. Use Copilot only for the short questions in `docs/COPILOT-GUIDE.md`.

**New here? Open `START-HERE.md` (or `.pdf`) first.**

| File | What it is |
|---|---|
| `Invoke-SpnMigration.ps1` | the orchestrator (Windows PowerShell 5.1 or 7) |
| `spn-migration.config.psd1` | your settings: the only file you edit |
| `templates/` | deploy workflow (OIDC), module CI, OIDC test |
| `docs/FLOW.md` | one-page flow with Mermaid diagrams |
| `docs/ARCHITECTURE.md` | Azure DevOps today vs GitHub target, with a mapping table |
| `docs/CALL-BRIEF.pdf` (+ PNGs) | 4 pages to share: SPN today vs target, platform-wide today vs target, who does what (org admin vs owner) |
| `docs/DEMO-RUNBOOK.md` / `.pdf` | live end-to-end demo for SBX NonProd: commands, expected result, fallback per step |
| `docs/COPILOT-PROMPTS.md` | Ask-mode prompts to regenerate or adapt each file with Copilot |
| `docs/COPILOT-GUIDE.md` | short prompts, plus the MCP setup |
| `docs/MANUAL-STEPS.md` | what someone other than you must do |
| `.vscode/mcp.json`, `tools/Install-TerraformMcp.ps1` | Azure DevOps MCP + Terraform MCP (binary, no Docker) |

## Run it (VDI, `C:\repos\mix\ADO-GIT`)

```powershell
cd C:\repos\mix\ADO-GIT
Expand-Archive .\spn-migration.zip -DestinationPath . -Force
cd .\spn-migration
Set-ExecutionPolicy -Scope Process Bypass
Get-ChildItem -Recurse *.ps1 | Unblock-File

# GitHub: gh only, no PAT. Browser sign-in; the script runs gh auth setup-git so git push uses gh too.
gh auth login --hostname cencora.ghe.com --web --git-protocol https
gh auth status --hostname cencora.ghe.com

# Azure DevOps (read only): az login is enough. Only if az is not installed, use an ADO PAT instead:
az login
#   $s = Read-Host 'ADO PAT' -AsSecureString
#   $env:ADO_PAT = [Runtime.InteropServices.Marshal]::PtrToStringBSTR([Runtime.InteropServices.Marshal]::SecureStringToBSTR($s))

notepad .\spn-migration.config.psd1      # fill the <...> values
.\Invoke-SpnMigration.ps1                # run; run again after each stop
.\Invoke-SpnMigration.ps1 -Status        # where am I
```

It stops three times on purpose:

1. **after `discover`**: open `out/discovery.md`, which lists the SPN files, the manifest line, the module `source` lines, the pipeline tasks and the backend key. Put the paths into the config and run again.
2. **after `tagmap`**: open `out/tag-map.csv`. Each artifact version has the commit it gets tagged on. Rows with an empty `newCommit` get no tag; the `note` column says why. Fill `sourceCommit` by hand if you know it, then `.\Invoke-SpnMigration.ps1 -Phase tagmap -Force`.
3. **after `convert`**: open `out/convert-report.md` for every line changed (manifest, `source = "git::...?ref=vX"`, backend `use_oidc`) and any artifact references left.

Then it writes the workflow, checks with terraform if installed, writes the OIDC commands, and at `push` it shows what it will push and waits for you to type `PUSH`. Nothing is pushed before that, and nothing in Azure DevOps is ever changed.

To redo a phase: `-Phase <name> -Force`. A failure shows the last 20 lines and the log path (`out/logs/<phase>.log`); fix it and run again, and it resumes there.

## Your layout (from the screenshots)

The config is already filled for it. `ADHPlatform/SPN` exists, so only tags are added (`ExistingModuleRepo = $true`). Versions come from the org-scoped feed `ADH-IAC-MODULES`, package `adh-iac-terraform-spn`, and each one is traced to its `module_publish_prd` commit in `Modernization_Terraform`, then matched to the commit in `ADHPlatform/SPN` by identical files, or by message and author time if the files differ. `Deployments/SPN` comes from `Modernization_Terraform`, and the `CoreInfra/<custodian>/<NonProd|Prod>/SPN.tfvars` files and the per-custodian manifests come from `Custodian_Infrastructure_Deployment_Terraform` (`develop`). The deploy style is `manifest-pin`: the manifests keep `0.0.4`, and at run time the workflow reads the custodian's version and clones `SPN` at `v0.0.4` into `Modules/SPN`, where `Deployments/SPN` already points. Three values are marked CHECK in the config: the manifest file name (`sep.json` is a guess), the state key pattern (compare with `.global/backend_config.csv`), and the deploy repo name.

## Things to know

- **What Copilot already pushed.** If `terraform-azurerm-spn` already has commits, preflight stops. Set `ExistingModuleRepo = $true` to keep that history and add only the tags (they are matched by file content, so this works if the earlier push kept history). If it was a flat copy with no history, ask a repo admin to empty the repo and rerun with `$false`.
- **Split method.** `git filter-repo` is used if installed (`pip install --user git-filter-repo`), otherwise `git subtree`, which is built into Portable Git. Both keep history. With filter-repo, a build commit that did not touch `modules/spn` maps to `0000...` in the commit-map; the script then uses the last commit before it that did change the module, and checks the files match.
- **Runners.** Plan, apply and `oidc-test` run on the Cencora VNET group (`AzureRunner` in the config), whose egress IP 52.242.194.21 must be allowed on the state storage account and Key Vault (MANUAL-STEPS row 7). The `checks` job (fmt, validate without backend) and module CI run on `ubuntu-latest`. Every action is pinned to a commit SHA.
- **State key.** `StateKeyPattern` must give the same key the ADO pipeline used (`backendAzureRmKey` in `out/discovery.md`). The PR plan for each tfvars file must say **No changes** before you merge.
- **Secrets.** Copied files are scanned. `push` refuses while a hit remains (`out/secret-scan.csv`): move the value into a GitHub secret and pass it as `TF_VAR_<name>`, or rerun with `-AllowSecrets` if it is a false hit.
- **Prod plans on PRs.** The PR runs one plan per tfvars file in that file's environment. If `prod` has required reviewers, its PR plan waits for an approval too.
- **Not tested on your repos.** It was run end to end against a sample ADO layout (monorepo with two modules, pipelines repo with tfvars, manifest and YAML) with filter-repo, subtree and an existing repo. The ADO REST calls (feed, builds, service connection) and the GitHub Actions run have not been exercised against the real services.

## After the script

Work through `docs/MANUAL-STEPS.md`: send rows 1 to 8 to the people named, run `out\github-setup.ps1`, check the draft PR's plans, merge, then run `oidc-test` and the first apply.
