# Settings for Invoke-SpnMigration.ps1, filled from Harsha's screenshots (17 Nov 2026).
# Values marked CHECK are guesses: "-Phase discover" prints what it finds so you can confirm them without Copilot.
@{
  # ---------- Azure DevOps (source, read only) ----------
  AdoOrg               = 'AnalyticsDataHub'
  AdoProject           = 'Platform'
  ModulesRepoUrl       = 'https://dev.azure.com/AnalyticsDataHub/Platform/_git/Modernization_Terraform'
  ModulesBranch        = 'module_publish_prd'   # branch the SPN Module Publish pipeline builds from
  ModulesRepoLocal     = ''                     # optional: an existing local clone instead of cloning again
  ModulePath           = 'Modules/SPN'          # case matters
  PipelinesRepoUrl     = 'https://dev.azure.com/AnalyticsDataHub/Platform/_git/Custodian_Infrastructure_Deployment_Terraform'
  PipelinesBranch      = 'develop'
  PipelinesRepoLocal   = ''
  AdoPipelineYamlPath  = '.azure-pipelines/Pipeline.ServicePrincipal.yaml'
  ServiceConnectionName = ''                    # CHECK: the azureSubscription / backendServiceArm name in that YAML (discover lists it)

  # ---------- Old artifact versions -> git tags ----------
  VersionSource        = 'feed'                 # feed | builds | csv | none
  Feed                 = 'ADH-IAC-MODULES'
  PackageName          = 'adh-iac-terraform-spn'
  OrgScopedFeed        = $true                  # ADH-IAC-MODULES is an organization-scoped feed
  BuildDefinitionId    = 0
  VersionsCsv          = ''                     # for VersionSource = csv: columns version,sourceCommit
  TagPrefix            = 'v'                    # 0.0.4 -> v0.0.4
  AllowNonSemver       = $false

  # ---------- GitHub (target) ----------
  GitHubHost           = 'cencora.ghe.com'
  GitHubOrg            = 'ADHPlatform'
  ModuleRepoName       = 'SPN'                  # already pushed (24 commits): only tags are added
  ExistingModuleRepo   = $true
  SplitMethod          = 'auto'                 # only used if ExistingModuleRepo = $false
  AddModuleCi          = $false                 # the repo already has .github/workflows; leave it alone

  # GitHub repo that will hold Deployments/SPN, the SPN tfvars, the manifests and the deploy workflow.
  DeployRepoName       = 'Custodian_Infrastructure_Deployment_Terraform'   # CHECK: same name as in ADO; created on push if you are allowed to
  DeployFolder         = ''                     # '' = files keep their ADO paths (CoreInfra/SBX/NonProd/SPN.tfvars, Deployments/SPN/main.tf)
  DeployBranch         = 'migrate/spn'
  # manifest-pin = each custodian's manifest pins the SPN version; the workflow clones the module at tag v<version>
  #                into the folder Deployments/SPN's local source points to (what the ADO pipeline did with the artifact)
  DeployStyle          = 'manifest-pin'
  PipelinesInclude     = @('CoreInfra/*/*/SPN.tfvars')          # CoreInfra/<custodian>/<NonProd|Prod>/SPN.tfvars
  PipelinesExclude     = @('**/.terraform/**', '**/*.tfstate', '**/*.tfstate.backup')
  ModulesRepoInclude   = @('Deployments/SPN/**')
  ManifestPath         = ''
  # Manifest next to each SPN.tfvars: CoreInfra/<custodian>/<NonProd|Prod>/modules_manifest.csv (PipelineName,Module,Version)
  ManifestPathPattern  = '{tfvarsdir}/modules_manifest.csv'
  ManifestMode         = 'keep'
  # Finds the SPN row in the CSV: <PipelineName>,spn,<Version> (Module column case-insensitive). Group "ver" = version.
  # If SPN appears under several PipelineName rows, the first wins; discover warns when they differ.
  ManifestVersionRegex = '(?im)^[^,\r\n]*,\s*"?(?:adh-iac-terraform-)?spn"?\s*,\s*"?(?<ver>\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?)'
  ModuleSourceRegex    = '(?i)spn'

  # ---------- Workflow ----------
  Environments         = @('NonProd-plan', 'NonProd', 'Prod-plan', 'Prod')   # ServicePrincipal.yml: Plan job uses <env>-plan, Apply job <env> (reviewers on Prod). One federated credential each.
  TerraformRoot        = 'Deployments/SPN'
  DefaultTfvars        = 'CoreInfra/SBX/NonProd/SPN.tfvars'   # CHECK: SBX folder name (from build SPN-SBX-NonProd)
  PrPlanInclude        = @('CoreInfra/SBX/NonProd/**')  # demo: PRs plan SBX NonProd only. Use @() to plan every custodian.
  # MUST give the key the ADO pipeline used (see backend_config.csv in discovery.md) or Terraform starts a new state.
  # {env}, {custodian} (CoreInfra/<custodian>/...), {app} = folder of the tfvars, {file} = tfvars name without .tfvars
  StateKeyPattern      = '{custodian}/{env}/spn.tfstate'   # CHECK against backend_config.csv
  # Azure jobs (plan, apply, oidc-test) need the Cencora VNET runner: its egress IP 52.242.194.21 is what the
  # state storage account and Key Vault firewalls must allow. linux-x64-latest is the other label in the group.
  AzureRunner          = '{ group: "cencora", labels: "linux-x64-ubuntu-latest" }'
  PublicRunner         = 'ubuntu-latest'        # fmt / validate / module CI: no Azure access, no VNET minutes
  TerraformVersion     = '1.9.8'

  # ---------- Local ----------
  WorkRoot             = 'C:\repos\mix\ADO-GIT\spn-work'
  RemoteBase           = ''
}
