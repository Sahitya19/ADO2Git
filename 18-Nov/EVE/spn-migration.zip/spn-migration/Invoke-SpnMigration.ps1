﻿<#
.SYNOPSIS
  Moves the SPN Terraform module from Azure DevOps to GitHub (cencora.ghe.com) in resumable phases, with no Copilot needed:
  history split -> artifact versions as git tags -> tfvars copied -> manifest/sources switched to git::...?ref= tags
  -> GitHub Actions workflow with OIDC -> push (only after you type PUSH).

.DESCRIPTION
  Run it again and it carries on from the first phase that is not done. Progress is in out/status.json.
  Phases marked (stop) finish and stop so you can check their report before going on.

    preflight     tools, auth, config, does the target repo already exist
    discover (stop)  lists SPN files, manifest lines, pipeline tasks and backend settings in the pipelines repo
    split         module folder -> its own repo with history (git filter-repo, or git subtree in Portable Git)
    tagmap (stop) artifact version -> build -> source commit -> commit in the new repo  => out/tag-map.csv
    tags          annotated tags v<version> in the new local repo
    modulefiles   adds ci.yml and .gitignore to the module repo (one commit, after the tagged history)
    deploycopy    copies the SPN tfvars and files from the pipelines repo into the deploy repo branch
    convert (stop) manifest + module sources -> git::https://<host>/<org>/<repo>.git?ref=vX, backend use_oidc
    workflow      writes .github/workflows (ServicePrincipal.yml for manifest-pin, else spn-terraform.yml), oidc-test.yml, runner-test.yml
    validate      terraform fmt/validate (skipped if terraform is not installed)
    oidc          writes out/oidc-setup.md, federated-credential JSON files and out/github-setup.ps1
    push          asks you to type PUSH, then pushes the module repo + tags and the deploy branch, opens a draft PR
    verify        compares the tags on GitHub with the tag map

  Nothing in Azure DevOps is changed. Nothing is pushed before the push phase. Git output goes to out/logs/<phase>.log;
  only the last 20 lines are shown when something fails (keeps Copilot context small if you paste an error).

.EXAMPLE
  ./Invoke-SpnMigration.ps1                    # run / resume
  ./Invoke-SpnMigration.ps1 -Status            # show where you are
  ./Invoke-SpnMigration.ps1 -Phase tags -Force # redo one phase (e.g. after editing out/tag-map.csv)
  ./Invoke-SpnMigration.ps1 -Reset             # forget progress (does not delete clones)
#>
[CmdletBinding()]
param(
  [string]$ConfigPath = (Join-Path $PSScriptRoot 'spn-migration.config.psd1'),
  [string]$Phase = '',          # run only this phase
  [switch]$Force,               # rerun a phase that is already done
  [switch]$Status,
  [switch]$Reset,
  [switch]$AllowSecrets         # push even if the secret scan finds something (after you checked it is a false hit)
)

$ErrorActionPreference = 'Stop'
$Kit = $PSScriptRoot
$Out = Join-Path $Kit 'out'
$LogDir = Join-Path $Out 'logs'
$StatusFile = Join-Path $Out 'status.json'
New-Item -ItemType Directory -Force $Out, $LogDir | Out-Null

$Phases = @('preflight', 'discover', 'split', 'tagmap', 'tags', 'modulefiles', 'deploycopy', 'convert', 'workflow', 'validate', 'oidc', 'push', 'verify')
$StopAfter = @('discover', 'tagmap', 'convert')

# ======================================================================== helpers
function Write-Step([string]$m) { Write-Host "  - $m" }
function Write-Utf8([string]$Path, [string]$Text) {
  New-Item -ItemType Directory -Force (Split-Path $Path -Parent) | Out-Null
  [IO.File]::WriteAllText($Path, $Text, (New-Object Text.UTF8Encoding $false))
}
function Read-Text([string]$Path) { return [IO.File]::ReadAllText($Path) }

$script:CurrentLog = Join-Path $LogDir 'run.log'
function Invoke-Native {
  # Runs git/gh/terraform. Output goes to the phase log; returns stdout lines. Throws with the last 20 lines on failure.
  param([string]$Exe, [string[]]$ArgList, [string]$Dir = '', [switch]$NoThrow)
  $old = $ErrorActionPreference; $ErrorActionPreference = 'Continue'
  $exePath = @(Get-Command $Exe -CommandType Application -ErrorAction Stop)[0].Source
  if ($Dir) { Push-Location $Dir }
  try {
    $lines = @(& $exePath @ArgList 2>&1 | ForEach-Object { "$_" } | Where-Object { $_ -ne 'System.Management.Automation.RemoteException' })
    $code = $LASTEXITCODE
  } finally { if ($Dir) { Pop-Location }; $ErrorActionPreference = $old }
  Add-Content -Path $script:CurrentLog -Value (@("> $Exe $($ArgList -join ' ')  [exit $code]") + $lines)
  $script:LastExit = $code
  if ($code -ne 0 -and -not $NoThrow) {
    $tail = ($lines | Select-Object -Last 20) -join "`n"
    throw "$Exe $($ArgList -join ' ') failed (exit $code):`n$tail`n(full output: $script:CurrentLog)"
  }
  return $lines
}
function GitRun { param([Parameter(ValueFromRemainingArguments = $true)][string[]]$a) Invoke-Native -Exe 'git' -ArgList $a }
function GitIn([string]$Dir, [string[]]$a) { Invoke-Native -Exe 'git' -ArgList $a -Dir $Dir }
function GitOk([string]$Dir, [string[]]$a) { Invoke-Native -Exe 'git' -ArgList $a -Dir $Dir -NoThrow | Out-Null; return ($script:LastExit -eq 0) }
function GitOne([string]$Dir, [string[]]$a) { $r = @(GitIn $Dir $a); if ($r.Count) { return $r[0].Trim() } return '' }
function Test-Cmd([string]$n) { return [bool](Get-Command $n -CommandType Application -ErrorAction SilentlyContinue) }

function Get-State {
  if (Test-Path $StatusFile) {
    $o = Get-Content $StatusFile -Raw | ConvertFrom-Json
    $h = @{}; foreach ($p in $o.PSObject.Properties) { $h[$p.Name] = $p.Value }
    return $h
  }
  return @{}
}
function Set-PhaseState([string]$Name, [string]$State, [string]$Note = '') {
  $s = Get-State
  $s[$Name] = [pscustomobject]@{ state = $State; at = (Get-Date).ToString('yyyy-MM-dd HH:mm'); note = $Note }
  Write-Utf8 $StatusFile ($s | ConvertTo-Json -Depth 5)
}
function Get-Data([string]$Key) {
  $p = Join-Path $Out 'data.json'
  if (-not (Test-Path $p)) { return $null }
  $o = Get-Content $p -Raw | ConvertFrom-Json
  return $o.$Key
}
function Set-Data([string]$Key, $Value) {
  $p = Join-Path $Out 'data.json'
  $h = @{}
  if (Test-Path $p) { $o = Get-Content $p -Raw | ConvertFrom-Json; foreach ($x in $o.PSObject.Properties) { $h[$x.Name] = $x.Value } }
  $h[$Key] = $Value
  Write-Utf8 $p ($h | ConvertTo-Json -Depth 6)
}

function ConvertTo-GlobRegex([string]$g) {
  $g = $g.Replace('\', '/')
  $r = [regex]::Escape($g)
  $r = $r.Replace('\*\*/', '(?:.*/)?').Replace('/\*\*', '(?:/.*)?').Replace('\*\*', '.*').Replace('\*', '[^/]*').Replace('\?', '[^/]')
  return '(?i)^' + $r + '$'
}
function Test-Glob([string]$rel, [string[]]$globs) {
  foreach ($g in $globs) { if ($rel -match (ConvertTo-GlobRegex $g)) { return $true } }
  return $false
}
function Get-RepoFiles([string]$Root) {
  # relative paths with forward slashes, .git excluded
  $rootFull = (Resolve-Path $Root).Path.TrimEnd('\', '/')
  Get-ChildItem -Path $rootFull -Recurse -File -Force |
    Where-Object { $_.FullName -notmatch '[\\/]\.git([\\/]|$)' } |
    ForEach-Object { $_.FullName.Substring($rootFull.Length + 1).Replace('\', '/') }
}

$SecretPattern = '(?i)(client_secret|password|passwd|secret|access_key|account_key|sas_token|connection_string|private_key|pat)\s*[=:]\s*"[^"$\{]{6,}"'
# also: JWTs (eyJ...), and Variable,Value CSV rows whose name says token/secret/password/key with a non-empty value
$SecretPattern2 = '(?i)\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}|^\s*[\w.-]*(token|secret|password|passwd|access_key|api_key|private_key)[\w.-]*\s*,\s*[^,\s]{6,}'
function Find-Secrets([string]$Root, [string[]]$RelFiles) {
  $hits = @()
  foreach ($f in $RelFiles) {
    $full = Join-Path $Root $f
    if (-not (Test-Path $full)) { continue }
    $n = 0
    foreach ($line in [IO.File]::ReadAllLines($full)) {
      $n++
      if ($line -match $SecretPattern -or $line -match $SecretPattern2 -or $line -match '(?i)DefaultEndpointsProtocol=|AccountKey=|SharedAccessSignature=|-----BEGIN [A-Z ]*PRIVATE KEY') {
        # never print the value: only the name before the first = : or , separator
        $hits += [pscustomobject]@{ file = $f; line = $n; text = ((($line.Trim() -split '\s*[=:,]\s*', 2)[0]) + ' = ****') }
      }
    }
  }
  return $hits
}

function Get-ManifestFor([string]$Tfvars) {
  # '{tfvarsdir}/modules_manifest.csv' -> CoreInfra/AHP/NonProd/modules_manifest.csv for CoreInfra/AHP/NonProd/SPN.tfvars
  $dir = ($Tfvars -replace '/[^/]*$', '')
  $cust = ($dir -replace '/[^/]*$', '') -replace '^.*/', ''
  return $C.ManifestPathPattern.Replace('\', '/').Replace('{tfvarsdir}', $dir).Replace('{custodian}', $cust)
}
function Get-ManifestVersions([string]$Path) {
  # every SPN version in the file (a module can appear under several PipelineName rows); first one is what the workflow uses
  return @([regex]::Matches((Read-Text $Path), $C.ManifestVersionRegex) | ForEach-Object { $_.Groups['ver'].Value })
}
function Get-AzureRunner {
  # Jobs that reach Azure (state, Key Vault): Cencora VNET runner group. Older configs used RunnerLabels.
  if ($C.AzureRunner) { return $C.AzureRunner }
  if ($C.RunnerLabels) { return $C.RunnerLabels }
  return '{ group: "cencora", labels: "linux-x64-ubuntu-latest" }'
}
function Get-AdoCustodians {
  # "Select Custodian" values of the ADO pipeline (parameter custodianShortName), so the GitHub run form shows the same list
  $yp = ''
  foreach ($r in $SrcPipelines, $SrcModules) { if ($r -and $C.AdoPipelineYamlPath -and (Test-Path (Join-Path $r $C.AdoPipelineYamlPath))) { $yp = Join-Path $r $C.AdoPipelineYamlPath; break } }
  if (-not $yp) { return @() }
  $lines = @(Get-Content $yp); $out = @(); $inParam = $false; $inValues = $false
  foreach ($l in $lines) {
    if ($l -match '^\s*-\s*name:\s*custodianShortName') { $inParam = $true; continue }
    if ($inParam -and -not $inValues) { if ($l -match '^\s*values:\s*$') { $inValues = $true }; if ($l -match '^\s*-\s*name:') { break }; continue }
    if ($inValues) { if ($l -match '^\s*-\s*([A-Za-z0-9_.-]+)\s*$') { $out += $Matches[1] } elseif ($l.Trim()) { break } }
  }
  return $out
}
function Get-DefaultCustodian {
  if ($C.DefaultTfvars -match '^CoreInfra/([^/]+)/') { return $Matches[1] } else { return 'SBX' }
}
function Get-PublicRunner { if ($C.PublicRunner) { return $C.PublicRunner } else { return 'ubuntu-latest' } }
function Get-ManifestRegex {
  # 'CoreInfra/{custodian}/sep.json' -> regex with the custodian folder captured
  return '(?i)^' + [regex]::Escape($C.ManifestPathPattern.Replace('\', '/')).Replace('\{custodian}', '([^/]+)').Replace('\*', '[^/]*') + '$'
}
function Compare-Version([string]$a, [string]$b) {
  # compares the numeric x.y.z part; returns -1/0/1
  $pa = @(($a -replace '^[^\d]*', '' -split '[-+]')[0] -split '\.' | ForEach-Object { [int]("0" + ($_ -replace '\D', '')) })
  $pb = @(($b -replace '^[^\d]*', '' -split '[-+]')[0] -split '\.' | ForEach-Object { [int]("0" + ($_ -replace '\D', '')) })
  for ($i = 0; $i -lt [Math]::Max($pa.Count, $pb.Count); $i++) {
    $x = 0; $y = 0
    if ($i -lt $pa.Count) { $x = $pa[$i] }; if ($i -lt $pb.Count) { $y = $pb[$i] }
    if ($x -lt $y) { return -1 }; if ($x -gt $y) { return 1 }
  }
  return 0
}

# ======================================================================== config
if ($Reset) { Remove-Item $StatusFile -ErrorAction SilentlyContinue; Write-Host 'Progress cleared (clones in WorkRoot kept).'; return }
if (-not (Test-Path $ConfigPath)) { throw "Config not found: $ConfigPath" }
$C = Import-PowerShellDataFile $ConfigPath
$C.ModulePath = $C.ModulePath.Trim('/').Replace('\', '/')
$C.DeployFolder = $C.DeployFolder.Trim('/').Replace('\', '/')
$RemoteBase = $C.RemoteBase; if (-not $RemoteBase) { $RemoteBase = "https://$($C.GitHubHost)/$($C.GitHubOrg)" }
$UseGh = $RemoteBase -like 'https://*'
$ModuleRepoFull = "$($C.GitHubOrg)/$($C.ModuleRepoName)"
$DeployRepoFull = "$($C.GitHubOrg)/$($C.DeployRepoName)"
$ModuleUrl = "$RemoteBase/$($C.ModuleRepoName).git"
$DeployUrl = "$RemoteBase/$($C.DeployRepoName).git"
$ModuleGitSource = "git::https://$($C.GitHubHost)/$ModuleRepoFull.git"
$W = $C.WorkRoot
$SrcModules = $(if ($C.ModulesRepoLocal) { $C.ModulesRepoLocal } else { Join-Path $W 'src-modules' })
$SrcPipelines = $(if ($C.PipelinesRepoLocal) { $C.PipelinesRepoLocal } else { Join-Path $W 'src-pipelines' })
$ModuleRepo = Join-Path $W $C.ModuleRepoName
$DeployRepo = Join-Path $W ("deploy-" + $C.DeployRepoName)
$DeployDir = $(if ($C.DeployFolder) { Join-Path $DeployRepo $C.DeployFolder } else { $DeployRepo })
if ($UseGh) { $env:GH_HOST = $C.GitHubHost }

if ($Status) {
  $s = Get-State
  foreach ($p in $Phases) {
    $e = $s[$p]; $st = 'pending'; $at = ''; $note = ''
    if ($e) { $st = $e.state; $at = $e.at; $note = $e.note }
    '{0,-12} {1,-8} {2,-17} {3}' -f $p, $st, $at, $note | Write-Host
  }
  return
}

function Get-AdoHeaders {
  if (-not $env:ADO_PAT) {
    # no PAT: use your az login session (Entra token for Azure DevOps, resource id 499b84ac-...)
    if (Test-Cmd az) {
      $tok = @(Invoke-Native az @('account', 'get-access-token', '--resource', '499b84ac-1321-427f-aa17-267ca6975798', '--query', 'accessToken', '-o', 'tsv') -NoThrow) | Select-Object -Last 1
      if ($script:LastExit -eq 0 -and $tok) { return @{ Authorization = "Bearer $($tok.Trim())" } }
    }
    throw 'No Azure DevOps sign-in: run "az login" (preferred) or set $env:ADO_PAT (Code, Build, Packaging, Service Connections: Read). Never paste either into Copilot.'
  }
  return @{ Authorization = 'Basic ' + [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$($env:ADO_PAT)")) }
}
function Invoke-AdoGet([string]$Uri) { return Invoke-RestMethod -Uri $Uri -Headers (Get-AdoHeaders) -Method Get -ErrorAction Stop }

function Sync-Clone([string]$Url, [string]$Path, [string]$Branch = '') {
  if (Test-Path (Join-Path $Path '.git')) {
    if (-not (GitOk $Path @('fetch', '--all', '--tags', '--prune', '--quiet'))) { Write-Warning "git fetch failed in $Path; using it as it is." }
  } else {
    if ($Url -match '<') { throw "Fill in the repo URL in the config (found a <placeholder>: $Url)" }
    Write-Step "cloning $Url (full history, can take a while)"
    GitRun clone --quiet $Url $Path | Out-Null
  }
  if ($Branch) {
    # work on the ADO branch the pipelines really use (e.g. module_publish_prd, develop), at its latest commit
    if (-not (GitOk $Path @('rev-parse', '--verify', '--quiet', "origin/$Branch"))) { throw "Branch $Branch not found in $Url" }
    GitIn $Path @('checkout', '--quiet', '-B', $Branch, "origin/$Branch") | Out-Null
  }
}
function Sync-Modules { Sync-Clone $C.ModulesRepoUrl $SrcModules $C.ModulesBranch }
function Sync-Pipelines { Sync-Clone $C.PipelinesRepoUrl $SrcPipelines $C.PipelinesBranch }
function Get-DefaultBranch([string]$Repo) {
  $r = @(Invoke-Native -Exe git -ArgList @('symbolic-ref', '--short', 'refs/remotes/origin/HEAD') -Dir $Repo -NoThrow)
  if ($script:LastExit -eq 0 -and $r.Count) { return ($r[0].Trim() -replace '^origin/', '') }
  return (GitOne $Repo @('rev-parse', '--abbrev-ref', 'HEAD'))
}

# ======================================================================== phases
function Phase-preflight {
  $bad = @()
  if (-not (Test-Cmd git)) { $bad += 'git not on PATH (add PortableGit\cmd to your user PATH)' }
  else { Write-Step ((GitRun --version) -join '') }
  $fr = $false
  if (Test-Cmd git) { Invoke-Native git @('filter-repo', '--version') -NoThrow | Out-Null; $fr = ($script:LastExit -eq 0) }
  Write-Step ("git filter-repo: " + $(if ($fr) { 'available' } else { 'not installed (subtree will be used; fine)' }))
  if ($C.SplitMethod -eq 'filter-repo' -and -not $fr) { $bad += 'SplitMethod = filter-repo but git filter-repo is not installed (pip install git-filter-repo, or use auto)' }
  if (-not (GitOne $Kit @('config', '--global', 'user.email'))) { $bad += 'git config --global user.email is not set (needed for tags and commits)' }
  if ($UseGh) {
    if (-not (Test-Cmd gh)) { $bad += 'gh CLI not on PATH' }
    else {
      Invoke-Native gh @('auth', 'status', '--hostname', $C.GitHubHost) -NoThrow | Out-Null
      if ($script:LastExit -ne 0) { $bad += "gh is not signed in to $($C.GitHubHost): run gh auth login --hostname $($C.GitHubHost) then gh auth setup-git --hostname $($C.GitHubHost)" }
      else {
        Write-Step "gh signed in to $($C.GitHubHost)"
        # git push/clone to GitHub go through gh's credential helper: no GitHub PAT anywhere
        Invoke-Native gh @('auth', 'setup-git', '--hostname', $C.GitHubHost) -NoThrow | Out-Null
        Write-Step "git uses gh for $($C.GitHubHost) (gh auth setup-git)"
      }
    }
  }
  Write-Step ("terraform: " + $(if (Test-Cmd terraform) { 'available' } else { 'not found (validate phase will be skipped; CI still validates)' }))
  if ($C.VersionSource -in @('feed', 'builds')) { try { Get-AdoHeaders | Out-Null; Write-Step 'Azure DevOps sign-in: ok' } catch { $bad += $_.Exception.Message } }
  foreach ($k in 'ModulesRepoUrl', 'PipelinesRepoUrl', 'DeployRepoName') {
    if ($C[$k] -match '<' -and -not ($k -eq 'ModulesRepoUrl' -and $C.ModulesRepoLocal) -and -not ($k -eq 'PipelinesRepoUrl' -and $C.PipelinesRepoLocal)) { $bad += "config $k still has a <placeholder>" }
  }
  if ($C.VersionSource -eq 'feed' -and $C.Feed -match '<') { $bad += 'config Feed still has a <placeholder> (or set VersionSource to builds/csv/none)' }
  New-Item -ItemType Directory -Force $W | Out-Null

  # does the target module repo already have commits?
  $remoteHeads = @(Invoke-Native git @('ls-remote', '--heads', $ModuleUrl) -NoThrow)
  if ($script:LastExit -eq 0 -and ($remoteHeads | Where-Object { $_ -match 'refs/heads/' })) {
    if ($C.ExistingModuleRepo) { Write-Step "$ModuleRepoFull already has branches: will reuse its history and add tags (ExistingModuleRepo = true)" }
    else { $bad += "$ModuleRepoFull already has commits on GitHub (maybe from the Copilot run). Set ExistingModuleRepo = `$true to keep it and only add tags, or ask a repo admin to empty/rename it to redo the split." }
  } else { Write-Step "$ModuleRepoFull is empty or does not exist yet (fine; push phase creates or fills it)" }
  if ($bad.Count) { throw ("Fix these first:`n  * " + ($bad -join "`n  * ")) }
  return 'ok'
}

function Phase-discover {
  Sync-Pipelines
  Sync-Modules
  $md0 = New-Object System.Collections.Generic.List[string]
  # modules repo: deployments that call the module, pipeline YAML there
  $mfiles = @(Get-RepoFiles $SrcModules | Where-Object { $_ -notlike "$($C.ModulePath)/*" })
  $minc = @($mfiles | Where-Object { $C.ModulesRepoInclude -and (Test-Glob $_ $C.ModulesRepoInclude) })
  $md0.Add("## Modules repo: files ModulesRepoInclude copies ($($minc.Count))"); $md0.Add('')
  foreach ($f in $minc) { $md0.Add("- $f") }
  $md0.Add(''); $md0.Add('## Modules repo: module sources matching ModuleSourceRegex (outside the module folder)'); $md0.Add('')
  foreach ($f in @($mfiles | Where-Object { $_ -match '\.tf$' })) {
    foreach ($m in [regex]::Matches((Read-Text (Join-Path $SrcModules $f)), '(?m)^\s*source\s*=\s*"([^"]+)"')) { if ($m.Groups[1].Value -match $C.ModuleSourceRegex) { $md0.Add("- $f : source = `"$($m.Groups[1].Value)`"") } }
  }
  $md0.Add(''); $md0.Add('## Modules repo: pipeline YAML mentioning spn'); $md0.Add('')
  foreach ($f in @($mfiles | Where-Object { $_ -match '\.ya?ml$' -and (Read-Text (Join-Path $SrcModules $_)) -match '(?i)spn' })) { $md0.Add("- $f") }
  # backend config CSV(s): header + rows mentioning spn
  $md0.Add(''); $md0.Add('## Backend config CSV rows mentioning spn (use these for StateKeyPattern and TF_STATE_* variables)'); $md0.Add('')
  foreach ($root in $SrcModules, $SrcPipelines) {
    foreach ($f in @(Get-RepoFiles $root | Where-Object { $_ -match '\.csv$' -and $_ -match '(?i)backend' })) {
      $lines = [IO.File]::ReadAllLines((Join-Path $root $f))
      $md0.Add("- **$(Split-Path $root -Leaf)/$f** header: ``$($lines[0])``  ($($lines.Count - 1) rows)")
      foreach ($l in ($lines | Select-Object -Skip 1 | Where-Object { $_ -match '(?i)spn|\bAHP\b|\bSBX\b' } | Select-Object -First 15)) { $md0.Add("  - ``$l``") }
    }
  }
  # module call blocks in the deployment (shows the local source path the ADO pipeline filled from the artifact)
  $md0.Add(''); $md0.Add('## Module blocks calling SPN (paste this section if you ask for help)'); $md0.Add('')
  foreach ($f in @($mfiles | Where-Object { $_ -match '\.tf$' -and (Test-Glob $_ $C.ModulesRepoInclude) })) {
    foreach ($m in [regex]::Matches((Read-Text (Join-Path $SrcModules $f)), '(?ms)^(module\s+"[^"]+"\s*\{.*?^\})')) { if ($m.Value -match $C.ModuleSourceRegex) { $md0.Add("$f"); $md0.Add('```hcl'); $md0.Add(($m.Value -split "`n" | Select-Object -First 12) -join "`n"); $md0.Add('```') } }
  }
  # per-custodian manifests: which file pins which SPN version
  $md0.Add(''); $md0.Add("## SPN version pinned per manifest (ManifestPathPattern = $($C.ManifestPathPattern))"); $md0.Add('')
  $md0.Add('| tfvars | manifest | SPN version |'); $md0.Add('|---|---|---|')
  $mfs = @()
  foreach ($tvf in @(Get-RepoFiles $SrcPipelines | Where-Object { (Test-Glob $_ $C.PipelinesInclude) })) {
    $f = Get-ManifestFor $tvf; $full = Join-Path $SrcPipelines $f
    if (-not (Test-Path $full)) { $md0.Add("| $tvf | $f | MANIFEST MISSING |"); continue }
    $mfs += $f
    $vs = @(Get-ManifestVersions $full | Sort-Object -Unique)
    $txt = $(if (-not $vs.Count) { 'NOT FOUND: fix ManifestVersionRegex' } elseif ($vs.Count -gt 1) { "SEVERAL: $($vs -join ', ') (first row wins)" } else { $vs[0] })
    $md0.Add("| $tvf | $f | $txt |")
  }
  if (-not $mfs.Count) { $md0.Add('| no file matches ManifestPathPattern | | |') }
  else { $md0.Add(''); $md0.Add("First 25 lines of $($mfs[0]) (to check the regex):"); $md0.Add('```'); $md0.Add(([IO.File]::ReadAllLines((Join-Path $SrcPipelines $mfs[0])) | Select-Object -First 25) -join "`n"); $md0.Add('```') }
  # tfvars per custodian
  $tv = @(Get-RepoFiles $SrcPipelines | Where-Object { (Test-Glob $_ $C.PipelinesInclude) })
  $md0.Add(''); $md0.Add("SPN tfvars found: $($tv.Count) files, $(@($tv | ForEach-Object { ($_ -split '/')[1] } | Sort-Object -Unique).Count) custodians. PR plans (PrPlanInclude): $(@($tv | Where-Object { Test-Glob $_ $C.PrPlanInclude }).Count) files.")
  $md0.Add('')
  $files = @(Get-RepoFiles $SrcPipelines)
  $inc = @($files | Where-Object { (Test-Glob $_ $C.PipelinesInclude) -and -not (Test-Glob $_ $C.PipelinesExclude) })
  $spnNamed = @($files | Where-Object { $_ -match '(?i)spn' })
  $md = New-Object System.Collections.Generic.List[string]
  $md.Add("# Discovery: SPN in the pipelines repo"); $md.Add("")
  $md.Add("Generated $(Get-Date -Format 'dd MMM yyyy HH:mm') from $SrcPipelines. Use it to fill spn-migration.config.psd1, then run the script again."); $md.Add("")
  foreach ($l in $md0) { $md.Add($l) }
  $md.Add("## Pipelines repo: files the PipelinesInclude patterns copy ($($inc.Count))"); $md.Add("")
  foreach ($f in $inc) { $md.Add("- $f") }
  if (-not $inc.Count) { $md.Add("- none: fix PipelinesInclude") }
  $md.Add(""); $md.Add("## Every file with 'spn' in its path ($($spnNamed.Count))"); $md.Add("")
  foreach ($f in ($spnNamed | Select-Object -First 200)) { $md.Add("- $f") }

  # module sources, manifest candidates, pipeline YAML
  $tf = @($files | Where-Object { $_ -match '\.tf$' })
  $srcHits = @(); $backendHits = @()
  foreach ($f in $tf) {
    $t = Read-Text (Join-Path $SrcPipelines $f)
    foreach ($m in [regex]::Matches($t, '(?m)^\s*source\s*=\s*"([^"]+)"')) { if ($m.Groups[1].Value -match $C.ModuleSourceRegex) { $srcHits += "$f : source = `"$($m.Groups[1].Value)`"" } }
    if ($t -match 'backend\s+"azurerm"') { $backendHits += $f }
  }
  $md.Add(""); $md.Add("## Terraform module sources matching ModuleSourceRegex ($($srcHits.Count))"); $md.Add("")
  foreach ($h in $srcHits) { $md.Add("- $h") }
  if (-not $srcHits.Count) { $md.Add("- none: the pipeline probably runs terraform inside the downloaded artifact. Set DeployStyle = 'module-as-root'.") }
  $md.Add(""); $md.Add("## Files with backend `"azurerm`": $($backendHits -join ', ')"); $md.Add("")

  $manifestCands = @($files | Where-Object { $_ -match '(?i)(manifest|modules?|versions?)[^/]*\.(json|ya?ml|txt|psd1|csv|tfvars|auto\.tfvars)$' })
  $md.Add("## Manifest candidates (lines that match ManifestVersionRegex)"); $md.Add("")
  foreach ($f in $manifestCands) {
    $n = 0
    foreach ($line in [IO.File]::ReadAllLines((Join-Path $SrcPipelines $f))) { $n++; if ($line -match $C.ManifestVersionRegex) { $md.Add("- $f line ${n}: ``$($line.Trim())``  -> version $($Matches['ver'])") } }
  }

  $yml = @($files | Where-Object { $_ -match '\.ya?ml$' })
  $ymlSpn = @($yml | Where-Object { $_ -match '(?i)spn' -or (Read-Text (Join-Path $SrcPipelines $_)) -match '(?i)spn' })
  $md.Add(""); $md.Add("## Pipeline YAML that mentions spn ($($ymlSpn.Count)) - pick one for AdoPipelineYamlPath"); $md.Add("")
  foreach ($f in $ymlSpn) {
    $t = Read-Text (Join-Path $SrcPipelines $f)
    $tasks = @([regex]::Matches($t, '(?m)^\s*-?\s*task:\s*(\S+)') | ForEach-Object { $_.Groups[1].Value } | Sort-Object -Unique)
    $back = @([regex]::Matches($t, '(?im)^\s*(backendAzureRm\w+|backendServiceArm|environmentServiceName\w*|azureSubscription|connectedServiceName\w*)\s*:\s*(.+)$') | ForEach-Object { "$($_.Groups[1].Value)=$($_.Groups[2].Value.Trim())" } | Sort-Object -Unique)
    $md.Add("- **$f**"); $md.Add("  - tasks: $($tasks -join ', ')")
    if ($back.Count) { $md.Add("  - connection/backend: $($back -join '; ')") }
  }
  $md.Add(""); $md.Add("## Next"); $md.Add("")
  $md.Add("1. Set PipelinesInclude, ManifestPath, AdoPipelineYamlPath, ServiceConnectionName, DeployStyle and StateKeyPattern in the config.")
  $md.Add("2. StateKeyPattern must give the same state key as backendAzureRmKey above, or Terraform plans to create everything again.")
  $md.Add("3. Run ./Invoke-SpnMigration.ps1 again.")
  Write-Utf8 (Join-Path $Out 'discovery.md') ($md -join "`r`n")
  return "see out/discovery.md ($($inc.Count) files to copy, $($srcHits.Count) module sources)"
}

function Phase-split {
  if ($C.ExistingModuleRepo) {
    if (-not (Test-Path (Join-Path $ModuleRepo '.git'))) { GitRun clone --quiet $ModuleUrl $ModuleRepo | Out-Null }
    else { GitOk $ModuleRepo @('pull', '--ff-only', '--quiet') | Out-Null }
    if (-not (GitOk $ModuleRepo @('rev-parse', '--verify', '--quiet', 'HEAD'))) { GitIn $ModuleRepo @('checkout', '--quiet', 'main') | Out-Null }
    if ((GitOne $ModuleRepo @('rev-parse', '--abbrev-ref', 'HEAD')) -ne 'main') { throw "The existing repo's checked-out branch is not main. Rename it to main on GitHub or check it out by hand in $ModuleRepo." }
    Sync-Modules
    Set-Data 'splitMethod' 'existing'
    return "reused existing $ModuleRepoFull ($(GitOne $ModuleRepo @('rev-list','--count','HEAD')) commits)"
  }
  Sync-Modules
  $branch = $(if ($C.ModulesBranch) { $C.ModulesBranch } else { Get-DefaultBranch $SrcModules })
  $srcRef = "origin/$branch"; if (-not (GitOk $SrcModules @('rev-parse', '--verify', '--quiet', $srcRef))) { $srcRef = $branch }
  if (-not (GitOk $SrcModules @('cat-file', '-e', "${srcRef}:$($C.ModulePath)"))) { throw "Folder $($C.ModulePath) not found on $srcRef in the modules repo. Check ModulePath." }
  $method = $C.SplitMethod
  if ($method -eq 'auto') { Invoke-Native git @('filter-repo', '--version') -NoThrow | Out-Null; $method = $(if ($script:LastExit -eq 0) { 'filter-repo' } else { 'subtree' }) }
  if (Test-Path $ModuleRepo) {
    if (Test-Path (Join-Path $ModuleRepo '.git\filter-repo\already_ran')) { Write-Warning "Rebuilding $ModuleRepo" }
    Remove-Item -Recurse -Force $ModuleRepo
  }
  Write-Step "splitting $($C.ModulePath) from $srcRef with $method"
  if ($method -eq 'filter-repo') {
    GitRun clone --quiet --no-local --single-branch --branch $branch --no-tags $SrcModules $ModuleRepo | Out-Null
    GitIn $ModuleRepo @('filter-repo', '--subdirectory-filter', $C.ModulePath, '--force', '--quiet') | Out-Null
    $cm = Join-Path $ModuleRepo '.git/filter-repo/commit-map'
    Copy-Item $cm (Join-Path $Out 'commit-map.txt') -Force
    Write-Step "filter-repo commit-map saved to out/commit-map.txt (old -> new; 0000... = commit did not touch the module)"
  } else {
    $sha = @(GitIn $SrcModules @('subtree', 'split', "--prefix=$($C.ModulePath)", $srcRef) | Where-Object { $_ -match '^[0-9a-f]{40}$' }) | Select-Object -Last 1
    if (-not $sha) { throw 'git subtree split returned no commit' }
    GitIn $SrcModules @('branch', '-f', "split/$($C.ModuleRepoName)", $sha) | Out-Null
    GitRun clone --quiet --single-branch --branch "split/$($C.ModuleRepoName)" --no-tags $SrcModules $ModuleRepo | Out-Null
    GitIn $ModuleRepo @('remote', 'remove', 'origin') | Out-Null
  }
  $cur = GitOne $ModuleRepo @('rev-parse', '--abbrev-ref', 'HEAD')
  if ($cur -ne 'main') { GitIn $ModuleRepo @('branch', '-m', $cur, 'main') | Out-Null }
  GitOk $ModuleRepo @('remote', 'remove', 'origin') | Out-Null
  GitIn $ModuleRepo @('remote', 'add', 'origin', $ModuleUrl) | Out-Null
  Set-Data 'splitMethod' $method
  return "${method}: $(GitOne $ModuleRepo @('rev-list','--count','main')) commits in $ModuleRepo"
}

function Get-OldVersions {
  $rows = @()
  switch ($C.VersionSource) {
    'csv' {
      foreach ($r in (Import-Csv $C.VersionsCsv)) { $rows += [pscustomobject]@{ version = $r.version.Trim(); published = ''; buildId = ''; sourceCommit = "$($r.sourceCommit)".Trim(); note = 'from csv' } }
    }
    'builds' {
      $u = "https://dev.azure.com/$($C.AdoOrg)/$($C.AdoProject)/_apis/build/builds?definitions=$($C.BuildDefinitionId)&resultFilter=succeeded&`$top=1000&api-version=7.1"
      foreach ($b in (Invoke-AdoGet $u).value) { $rows += [pscustomobject]@{ version = "$($b.buildNumber)"; published = ([datetime]$b.finishTime).ToString('yyyy-MM-dd'); buildId = "$($b.id)"; sourceCommit = $b.sourceVersion; note = "build from $($b.sourceBranch)" } }
    }
    'feed' {
      $scope = $(if ($C.OrgScopedFeed) { '' } else { "/$($C.AdoProject)" })
      $base = "https://feeds.dev.azure.com/$($C.AdoOrg)$scope/_apis/packaging/feeds/$($C.Feed)"
      $pkgs = Invoke-AdoGet "$base/packages?packageNameQuery=$($C.PackageName)&includeAllVersions=true&api-version=7.1"
      $pkg = @($pkgs.value | Where-Object { $_.name -eq $C.PackageName }) | Select-Object -First 1
      if (-not $pkg) { throw "Package '$($C.PackageName)' not found in feed '$($C.Feed)'. Names found: $(@($pkgs.value | ForEach-Object name) -join ', ')" }
      foreach ($v in @($pkg.versions)) {
        $buildId = ''; $commit = ''; $note = ''
        try {
          $prov = Invoke-AdoGet "$base/packages/$($pkg.id)/versions/$($v.id)/provenance?api-version=7.1-preview.1"
          if ($prov.provenance -and $prov.provenance.data) { foreach ($p in $prov.provenance.data.PSObject.Properties) { if ($p.Name -match 'BuildId$') { $buildId = $p.Value } } }
          if ($buildId) {
            $b = Invoke-AdoGet "https://dev.azure.com/$($C.AdoOrg)/$($C.AdoProject)/_apis/build/builds/${buildId}?api-version=7.1"
            $commit = $b.sourceVersion; $note = "build $($b.buildNumber)"
          } else { $note = 'no build in provenance (published by hand?): fill sourceCommit by hand' }
        } catch { $note = "lookup failed (build deleted by retention?): fill sourceCommit by hand. $($_.Exception.Message)" }
        $pub = ''; if ($v.publishDate) { $pub = ([datetime]$v.publishDate).ToString('yyyy-MM-dd') }
        $rows += [pscustomobject]@{ version = $v.version; published = $pub; buildId = "$buildId"; sourceCommit = $commit; note = $note }
      }
    }
    default { }
  }
  return $rows
}

function Phase-tagmap {
  $mapPath = Join-Path $Out 'tag-map.csv'
  $method = Get-Data 'splitMethod'
  $old = @(Get-OldVersions)
  # keep hand edits: if a tag-map exists, its sourceCommit wins where the API had none
  if (Test-Path $mapPath) {
    $prev = @{}; foreach ($r in (Import-Csv $mapPath)) { $prev[$r.version] = $r }
    foreach ($r in $old) { if (-not $r.sourceCommit -and $prev[$r.version] -and $prev[$r.version].sourceCommit) { $r.sourceCommit = $prev[$r.version].sourceCommit; $r.note = 'sourceCommit from your edit' } }
  }
  # commit-map (filter-repo)
  $cmap = @{}
  $cmFile = Join-Path $Out 'commit-map.txt'
  if ($method -eq 'filter-repo' -and (Test-Path $cmFile)) {
    foreach ($l in (Get-Content $cmFile | Select-Object -Skip 1)) { $p = $l -split '\s+'; if ($p.Count -ge 2) { $cmap[$p[0]] = $p[1] } }
  }
  # tree index of the new repo: tree -> commits (newest first)
  $tidx = @{}; $sidx = @{}
  foreach ($l in (GitIn $ModuleRepo @('log', '--format=%H%x09%at%x09%s', 'HEAD'))) {
    $p = $l -split "`t", 3; if ($p.Count -eq 3) { $k = "$($p[1])|$($p[2])"; if (-not $sidx.ContainsKey($k)) { $sidx[$k] = $p[0] } }
  }
  foreach ($l in (GitIn $ModuleRepo @('log', '--format=%H %T %at', 'HEAD'))) {
    $p = $l -split ' '; if ($p.Count -lt 3) { continue }
    if (-not $tidx.ContainsKey($p[1])) { $tidx[$p[1]] = New-Object System.Collections.ArrayList }
    [void]$tidx[$p[1]].Add([pscustomobject]@{ sha = $p[0]; at = [long]$p[2] })
  }
  $semver = '^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?(?:\+[0-9A-Za-z.-]+)?$'
  $out = @(); $seen = @{}
  foreach ($r in $old) {
    if ($seen[$r.version]) { continue }; $seen[$r.version] = $true
    $row = [ordered]@{ version = $r.version; tag = "$($C.TagPrefix)$($r.version)"; published = $r.published; buildId = $r.buildId; sourceCommit = $r.sourceCommit; moduleCommit = ''; newCommit = ''; how = ''; confidence = ''; note = $r.note }
    if ($r.version -notmatch $semver -and -not $C.AllowNonSemver) { $row.note = 'not semver: skipped (AllowNonSemver = $true keeps it)'; $out += [pscustomobject]$row; continue }
    if ($row.tag -match '[\s~^:?*\[\\]|\.\.|@\{|\.lock$|/$') { $row.note = 'not a valid git tag name'; $out += [pscustomobject]$row; continue }
    $sc = $r.sourceCommit
    if (-not $sc) { $row.note = 'no source commit known: put the ADO commit it was built from in sourceCommit, then rerun -Phase tagmap -Force'; $out += [pscustomobject]$row; continue }
    if (-not (GitOk $SrcModules @('cat-file', '-e', "$sc^{commit}"))) {
      GitOk $SrcModules @('fetch', '--quiet', 'origin', $sc) | Out-Null   # PR / deleted-branch builds
      if (-not (GitOk $SrcModules @('cat-file', '-e', "$sc^{commit}"))) { $row.note = "commit $sc not in the modules repo (branch deleted?)"; $out += [pscustomobject]$row; continue }
    }
    $oldTree = ''
    if (GitOk $SrcModules @('cat-file', '-e', "${sc}:$($C.ModulePath)")) { $oldTree = GitOne $SrcModules @('rev-parse', "${sc}:$($C.ModulePath)") }
    else { $row.note = 'module folder did not exist at that commit (moved or renamed?)'; $out += [pscustomobject]$row; continue }
    # the commit that last changed the module at or before the build commit (build commits often only touched other modules)
    $touch = GitOne $SrcModules @('rev-list', '-1', $sc, '--', $C.ModulePath)
    $row.moduleCommit = $touch
    $cand = ''
    if ($cmap.Count -and $touch -and $cmap[$touch] -and $cmap[$touch] -notmatch '^0+$') {
      $cand = $cmap[$touch]
      if ((GitOne $ModuleRepo @('rev-parse', "$cand^{tree}")) -eq $oldTree) { $row.newCommit = $cand; $row.how = 'commit-map'; $row.confidence = 'exact' }
    }
    if (-not $row.newCommit -and $tidx.ContainsKey($oldTree)) {
      $list = @($tidx[$oldTree])
      $touchAt = [long](GitOne $SrcModules @('log', '-1', '--format=%at', $touch))
      $pick = @($list | Where-Object { $_.at -eq $touchAt }) | Select-Object -First 1
      if (-not $pick) { $pick = $list[-1] }   # oldest commit with this content
      $row.newCommit = $pick.sha; $row.how = 'same files (tree match)'
      $row.confidence = $(if ($list.Count -eq 1) { 'exact' } else { "likely ($($list.Count) commits have these files)" })
    }
    if (-not $row.newCommit -and $touch) {
      # last resort: same author time + subject as the commit that last changed the module (repo split by another tool)
      $k = (GitOne $SrcModules @('log', '-1', '--format=%at%x09%s', $touch)) -replace "`t", '|'
      if ($sidx.ContainsKey($k)) { $row.newCommit = $sidx[$k]; $row.how = 'same message + author time'; $row.confidence = 'likely (files differ: check the diff)' }
    }
    if (-not $row.newCommit) { $row.note = "no commit in the new repo matches $sc by files or by message (only on another branch?)" }
    $out += [pscustomobject]$row
  }
  $out = @($out | Sort-Object { $v = $_.version -replace '[-+].*$', ''; ($v -split '\.' | ForEach-Object { '{0:D8}' -f [int]("0" + ($_ -replace '\D', '')) }) -join '.' })
  if ($out.Count) { $out | Export-Csv -NoTypeInformation -Encoding UTF8 $mapPath } else { Write-Utf8 $mapPath 'version,tag,published,buildId,sourceCommit,moduleCommit,newCommit,how,confidence,note' }
  $ok = @($out | Where-Object { $_.newCommit }).Count
  $out | Format-Table version, tag, confidence, note -AutoSize | Out-String -Width 200 | Write-Host
  Write-Host "  Review out/tag-map.csv. Empty newCommit rows get no tag. To fix one, put the ADO commit in sourceCommit and run:  ./Invoke-SpnMigration.ps1 -Phase tagmap -Force"
  return "$ok of $($out.Count) versions mapped (out/tag-map.csv)"
}

function Phase-tags {
  $map = @(Import-Csv (Join-Path $Out 'tag-map.csv') | Where-Object { $_.newCommit })
  $made = 0; $skip = 0
  foreach ($r in $map) {
    $existing = ''
    if (GitOk $ModuleRepo @('rev-parse', '--verify', '--quiet', "refs/tags/$($r.tag)")) { $existing = GitOne $ModuleRepo @('rev-parse', "$($r.tag)^{commit}") }
    if ($existing -eq $r.newCommit) { $skip++; continue }
    if ($existing) { Write-Warning "$($r.tag) already points at $existing, map says $($r.newCommit): left as is. Delete it locally (git tag -d $($r.tag)) and rerun to move it."; $skip++; continue }
    $msg = "$($r.tag): migrated from Azure Artifacts $($C.Feed)/$($C.PackageName) $($r.version)"
    if ($r.buildId) { $msg += " (ADO build $($r.buildId), commit $($r.sourceCommit))" }
    GitIn $ModuleRepo @('tag', '-a', $r.tag, $r.newCommit, '-m', $msg) | Out-Null
    $made++
  }
  return "$made tags created, $skip already there"
}

function Phase-modulefiles {
  if (-not $C.AddModuleCi) { return 'skipped (AddModuleCi = $false)' }
  $ci = Join-Path $ModuleRepo '.github/workflows/ci.yml'
  $changed = $false
  if (-not (Test-Path $ci)) {
    $t = (Read-Text (Join-Path $Kit 'templates/module-ci.yml')).Replace('__PUBLIC_RUNNER__', (Get-PublicRunner)).Replace('__TF_VERSION__', $C.TerraformVersion)
    Write-Utf8 $ci $t; $changed = $true
  }
  $gi = Join-Path $ModuleRepo '.gitignore'
  $want = @('.terraform/', '*.tfstate', '*.tfstate.*', '*.tfplan', 'crash.log', '.terraform.tfstate.lock.info')
  $have = @(); if (Test-Path $gi) { $have = @(Get-Content $gi) }
  $add = @($want | Where-Object { $have -notcontains $_ })
  if ($add.Count) { Write-Utf8 $gi ((@($have) + $add) -join "`n") ; $changed = $true }
  if (-not $changed) { return 'nothing to add' }
  GitIn $ModuleRepo @('add', '.github/workflows/ci.yml', '.gitignore') | Out-Null
  GitIn $ModuleRepo @('commit', '--quiet', '-m', 'ci: add GitHub Actions checks after migration from Azure DevOps') | Out-Null
  return 'committed ci.yml and .gitignore on main (after the tagged history, so old tags are unchanged)'
}

function Phase-deploycopy {
  Sync-Pipelines
  if (-not (Test-Path (Join-Path $DeployRepo '.git'))) {
    Invoke-Native git @('ls-remote', '--heads', $DeployUrl) -NoThrow | Out-Null
    $exists = ($script:LastExit -eq 0)
    if ($exists) { GitRun clone --quiet $DeployUrl $DeployRepo | Out-Null }
    if (-not (Test-Path (Join-Path $DeployRepo '.git'))) {
      Write-Step "$DeployRepoFull not found or empty: starting a new local repo (push phase will try to create it)"
      New-Item -ItemType Directory -Force $DeployRepo | Out-Null
      GitIn $DeployRepo @('init', '--quiet', '-b', 'main') | Out-Null
      GitIn $DeployRepo @('commit', '--quiet', '--allow-empty', '-m', 'chore: start repository') | Out-Null
      GitIn $DeployRepo @('remote', 'add', 'origin', $DeployUrl) | Out-Null
      Set-Data 'deployRepoNew' $true
    }
  }
  if (GitOk $DeployRepo @('rev-parse', '--verify', '--quiet', $C.DeployBranch)) { GitIn $DeployRepo @('switch', '--quiet', $C.DeployBranch) | Out-Null }
  else { GitIn $DeployRepo @('switch', '--quiet', '-c', $C.DeployBranch) | Out-Null }

  $files = @(Get-RepoFiles $SrcPipelines | Where-Object { (Test-Glob $_ $C.PipelinesInclude) -and -not (Test-Glob $_ $C.PipelinesExclude) })
  if ($C.ManifestPath -and ($files -notcontains $C.ManifestPath.Replace('\', '/'))) { $files += $C.ManifestPath.Replace('\', '/') }
  if ($C.ManifestPathPattern) { foreach ($tvf in @($files | Where-Object { $_ -match '\.tfvars$' })) { $m = Get-ManifestFor $tvf; if ((Test-Path (Join-Path $SrcPipelines $m)) -and $files -notcontains $m) { $files += $m } } }
  $fromModules = @()
  if ($C.ModulesRepoInclude -and @($C.ModulesRepoInclude).Count) {
    Sync-Modules
    $fromModules = @(Get-RepoFiles $SrcModules | Where-Object { (Test-Glob $_ $C.ModulesRepoInclude) -and -not (Test-Glob $_ $C.PipelinesExclude) -and $files -notcontains $_ })
  }
  if (-not ($files.Count + $fromModules.Count)) { throw 'PipelinesInclude / ModulesRepoInclude matched no files. Check out/discovery.md and fix the patterns.' }
  foreach ($pair in @(@($files | ForEach-Object { ,@($SrcPipelines, $_) }) + @($fromModules | ForEach-Object { ,@($SrcModules, $_) }))) {
    $dst = Join-Path $DeployDir $pair[1]
    New-Item -ItemType Directory -Force (Split-Path $dst -Parent) | Out-Null
    Copy-Item (Join-Path $pair[0] $pair[1]) $dst -Force
  }
  $files = @($files + $fromModules)
  Set-Data 'copiedFiles' $files
  $hits = @(Find-Secrets $DeployDir $files)
  if ($hits.Count) {
    $hits | Export-Csv -NoTypeInformation -Encoding UTF8 (Join-Path $Out 'secret-scan.csv')
    Write-Warning "$($hits.Count) possible secrets in the copied files (out/secret-scan.csv). Replace each value with a variable (set it as a GitHub secret / TF_VAR_...) before the push phase."
  }
  return "$($files.Count) files copied to $DeployDir on branch $($C.DeployBranch); $($hits.Count) possible secrets"
}

function Get-PinnedVersion {
  $pinned = ''
  if ($C.ManifestPath) {
    $mf = Join-Path $SrcPipelines $C.ManifestPath
    if (Test-Path $mf) { $mm = [regex]::Match((Read-Text $mf), $C.ManifestVersionRegex); if ($mm.Success) { $pinned = $mm.Groups['ver'].Value } }
  }
  if (-not $pinned) {
    $tagged = @(Import-Csv (Join-Path $Out 'tag-map.csv') | Where-Object { $_.newCommit })
    foreach ($r in $tagged) { if (-not $pinned -or (Compare-Version $r.version $pinned) -gt 0) { $pinned = $r.version } }
  }
  return $pinned
}

function Phase-convert {
  $script:convRows = @()
  $files = @(Get-Data 'copiedFiles')
  if ($C.DeployStyle -eq 'manifest-pin') { return (Convert-ManifestPin $files) }
  $pinned = Get-PinnedVersion
  if (-not $pinned) { throw 'No version found: the manifest line did not match ManifestVersionRegex and no tag was mapped.' }
  $ref = "$($C.TagPrefix)$pinned"
  $tags = @(Import-Csv (Join-Path $Out 'tag-map.csv') | Where-Object { $_.newCommit } | ForEach-Object { $_.tag })
  $report = New-Object System.Collections.Generic.List[string]
  $report.Add('# Convert report: artifacts -> git tags'); $report.Add('')
  $report.Add("Pinned SPN version: **$pinned** -> ``${ModuleGitSource}?ref=$ref``")
  if ($tags -notcontains $ref) { $report.Add(''); $report.Add("> WARNING: tag $ref is not in the tag map. Terraform init will fail until that tag exists. Fix out/tag-map.csv or the manifest.") }
  $report.Add(''); $report.Add('| File | Line before | Line after |'); $report.Add('|---|---|---|')
  $n = 0

  # 1. manifest
  if ($C.ManifestPath -and $C.ManifestMode -eq 'ref') {
    $mf = Join-Path $DeployDir $C.ManifestPath
    if (Test-Path $mf) {
      $lines = [IO.File]::ReadAllLines($mf); $done = $false
      for ($i = 0; $i -lt $lines.Count -and -not $done; $i++) {
        if ($lines[$i] -match $C.ManifestVersionRegex -and $lines[$i] -notmatch 'git::') {
          $before = $lines[$i]; $v = $Matches['ver']
          $lines[$i] = $lines[$i].Replace($v, "${ModuleGitSource}?ref=$($C.TagPrefix)$v")
          $report.Add("| $($C.ManifestPath) | ``$($before.Trim())`` | ``$($lines[$i].Trim())`` |"); $n++; $done = $true
        }
      }
      Write-Utf8 $mf (($lines -join "`r`n") + "`r`n")
    }
  }
  # 2. terraform module blocks + backend blocks
  foreach ($f in @($files | Where-Object { $_ -match '\.tf$' })) {
    $p = Join-Path $DeployDir $f
    $t = Read-Text $p; $orig = $t
    $t = [regex]::Replace($t, '(?ms)(module\s+"[^"]+"\s*\{)(.*?)(^\})', {
        param($m)
        $body = $m.Groups[2].Value
        $sm = [regex]::Match($body, '(?m)^(\s*source\s*=\s*)"([^"]+)"')
        if (-not $sm.Success -or $sm.Groups[2].Value -notmatch $C.ModuleSourceRegex -or $sm.Groups[2].Value -match '^git::') { return $m.Value }
        $v = $ref
        $vm = [regex]::Match($body, '(?m)^\s*version\s*=\s*"[~>=<!\s]*([0-9][^"]*)"\s*\r?\n')
        if ($vm.Success) { $v = "$($C.TagPrefix)$($vm.Groups[1].Value.Trim())"; $body = $body.Remove($vm.Index, $vm.Length) }
        $body = $body.Remove($sm.Index, $sm.Length).Insert($sm.Index, "$($sm.Groups[1].Value)`"${ModuleGitSource}?ref=$v`"")
        $script:convRows += "| $f | ``source = `"$($sm.Groups[2].Value)`"`` | ``source = `"${ModuleGitSource}?ref=$v`"`` |"
        return $m.Groups[1].Value + $body + $m.Groups[3].Value
      })
    $t = [regex]::Replace($t, '(?ms)(backend\s+"azurerm"\s*\{)(.*?)(\})', {
        param($m)
        $body = $m.Groups[2].Value; $add = ''
        if ($body -notmatch 'use_oidc') { $add += "`n    use_oidc         = true" }
        if ($body -notmatch 'use_azuread_auth') { $add += "`n    use_azuread_auth = true" }
        if (-not $add) { return $m.Value }
        if ($body -notmatch '\n') { $body = "`n  " }   # empty block: backend "azurerm" {}
        $script:convRows += "| $f | ``backend `"azurerm`"`` | ``+ use_oidc = true, use_azuread_auth = true`` |"
        return $m.Groups[1].Value + $add + $body + $m.Groups[3].Value
      })
    if ($t -ne $orig) { Write-Utf8 $p $t }
  }
  foreach ($r in $script:convRows) { $report.Add($r); $n++ }
  # 3. module-as-root: the workflow reads this one-line file
  if ($C.DeployStyle -eq 'module-as-root') {
    Write-Utf8 (Join-Path $DeployDir 'spn.ref') "$ref`n"
    $report.Add("| spn.ref (new) | | ``$ref`` (the workflow clones the module at this tag) |"); $n++
  }
  $left = @()
  foreach ($f in $files) {
    $p = Join-Path $DeployDir $f
    if (-not (Test-Path $p)) { continue }
    $ln = 0
    foreach ($line in [IO.File]::ReadAllLines($p)) { $ln++; if ($line -match '(?i)(UniversalPackages|DownloadPackage|pkgs\.dev\.azure\.com|_packaging|artifactFeed|vstsFeed)') { $left += "- $f line ${ln}: ``$($line.Trim())``" } }
  }
  $report.Add(''); $report.Add('## Artifact references still left (fix by hand or delete)'); $report.Add('')
  if ($left.Count) { foreach ($l in $left) { $report.Add($l) } } else { $report.Add('- none') }
  Write-Utf8 (Join-Path $Out 'convert-report.md') ($report -join "`r`n")
  return "$n changes, $($left.Count) artifact references left (out/convert-report.md)"
}
$script:convRows = @()

function Convert-ManifestPin($files) {
  # Each custodian's manifest keeps its pinned version (0.0.4). The workflow turns it into tag v0.0.4 and clones the
  # module at that tag into the folder the deployment's local source points to, exactly where the ADO pipeline
  # unpacked the artifact. So the .tf source line stays; only the backend block gains use_oidc.
  $tags = @(Import-Csv (Join-Path $Out 'tag-map.csv') | Where-Object { $_.newCommit } | ForEach-Object { $_.tag })
  $r = New-Object System.Collections.Generic.List[string]
  $r.Add('# Convert report: artifacts -> git tags (manifest-pin)'); $r.Add('')
  $r.Add("Manifests keep their versions. At run time the workflow reads the SPN version for the custodian, and clones ``$ModuleUrl`` at ``$($C.TagPrefix)<version>``."); $r.Add('')
  $r.Add('| manifest | SPN version | tag | tag exists |'); $r.Add('|---|---|---|---|')
  $missing = 0
  foreach ($tvf in @($files | Where-Object { $_ -match '\.tfvars$' })) {
    $f = Get-ManifestFor $tvf; $full = Join-Path $DeployDir $f
    if (-not (Test-Path $full)) { $r.Add("| $f | manifest missing | | NO |"); $missing++; continue }
    $vs = @(Get-ManifestVersions $full)
    if (-not $vs.Count) { $r.Add("| $f | not found | | NO: fix ManifestVersionRegex |"); $missing++; continue }
    $tg = "$($C.TagPrefix)$($vs[0])"; $ok = $tags -contains $tg; if (-not $ok) { $missing++ }
    $more = ''; if (@($vs | Sort-Object -Unique).Count -gt 1) { $more = " (file also has $(@($vs | Select-Object -Skip 1) -join ', '))" }
    $r.Add("| $f | $($vs[0])$more | $tg | $(if ($ok) { 'yes' } else { 'NO: this custodian/env cannot plan until the tag exists' }) |")
  }
  # local module source in the deployment
  $src = ''
  foreach ($f in @($files | Where-Object { $_ -match '\.tf$' })) {
    $p = Join-Path $DeployDir $f; $tx = Read-Text $p
    foreach ($m in [regex]::Matches($tx, '(?ms)module\s+"[^"]+"\s*\{.*?^\}')) {
      $sm = [regex]::Match($m.Value, '(?m)^\s*source\s*=\s*"([^"]+)"')
      if ($sm.Success -and $sm.Groups[1].Value -match $C.ModuleSourceRegex -and $sm.Groups[1].Value -notmatch '^(git::|https?:)') { $src = $sm.Groups[1].Value }
    }
    $new = [regex]::Replace($tx, '(?ms)(backend\s+"azurerm"\s*\{)(.*?)(\})', {
        param($m)
        $body = $m.Groups[2].Value; $add = ''
        if ($body -notmatch 'use_oidc') { $add += "`n    use_oidc         = true" }
        if ($body -notmatch 'use_azuread_auth') { $add += "`n    use_azuread_auth = true" }
        if (-not $add) { return $m.Value }
        if ($body -notmatch '\n') { $body = "`n  " }
        $script:convRows += "- $f : backend azurerm + use_oidc = true, use_azuread_auth = true"
        return $m.Groups[1].Value + $add + $body + $m.Groups[3].Value
      })
    if ($new -ne $tx) { Write-Utf8 $p $new }
  }
  if (-not $src) { throw 'No local module source matching ModuleSourceRegex found in the copied .tf files. Check ModulesRepoInclude / ModuleSourceRegex.' }
  Set-Data 'moduleLocalSource' $src
  $r.Add(''); $r.Add("Deployment source ``$src`` stays; the workflow clones the tagged module there."); $r.Add('')
  foreach ($x in $script:convRows) { $r.Add($x) }
  Write-Utf8 (Join-Path $Out 'convert-report.md') ($r -join "`r`n")
  return "manifest-pin: module source $src kept, $missing manifests without a matching tag (out/convert-report.md)"
}

function Phase-workflow {
  $wfDir = Join-Path $DeployRepo '.github/workflows'
  $envOpts = ($C.Environments | ForEach-Object { "          - $_" }) -join "`n"
  $dir = $(if ($C.DeployFolder) { $C.DeployFolder } else { '.' })
  # one PR plan per copied tfvars file; environment = first configured environment name found in its path
  $matrix = @()
  foreach ($f in @(@(Get-Data 'copiedFiles') | Where-Object { $_ -match '\.tfvars$' -and $_ -notmatch '\.auto\.tfvars$' -and (-not $C.PrPlanInclude -or (Test-Glob $_ $C.PrPlanInclude)) })) {
    $parts = @($f.ToLower() -split '[/._-]'); $e = $C.Environments[0]
    foreach ($x in $C.Environments) { if ($parts -contains $x.ToLower()) { $e = $x; break } }
    $matrix += [ordered]@{ env = $e; tfvars = $f }
  }
  if (-not $matrix.Count) { $matrix = @([ordered]@{ env = $C.Environments[0]; tfvars = $C.DefaultTfvars }) }
  $matrixJson = (ConvertTo-Json -InputObject @($matrix) -Compress).Replace("'", "''")
  $t = Read-Text (Join-Path $Kit 'templates/spn-terraform.yml')
  $t = $t.Replace('__PR_MATRIX__', $matrixJson)
  if ($C.DeployFolder) { $paths = @("$($C.DeployFolder)/**") }
  else { $paths = @(@(Get-Data 'copiedFiles') | ForEach-Object { $s = $_ -split '/'; if ($s.Count -gt 2) { "$($s[0])/$($s[1])/**" } else { $_ } } | Sort-Object -Unique) }
  $t = $t.Replace('__PR_PATHS__', (($paths + '.github/workflows/spn-terraform.yml' | ForEach-Object { "`"$_`"" }) -join ', '))
  $pyRx = $C.ManifestVersionRegex.Replace('(?<ver>', '(?P<ver>').Replace("'", "''")
  $t = $t.Replace('__MANIFEST_PATTERN__', $C.ManifestPathPattern).Replace('__MANIFEST_REGEX__', $pyRx).Replace('__MODULE_LOCAL_SOURCE__', "$(Get-Data 'moduleLocalSource')").Replace('__TAG_PREFIX__', $C.TagPrefix)
  $t = $t.Replace('__DEPLOY_DIR__', $dir).Replace('__ENV_OPTIONS__', $envOpts).Replace('__DEFAULT_ENV__', $C.Environments[0]).
    Replace('__DEFAULT_TFVARS__', $C.DefaultTfvars).Replace('__AZURE_RUNNER__', (Get-AzureRunner)).Replace('__PUBLIC_RUNNER__', (Get-PublicRunner)).Replace('__STATE_KEY_PATTERN__', $C.StateKeyPattern).
    Replace('__DEPLOY_STYLE__', $C.DeployStyle).Replace('__GH_HOST__', $C.GitHubHost).Replace('__MODULE_REPO__', $ModuleRepoFull).Replace('__MODULE_REPO_NAME__', $C.ModuleRepoName).Replace('__TF_VERSION__', $C.TerraformVersion).Replace('__TF_ROOT__', $C.TerraformRoot)
  if ($C.DeployStyle -eq 'manifest-pin') {
    # ADO-aligned: manual ServicePrincipal workflow (Plan > approval > Apply) + shared composite action, copied from repos/
    $src = Join-Path $Kit 'repos/Custodian_Infrastructure_Deployment_Terraform/.github'
    Get-ChildItem $src -Recurse -File | ForEach-Object {
      $rel = $_.FullName.Substring($src.Length).TrimStart('\', '/')
      $dst = Join-Path (Join-Path $DeployRepo '.github') $rel
      New-Item -ItemType Directory -Force -Path (Split-Path $dst) | Out-Null
      $x = Read-Text $_.FullName
      if ($rel -like '*ServicePrincipal.yml') {
        $x = $x.Replace('TF_ROOT: Deployments/SPN', "TF_ROOT: $($C.TerraformRoot)").Replace('default: "SBX"', "default: `"$(Get-DefaultCustodian)`"")
        $cust = @(Get-AdoCustodians)
        if ($cust.Count) {
          if ($cust -notcontains (Get-DefaultCustodian)) { $cust += (Get-DefaultCustodian) }
          $x = [regex]::Replace($x, '(?m)^(\s*options: )\[AHP, [^\]]*\]', ('${1}[' + (($cust | Sort-Object -Unique) -join ', ') + ']'))
        }
      }
      Write-Utf8 $dst $x
    }
    $old = Join-Path $wfDir 'spn-terraform.yml'; if (Test-Path $old) { Remove-Item $old -Force }
    $wfName = 'ServicePrincipal.yml'
  } else {
    Write-Utf8 (Join-Path $wfDir 'spn-terraform.yml') $t
    $wfName = 'spn-terraform.yml'
  }
  # shared backend-config action (subscription, state, Key Vault from .global/backend_config.csv) is needed by every workflow
  $beSrc = Join-Path $Kit 'repos/Custodian_Infrastructure_Deployment_Terraform/.github/actions/backend-config'
  $beDst = Join-Path $DeployRepo '.github/actions/backend-config'
  New-Item -ItemType Directory -Force $beDst | Out-Null
  Copy-Item (Join-Path $beSrc '*') $beDst -Force
  if (-not (Test-Path (Join-Path $DeployRepo 'common/terraform.backend_config.csv'))) {
    Write-Warning 'common/terraform.backend_config.csv is not in the deploy repo: rerun -Phase deploycopy -Force (config PipelinesInclude) or the workflows fall back to the AZURE_SUBSCRIPTION_ID / TF_STATE_* variables.'
  }
  $o = (Read-Text (Join-Path $Kit 'templates/oidc-test.yml')).Replace('__AZURE_RUNNER__', (Get-AzureRunner)).Replace('__PUBLIC_RUNNER__', (Get-PublicRunner)).Replace('__DEFAULT_ENV__', $C.Environments[0]).Replace('__DEFAULT_CUSTODIAN__', (Get-DefaultCustodian)).Replace('__ENV_CHOICES__', ($C.Environments -join ', '))
  Write-Utf8 (Join-Path $wfDir 'oidc-test.yml') $o
  # runner-test: needs no Azure login; matrix value is JSON, so the runner object is written as a quoted JSON string
  $azr = (Get-AzureRunner).Trim()
  if ($azr.StartsWith('{')) { $azJson = ($azr -replace '([{,]\s*)(\w+)\s*:', '$1"$2":') } else { $azJson = '"' + $azr + '"' }
  $rt = (Read-Text (Join-Path $Kit 'templates/runner-test.yml')).Replace('__AZURE_RUNNER_JSON__', "'" + $azJson + "'").Replace('__PUBLIC_RUNNER__', (Get-PublicRunner)).Replace('__GH_HOST__', $C.GitHubHost)
  Write-Utf8 (Join-Path $wfDir 'runner-test.yml') $rt

  # what the old ADO pipeline did that this workflow does not cover
  $md = New-Object System.Collections.Generic.List[string]
  $md.Add('# Old ADO pipeline vs new workflow'); $md.Add('')
  $yp = ''
  if ($C.AdoPipelineYamlPath) { foreach ($r in $SrcPipelines, $SrcModules) { if (-not $yp -and (Test-Path (Join-Path $r $C.AdoPipelineYamlPath))) { $yp = Join-Path $r $C.AdoPipelineYamlPath } } }
  if ($yp) {
    $y = Read-Text $yp
    $known = @{
      'TerraformInstaller' = 'hashicorp/setup-terraform'; 'TerraformTaskV' = 'terraform init/plan/apply steps'; 'TerraformCLI' = 'terraform init/plan/apply steps'
      'UniversalPackages' = 'removed: module comes from the git tag'; 'DownloadPackage' = 'removed: module comes from the git tag'
      'AzureCLI' = 'az CLI after azure/login (add the script as a run step)'; 'AzurePowerShell' = 'add azure/powershell or pwsh run step after login'
      'PublishPipelineArtifact' = 'actions/upload-artifact (plan file)'; 'DownloadPipelineArtifact' = 'actions/download-artifact (plan file)'
      'CopyFiles' = 'not needed'; 'Bash' = 'run step'; 'PowerShell' = 'run step (shell: pwsh)'; 'replacetokens' = 'TF_VAR_ env vars or -var'
      'AzureKeyVault' = 'az keyvault secret show in a run step after login, or GitHub secrets'; 'ManualValidation' = 'environment required reviewers'
    }
    $md.Add('| ADO task | In the new workflow |'); $md.Add('|---|---|')
    foreach ($task in ([regex]::Matches($y, '(?m)^\s*-?\s*task:\s*(\S+)') | ForEach-Object { $_.Groups[1].Value } | Sort-Object -Unique)) {
      $hit = 'NOT CONVERTED: add a step by hand'
      foreach ($k in $known.Keys) { if ($task -like "$k*") { $hit = $known[$k] } }
      $md.Add("| $task | $hit |")
    }
    foreach ($m in [regex]::Matches($y, '(?im)^\s*-\s*group:\s*(.+)$')) { $md.Add(''); $md.Add("Variable group **$($m.Groups[1].Value.Trim())**: recreate its values as environment variables/secrets (values cannot be exported).") }
    foreach ($m in [regex]::Matches($y, '(?im)^\s*(backendAzureRm\w+)\s*:\s*(.+)$')) { $md.Add("- $($m.Groups[1].Value) = $($m.Groups[2].Value.Trim())  (put in GitHub environment variables TF_STATE_*)") }
  } else { $md.Add('AdoPipelineYamlPath not set: nothing compared.') }
  Write-Utf8 (Join-Path $Out 'pipeline-compare.md') ($md -join "`r`n")
  return "wrote .github/workflows/$wfName, oidc-test.yml and runner-test.yml (see out/pipeline-compare.md)"
}

function Phase-validate {
  if (-not (Test-Cmd terraform)) { return 'skipped: terraform not installed here (the module CI and the PR plan validate on GitHub)' }
  $r = @()
  Invoke-Native terraform @('fmt', '-check', '-recursive', '-no-color') -Dir $ModuleRepo -NoThrow | Out-Null
  $r += "module fmt: " + $(if ($script:LastExit -eq 0) { 'ok' } else { 'needs terraform fmt (CI will fail; fix in a PR after migration, tags stay as built)' })
  Invoke-Native terraform @('init', '-backend=false', '-input=false', '-no-color') -Dir $ModuleRepo -NoThrow | Out-Null
  if ($script:LastExit -eq 0) {
    Invoke-Native terraform @('validate', '-no-color') -Dir $ModuleRepo -NoThrow | Out-Null
    $r += "module validate: " + $(if ($script:LastExit -eq 0) { 'ok' } else { 'FAILED (see log)' })
  } else { $r += 'module init failed (provider download blocked?) - see log' }
  Invoke-Native terraform @('fmt', '-check', '-recursive', '-no-color') -Dir $DeployDir -NoThrow | Out-Null
  $r += "deploy fmt: " + $(if ($script:LastExit -eq 0) { 'ok' } else { 'run terraform fmt -recursive in the deploy folder' })
  Remove-Item -Recurse -Force (Join-Path $ModuleRepo '.terraform'), (Join-Path $ModuleRepo '.terraform.lock.hcl') -ErrorAction SilentlyContinue
  return ($r -join '; ')
}

function Phase-oidc {
  $issuer = "https://token.actions.$($C.GitHubHost)"
  $app = '<appId (client id) of the identity>'; $tenant = '<tenantId>'; $sub = '<subscriptionId>'; $scInfo = 'ServiceConnectionName not set'
  if ($C.ServiceConnectionName) {
    try {
      $u = "https://dev.azure.com/$($C.AdoOrg)/$($C.AdoProject)/_apis/serviceendpoint/endpoints?endpointNames=$([uri]::EscapeDataString($C.ServiceConnectionName))&api-version=7.1"
      $ep = @((Invoke-AdoGet $u).value) | Select-Object -First 1
      if ($ep) {
        $app = $ep.authorization.parameters.serviceprincipalid; $tenant = $ep.authorization.parameters.tenantid; $sub = $ep.data.subscriptionId
        $scInfo = "$($ep.name): scheme $($ep.authorization.scheme), scope $($ep.data.scopeLevel), subscription $($ep.data.subscriptionName)"
      }
    } catch { $scInfo = "could not read the service connection: $($_.Exception.Message)" }
  }
  $subjectNote = 'default subject format'
  if ($UseGh) {
    $subOut = @(Invoke-Native gh @('api', "repos/$DeployRepoFull/actions/oidc/customization/sub") -NoThrow)
    if ($script:LastExit -eq 0 -and ($subOut -join '') -match '"use_default"\s*:\s*false') { $subjectNote = "CUSTOM subject claim on this repo: $($subOut -join ' ') - change the subjects below to match" }
  }
  $md = New-Object System.Collections.Generic.List[string]
  $md.Add('# OIDC setup for the SPN workflow'); $md.Add('')
  $md.Add("Service connection: $scInfo  "); $md.Add("Issuer: ``$issuer``  Audience: ``api://AzureADTokenExchange``  Subject check: $subjectNote"); $md.Add('')
  $md.Add('## 1. Entra admin or app owner (not Harsha): add federated credentials'); $md.Add('')
  $md.Add('Simplest: add them to the same app registration the ADO service connection uses, so the roles and the Microsoft Graph permissions an SPN module needs (for example Application.ReadWrite.OwnedBy) carry over unchanged. Max 20 federated credentials per app.'); $md.Add('')
  $md.Add('```powershell')
  foreach ($e in @($C.Environments)) {
    $subject = "repo:${DeployRepoFull}:environment:$e"
    $json = [ordered]@{ name = "gh-$($C.DeployRepoName)-$e"; issuer = $issuer; subject = $subject; description = "GitHub Actions $DeployRepoFull $e"; audiences = @('api://AzureADTokenExchange') } | ConvertTo-Json
    Write-Utf8 (Join-Path $Out "fic-$e.json") $json
    $md.Add("az ad app federated-credential create --id $app --parameters out/fic-$e.json")
  }
  $md.Add('```'); $md.Add('')
  $md.Add('Pull-request plans run in the `' + $C.Environments[0] + '` environment, so they use that environment''s credential. Every job names an environment, so no branch or pull_request subjects are needed.'); $md.Add('')
  $md.Add('Also for the admin: the identity needs **Storage Blob Data Contributor** on the state storage account (use_azuread_auth = true means no storage keys).'); $md.Add('')
  $md.Add('## 2. Harsha (repo admin): environments, variables, secret'); $md.Add('')
  $md.Add('Run `./out/github-setup.ps1` after the push phase. Then set required reviewers on Prod (and NonProd if ADO had an approval there) in Settings > Environments.'); $md.Add('')
  $md.Add('## 3. Test'); $md.Add('')
  $md.Add('The draft PR runs the plan job, which logs in with OIDC: that is the first test. oidc-test.yml and runner-test.yml also run once on the draft PR that adds them. To start them by hand they must be on main (GitHub only runs manual workflows that exist on the default branch):'); $md.Add('')
  $md.Add("gh workflow run oidc-test --repo $DeployRepoFull -f environment=$($C.Environments[0]) ; gh run watch --repo $DeployRepoFull")
  $md.Add(''); $md.Add('AADSTS70021 / no matching federated identity = issuer or subject wrong (subject is case sensitive). No subscriptions found = role missing or not yet applied.')
  Write-Utf8 (Join-Path $Out 'oidc-setup.md') ($md -join "`r`n")

  $ps = New-Object System.Collections.Generic.List[string]
  $ps.Add("# Creates the GitHub environments and variables for $DeployRepoFull (repo admin is enough). Review, then run.")
  $ps.Add("`$env:GH_HOST = '$($C.GitHubHost)'"); $ps.Add("`$repo = '$DeployRepoFull'")
  $ps.Add("`$vars = @{ AZURE_CLIENT_ID = '$app'; AZURE_TENANT_ID = '$tenant'; TF_STATE_CONTAINER = '<state container, e.g. tfstate>' }   # set once; subscription, RG and storage account come from common/terraform.backend_config.csv")
  $ps.Add("foreach (`$e in @('$($C.Environments -join "','")')) {")
  $ps.Add("  gh api -X PUT `"repos/`$repo/environments/`$e`" | Out-Null")
  $ps.Add("  foreach (`$k in `$vars.Keys) { gh variable set `$k --env `$e --repo `$repo --body `$vars[`$k] }   # change per environment if they differ")
  $ps.Add("}")
  $ps.Add("# Repo-level copies for pull-request plans (no environment on PR jobs)")
  $ps.Add("foreach (`$k in `$vars.Keys) { gh variable set `$k --repo `$repo --body `$vars[`$k] }")
  $ps.Add("# Read-only deploy key so the workflow can clone $ModuleRepoFull (no PAT). Repo admin on both repos is enough.")
  $ps.Add("`$k = Join-Path `$env:TEMP 'spn-deploy-key'; Remove-Item `"`$k*`" -ErrorAction SilentlyContinue")
  $ps.Add("if (`$PSVersionTable.PSVersion.Major -ge 7) { ssh-keygen -t ed25519 -N '' -C 'spn-module-read' -f `$k -q } else { ssh-keygen -t ed25519 -N '""""' -C 'spn-module-read' -f `$k -q }   # empty passphrase")
  $ps.Add("gh repo deploy-key add `"`$k.pub`" --repo $ModuleRepoFull --title 'spn-workflow-read'      # read-only by default")
  $ps.Add("(`"# repo: $($C.ModuleRepoName)`n`" + (Get-Content `$k -Raw)) | gh secret set MODULES_DEPLOY_KEYS --repo `$repo   # add one '# repo: <Name>' block per module repo")
  $ps.Add("Remove-Item `"`$k*`"                                                                   # the private key now lives only in the secret")
  $ps.Add("# Preferred instead of deploy keys: an ORG-OWNED GitHub App (org owner / App manager) with Contents: read on the module repos;")
  $ps.Add("#   org variable MODULES_APP_ID and org secret MODULES_APP_KEY. Never a personal token or a personally owned app.")
  Write-Utf8 (Join-Path $Out 'github-setup.ps1') ($ps -join "`r`n")
  return 'wrote out/oidc-setup.md, out/fic-*.json, out/github-setup.ps1'
}

function Phase-push {
  $modTags = @(GitIn $ModuleRepo @('tag', '--list')).Count
  $commitsAhead = GitOne $ModuleRepo @('rev-list', '--count', 'main')
  # secret gate on what is about to be committed in the deploy repo
  $files = @(Get-Data 'copiedFiles')
  $hits = @(Find-Secrets $DeployDir $files)
  if ($hits.Count -and -not $AllowSecrets) {
    $hits | Format-Table -AutoSize | Out-String | Write-Host
    throw "Possible secrets still in $($hits.Count) lines. Replace them with variables, or rerun with -AllowSecrets if they are false hits."
  }
  Write-Host ""
  Write-Host "About to push:"
  Write-Host "  1. $ModuleUrl  main ($commitsAhead commits) + $modTags tags"
  Write-Host "  2. $DeployUrl  branch $($C.DeployBranch) (SPN files + workflows) and open a draft pull request"
  $ans = Read-Host "Type PUSH to continue (anything else stops)"
  if ($ans -cne 'PUSH') { throw 'Stopped before pushing. Nothing was sent.' }

  # module repo
  if ($UseGh) {
    Invoke-Native gh @('repo', 'view', $ModuleRepoFull, '--json', 'name') -NoThrow | Out-Null
    if ($script:LastExit -ne 0) {
      Invoke-Native gh @('repo', 'create', $ModuleRepoFull, '--internal', '--description', 'Terraform SPN module, migrated from Azure DevOps with history') -NoThrow | Out-Null
      if ($script:LastExit -ne 0) { throw "Cannot create $ModuleRepoFull (repo-level rights only?). Ask an org owner to create it EMPTY (no README) and give you admin, then rerun." }
    }
  }
  GitIn $ModuleRepo @('push', '--quiet', '-u', 'origin', 'main') | Out-Null
  GitIn $ModuleRepo @('push', '--quiet', 'origin', '--tags') | Out-Null
  Write-Step "module repo pushed"

  # deploy repo
  if ($UseGh -and (Get-Data 'deployRepoNew')) {
    Invoke-Native gh @('repo', 'view', $DeployRepoFull, '--json', 'name') -NoThrow | Out-Null
    if ($script:LastExit -ne 0) {
      Invoke-Native gh @('repo', 'create', $DeployRepoFull, '--internal') -NoThrow | Out-Null
      if ($script:LastExit -ne 0) { throw "Cannot create $DeployRepoFull. Ask an org owner to create it empty, then rerun -Phase push -Force." }
    }
    GitIn $DeployRepo @('push', '--quiet', 'origin', 'main') | Out-Null
  }
  $add = @('.github')
  if ($C.DeployFolder) { $add += $C.DeployFolder } else { $add += $files }
  GitIn $DeployRepo (@('add', '--') + $add) | Out-Null
  if (-not (GitOk $DeployRepo @('diff', '--cached', '--quiet'))) {
    GitIn $DeployRepo @('commit', '--quiet', '-m', "feat(spn): move SPN tfvars and deploy workflow from Azure DevOps; module from git tag") | Out-Null
  }
  GitIn $DeployRepo @('push', '--quiet', '-u', 'origin', $C.DeployBranch) | Out-Null
  $pr = ''
  if ($UseGh) {
    $body = "SPN deployment moved from Azure DevOps.`n`n- module source: ${ModuleGitSource}?ref=<tag> (was an Azure Artifacts package)`n- workflow: .github/workflows/ (OIDC, no secrets; ServicePrincipal.yml mirrors Pipeline.ServicePrincipal.yaml)`n`nBefore merge: plan for every tfvars must show **no changes** against the existing state."
    $r = @(Invoke-Native gh @('pr', 'create', '--repo', $DeployRepoFull, '--head', $C.DeployBranch, '--draft', '--title', 'Move SPN deployment from Azure DevOps', '--body', $body) -NoThrow)
    $pr = ($r | Where-Object { $_ -match '^https://' }) -join ''
  }
  return "pushed module repo and $($C.DeployBranch). $pr"
}

function Phase-verify {
  $remote = @(Invoke-Native git @('ls-remote', '--tags', $ModuleUrl) | Where-Object { $_ -notmatch '\^\{\}$' -and $_ -match 'refs/tags/' })
  $map = @(Import-Csv (Join-Path $Out 'tag-map.csv') | Where-Object { $_.newCommit })
  $missing = @($map | Where-Object { $t = $_.tag; -not ($remote | Where-Object { $_ -match "refs/tags/$([regex]::Escape($t))$" }) })
  $localHead = GitOne $ModuleRepo @('rev-parse', 'main')
  $remoteHead = (@(Invoke-Native git @('ls-remote', $ModuleUrl, 'refs/heads/main')) -join '') -replace '\s.*$', ''
  $r = "remote tags $($remote.Count), mapped $($map.Count), missing $($missing.Count); main " + $(if ($localHead -eq $remoteHead) { 'matches' } else { "DIFFERS (local $localHead, remote $remoteHead)" })
  Write-Host ""
  Write-Host "Next (see README 'After the script'): run out/github-setup.ps1, ask the admin for out/oidc-setup.md step 1, run oidc-test, then check the PR plan shows no changes."
  return $r
}

# ======================================================================== runner
$state = Get-State
$todo = @()
if ($Phase) {
  if ($Phases -notcontains $Phase) { throw "Unknown phase '$Phase'. Phases: $($Phases -join ', ')" }
  $todo = @($Phase)
} else {
  foreach ($p in $Phases) { if (-not $state[$p] -or $state[$p].state -ne 'done') { $todo += $p } }
  if (-not $todo.Count) { Write-Host 'All phases are done. Use -Status, or -Phase <name> -Force to redo one.'; return }
}
foreach ($p in $todo) {
  if ($state[$p] -and $state[$p].state -eq 'done' -and -not $Force) { Write-Host "$p is already done (use -Force to redo)."; continue }
  $idx = [array]::IndexOf($Phases, $p)
  foreach ($prev in ($Phases | Select-Object -First $idx)) {
    if (-not $state[$prev] -or $state[$prev].state -ne 'done') { throw "Phase '$prev' must be done before '$p'." }
  }
  $script:CurrentLog = Join-Path $LogDir "$p.log"
  Write-Host ""
  Write-Host "=== $p ===" -ForegroundColor Cyan
  try {
    $note = & "Phase-$p"
    Set-PhaseState $p 'done' "$note"
    Write-Host "  done: $note" -ForegroundColor Green
  } catch {
    Set-PhaseState $p 'failed' ($_.Exception.Message -split "`n")[0]
    Write-Host "  FAILED: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "  at: $(($_.ScriptStackTrace -split "`n")[0])" -ForegroundColor DarkGray
    Add-Content -Path $script:CurrentLog -Value @("FAILED: $($_.Exception.Message)", $_.ScriptStackTrace)
    Write-Host "  Fix it and run the script again; it resumes at '$p'."
    exit 1
  }
  $state = Get-State
  if (-not $Phase -and $StopAfter -contains $p) {
    Write-Host ""
    Write-Host "Stopped after '$p' so you can check its report in out/. Run the script again to continue." -ForegroundColor Yellow
    break
  }
}
