# Brings both local repos in line with the ADO-aligned kit, then pushes after you type PUSH.
#  1. ADHPlatform/SPN: add CHANGELOG.md + Module CI + Module Release, remove Copilot's spn-validation.yml and scripts/, open a PR
#  2. Deploy repo: regenerate "5- Service Principal - Utility Pipeline" (Sub Group, runnerType) + OIDC files, then push
# Uses gh and git only (no PAT). Run from the kit folder:  .\tools\Fix-SpnRepos.ps1
param([string]$Work = 'C:\repos\mix\ADO-GIT\spn-work', [string]$Branch = 'ci/module-release')
$ErrorActionPreference = 'Stop'
$Kit = Split-Path $PSScriptRoot -Parent
$env:GH_HOST = 'cencora.ghe.com'

Write-Host '== 1. SPN module repo ==' -ForegroundColor Cyan
Push-Location (Join-Path $Work 'SPN')
try {
  git fetch --quiet origin
  if (git branch --list $Branch) { git switch --quiet $Branch } else { git switch --quiet -c $Branch origin/main }
  New-Item -ItemType Directory -Force .github\workflows | Out-Null
  Copy-Item "$Kit\repos\SPN\.github\workflows\*.yml" .github\workflows\ -Force
  if (-not (Test-Path CHANGELOG.md)) { Copy-Item "$Kit\repos\SPN\CHANGELOG.md" . }
  git rm -q -r --ignore-unmatch .github/workflows/spn-validation.yml scripts
  git add -A
  git diff --cached --quiet
  if ($LASTEXITCODE -ne 0) { git commit --quiet -m 'ci: Module CI + Module Release (git tags and CHANGELOG replace the ADO publish pipeline)' }
  git push --quiet -u origin $Branch
  $pr = gh pr list --repo ADHPlatform/SPN --head $Branch --json url --jq '.[0].url'
  if (-not $pr) { $pr = gh pr create --repo ADHPlatform/SPN --base main --head $Branch --fill }
  Write-Host "SPN PR: $pr"
  git switch --quiet main
} finally { Pop-Location }

Write-Host '== 2. Deploy repo workflow ==' -ForegroundColor Cyan
Push-Location $Kit
try {
  foreach ($p in 'workflow', 'oidc') { .\Invoke-SpnMigration.ps1 -Phase $p -Force }
  git -C (Join-Path $Work 'deploy-Custodian_Infrastructure_Deployment_Terraform') status --short
  .\Invoke-SpnMigration.ps1 -Phase push -Force      # shows what it pushes and waits for PUSH
  git -C (Join-Path $Work 'SPN') ls-remote --tags origin
} finally { Pop-Location }
