<#
  Downloads the HashiCorp terraform-mcp-server binary for Windows (no Docker needed) into this tools folder,
  checks its SHA256 against HashiCorp's published sums, and unzips it. Run once:
    Set-ExecutionPolicy -Scope Process Bypass; .\tools\Install-TerraformMcp.ps1
  Needs HTTPS to releases.hashicorp.com (ask for a proxy/allow-list entry if it is blocked, or copy the zip in by hand
  and pass -ZipPath).
#>
param([string]$Version = '1.4.1', [string]$ZipPath = '')
$ErrorActionPreference = 'Stop'
$here = $PSScriptRoot
$name = "terraform-mcp-server_${Version}_windows_amd64.zip"
$base = "https://releases.hashicorp.com/terraform-mcp-server/$Version"
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
if (-not $ZipPath) {
  $ZipPath = Join-Path $here $name
  Invoke-WebRequest -UseBasicParsing "$base/$name" -OutFile $ZipPath
}
$sums = (Invoke-WebRequest -UseBasicParsing "$base/terraform-mcp-server_${Version}_SHA256SUMS").Content
$want = (($sums -split "`n") | Where-Object { $_ -match [regex]::Escape($name) }) -replace '\s.*$', ''
$got = (Get-FileHash $ZipPath -Algorithm SHA256).Hash.ToLower()
if (-not $want -or $got -ne $want.Trim().ToLower()) { throw "SHA256 mismatch for $name (got $got, expected $want). Not installed." }
Expand-Archive $ZipPath -DestinationPath $here -Force
Remove-Item $ZipPath
if (-not (Test-Path (Join-Path $here 'terraform-mcp-server.exe'))) { throw 'terraform-mcp-server.exe not found after unzip.' }
Write-Host "Installed. Restart the 'terraform' server in VS Code (MCP: List Servers)."
