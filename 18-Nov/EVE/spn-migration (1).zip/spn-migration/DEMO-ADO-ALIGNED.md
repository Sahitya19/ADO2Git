# SPN demo: same process as ADO, on GitHub (SBX NonProd)

The process stays the same as in Azure DevOps. Only four things change:

- Git tags plus `CHANGELOG.md` replace Azure Artifacts packages.
- One repo per module replaces `Modules/` in the monorepo.
- The Cencora shared runners replace the ADO self-hosted agents.
- OIDC replaces the service connection secret.

Everything below is done in the browser on cencora.ghe.com, so the gh SSO block doesn't affect it.

## ADO step to GitHub step

| Today in ADO | On GitHub | File |
|---|---|---|
| Change `Modules/SPN` on a branch, PR, module test (`deployTest`) | Change `ADHPlatform/SPN` on a branch, PR, workflow **Module CI** | `repos/SPN/.github/workflows/module-ci.yml` |
| Fill `MODULE_CHANGELOG_TEMPLATE.md` | Add `## [0.0.5] - date` to `CHANGELOG.md` in the same PR | `repos/SPN/CHANGELOG.md` |
| Run **SPN Module Publish pipeline** on `module_publish_prd`, which creates feed package `adh-iac-terraform-spn 0.0.5` | Run **Module Release** on `main` with version `0.0.5`. This creates tag `v0.0.5` and a GitHub Release with the changelog | `repos/SPN/.github/workflows/module-release.yml` |
| Set the version in `CoreInfra/SBX/NonProd/modules_manifest.csv` | Same file, same edit | unchanged |
| Add the SPN entry in `CoreInfra/SBX/NonProd/SPN.tfvars` (`spn = { ... }`) | Same file, same edit | unchanged |
| Run `Pipeline.ServicePrincipal.yaml` by hand, with custodianShortName `SBX` | Run **5- Service Principal - Utility Pipeline** by hand: Select Custodian `SBX`, Deployment Environment `NonProd`, Sub Group `NA`, Runner `CencoraShared` (replaces Agent Pool Type) | `repos/Custodian_Infrastructure_Deployment_Terraform/.github/workflows/ServicePrincipal.yml` |
| A PowerShell step downloads the manifest versions from the feed | Each manifest row is cloned from `ADHPlatform/<Module>` at tag `v<Version>` into `Modules/<Module>` | `.github/actions/terraform-prepare/action.yml` (stands in for `.global/PipelineTemplates`) |
| Service connection, then plan, approval, apply | OIDC, then the **Plan** job, environment approval, then the **Apply** job | same workflow |
| ADO self-hosted agent | Cencora runner, group `cencora`, label `linux-x64-ubuntu-latest` | same workflow |

## Credentials: nothing runs as a person

- **Azure:** OIDC only. GitHub issues a short-lived token for the run, and Entra trusts it through a federated credential on the existing SPN app. There's no client secret, PAT or user login.
- **Module repos:** an org-owned GitHub App token, created for each run (or a repo-owned read-only deploy key during the pilot). No PAT or user token.
- **Module Release:** the built-in `GITHUB_TOKEN` of the SPN repo creates the tag and the release.
- **People** sign in only on their own machine, with gh and az, to run the one-time migration script. Pipelines never use those sign-ins.

## Before the call: one-time setup

**1. Module repo `ADHPlatform/SPN`.**

- Under `.github/workflows`, delete the old workflows that are failing (the red check on e60d447).
- Upload `module-ci.yml` and `module-release.yml` there (Add file > Upload files).
- Upload `CHANGELOG.md` to the repo root.
- Run Actions > **Module Release** with version `0.0.4`. This creates tag `v0.0.4`, the version the SBX manifest uses today.

  Note: this tags the current `main`. Once gh works, the script will map every old version to its exact ADO commit.

**2. Deploy repo `Custodian_Infrastructure_Deployment_Terraform`.**

- If it doesn't exist yet, create it, or ask an owner to.
- Upload these, keeping the same paths:
  - `.github/workflows/ServicePrincipal.yml`
  - `.github/actions/terraform-prepare/action.yml`
  - `Deployments/SPN/*`, from ADO `Modernization_Terraform` branch `module_publish_prd`
  - `CoreInfra/SBX/NonProd/SPN.tfvars` and `CoreInfra/SBX/NonProd/modules_manifest.csv`, from ADO `develop`
- Check that `Deployments/SPN/main.tf` uses `source = "../../Modules/SPN"`.

**3. Environments.** Create `NonProd-plan` and `NonProd` under Settings > Environments.

- Set these once, as repo variables: `AZURE_CLIENT_ID` (the app behind the SPN service connection; per environment if Prod uses another app), `AZURE_TENANT_ID` and `TF_STATE_CONTAINER`. Nobody types anything when they run a workflow.
- The subscription, state resource group and storage account come from `common/terraform.backend_config.csv`, the same file ADO uses, from the row for the chosen custodian and environment (for example `SBX,NonProd`).
- `common/terraform.common.csv` is not copied to GitHub: it holds a plaintext token.
- To show an approval, add yourself as a reviewer on `NonProd`.
- Repo variable `TF_STATE_KEY_PATTERN` is only needed if the state key isn't `{custodian}/{env}/spn.tfstate`.

**4. Module access (no user credentials).** The pipeline has to read the module repos to pull the tagged versions. `GITHUB_TOKEN` can't do this, because it only reads the repo the workflow runs in. Use one of these; neither belongs to a person:

- **Recommended: an org-owned GitHub App.** An org owner, or someone with the App manager role, creates it under the ADHPlatform organization (not under a personal account) and installs it on the module repos.
  - Permission: Repository contents, read-only.
  - Save its app ID as org variable `MODULES_APP_ID` and its private key as org secret `MODULES_APP_KEY`.
  - Each run gets a 1-hour token, and nobody's account is involved.
- **Pilot only: a read-only deploy key.** It belongs to the SPN repo, not to a user, and repo admin is enough.
  - On the VDI, run `ssh-keygen -t ed25519 -f spn_key` and press Enter twice.
  - Add `spn_key.pub` to SPN > Settings > Deploy keys as read-only.
  - Add a deploy repo secret `MODULES_DEPLOY_KEYS` whose value is the line `# repo: SPN` followed by the content of `spn_key`. Add one more `# repo: <Name>` block for each extra module repo.
  - Port 22 from the runner subnet (10.242.132.0/25) to cencora.ghe.com must be open.
  - It needs one key per module repo, so it doesn't scale beyond the pilot.

**5. Other people.**

- **Entra admin:** add 2 federated credentials on the app. Issuer `https://token.actions.cencora.ghe.com`, subjects `repo:ADHPlatform/Custodian_Infrastructure_Deployment_Terraform:environment:NonProd-plan` and `...:environment:NonProd`.
- **Network:** allow 52.242.194.21 on the state storage account and the Key Vault.
- **Org owner:** let the repo use runner group `cencora`.

## Live demo (about 10 minutes)

**1. New module version.**

- In `ADHPlatform/SPN`, edit `CHANGELOG.md`, choose "Create a new branch", and add:
  ```
  ## [0.0.5] - 2026-11-18
  ### Changed
  - Demo: first version published from GitHub.
  ```
- Open the PR. **Module CI** turns green. Merge.

**2. Publish.** Go to Actions > **Module Release** > Run workflow with version `0.0.5`. The tag `v0.0.5` and the release "SPN v0.0.5" appear, with the changelog as the notes. This replaces the ADO publish pipeline and the feed.

**3. Use it in SBX.**

- In the deploy repo, edit `CoreInfra/SBX/NonProd/modules_manifest.csv` and change the SPN row to `0.0.5`.
- Optionally, add one test SPN to `CoreInfra/SBX/NonProd/SPN.tfvars`, copying an existing entry, for example `"ADH_SBX_GHDemo_dev" = { adh_environment = "dev", owners = [...] }`.
- Commit.

**4. Deploy.** Go to Actions > **5- Service Principal - Utility Pipeline** > Run workflow: Select Custodian `SBX`, Deployment Environment `NonProd`, Sub Group `NA`, Runner `CencoraShared`. The run is named `ServicePrincipal-SBX-NonProd`, as in ADO.

- The **Plan** job summary shows `spn | 0.0.5 | v0.0.5 | Modules/SPN`, the state key, and "Plan: 1 to add" (or "No changes").
- **Apply** waits for approval. Approve it, and the test SPN is created.

## If something isn't ready

| Problem | Show this instead |
|---|---|
| OIDC (federated credential) not added yet | Run the pipeline with `planOnly`. It still fails at login, so show the **runner-test** workflow (egress IP 52.242.194.21) and the module table, and explain that login is the open item |
| Runner group not opened | The job stays queued. Show the run page and say this is waiting on the org owner |
| No org-owned app yet and SSH blocked | The clone step fails. Show the module table step and the release; module access is the open item for the org owner |
| Deploy repo can't be created | Show steps 1 and 2 (tag, changelog, release) on `ADHPlatform/SPN` only |

Names to check: the `PipelineName` value used for SPN in `modules_manifest.csv` (the workflow expects `ServicePrincipal`; if it differs, change `PIPELINE_NAME`, or it falls back to the `spn` row), and the SBX folder name.
