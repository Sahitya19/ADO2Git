# START HERE: complete and test the SPN module (SBX NonProd)

The script does the migration work. You use Copilot in VS Code only to read a report or fix one error. Each step below says where to do it:

- **Terminal**: you type the command yourself in the PowerShell panel at the bottom of VS Code. Open it with **View > Terminal** (Ctrl+`). This is where the script runs, and it does the actual work.
- **Copilot**: you ask GitHub Copilot a question in the chat panel. Open it with **View > Chat** (Ctrl+Alt+I), set the mode drop-down to **Ask** and pick a standard model, attach the one file named (paperclip), and paste the prompt. Copilot only explains or suggests; you copy its answer into the file or terminal yourself. Start a new chat each time.

Prompt names refer to `docs/COPILOT-GUIDE.md` (G: …) and `docs/COPILOT-PROMPTS.md` (P1 to P7).

## What to copy to C:\repos\mix\

Copy one file: `spn-migration.zip` goes into `C:\repos\mix\ADO-GIT\`. Everything else is created for you.

```
C:\repos\mix\
└── ADO-GIT\
    ├── spn-migration.zip            <- copy this one file here
    ├── spn-migration\               <- unzipped kit; open this folder in VS Code
    │   ├── START-HERE.md            (this guide)
    │   ├── Invoke-SpnMigration.ps1  (the script)
    │   ├── spn-migration.config.psd1 (settings, already filled for SBX NonProd)
    │   ├── templates\  docs\  tools\
    │   ├── .github\copilot-instructions.md   (keeps Copilot answers short)
    │   ├── .vscode\mcp.json                  (optional ADO / Terraform MCP)
    │   └── out\                     <- created by the script: reports, logs, setup scripts
    └── spn-work\                    <- created by the script: ADO clones, SPN repo, deploy repo
```

Do not copy kit files into your existing repo clones. The script clones what it needs into `spn-work\`.

## Steps

**1. Unzip and open (Terminal).**

```powershell
cd C:\repos\mix\ADO-GIT
Expand-Archive .\spn-migration.zip -DestinationPath . -Force
cd .\spn-migration
Get-ChildItem -Recurse *.ps1 | Unblock-File
code .
```

You should see the kit open in VS Code. Run the rest from the VS Code terminal with `Set-ExecutionPolicy -Scope Process Bypass`.

**2. Sign in (Terminal).** No PAT is needed.

```powershell
gh auth login --hostname cencora.ghe.com --web --git-protocol https
az login
```

You should see `gh auth status --hostname cencora.ghe.com` report "Logged in".

ADHPlatform enforces SAML SSO, so the gh sign-in must also be authorized for SSO once. Run this:

```powershell
gh api --hostname cencora.ghe.com repos/ADHPlatform/SPN --jq .full_name
```

If it prints `ADHPlatform/SPN`, you're done. If it prints "Resource protected by organization SAML enforcement", open the SSO link from that error, complete the sign-in, and run the command again:

```powershell
$r = gh api --hostname cencora.ghe.com repos/ADHPlatform/SPN 2>&1 | Out-String
Start-Process ([regex]::Match(($r -replace '\s',''), 'https://cencora\.ghe\.com/enterprises/[^"\\]+?(?=andtry)').Value)
```

**3. Discover (Terminal).** Run `.\Invoke-SpnMigration.ps1`. It stops after the discover phase.

You should see `out\discovery.md` list `CoreInfra/SBX/NonProd/SPN.tfvars`, its `modules_manifest.csv` row and the backend key.

- If SBX isn't listed, or a value marked CHECK in the config is wrong, use **Copilot G: "Fill the config"** with `out\discovery.md` attached. Paste the lines it gives into the config, then run `-Phase discover -Force`.

**4. Map versions to tags (Terminal).** Run `.\Invoke-SpnMigration.ps1` again. It stops after the tagmap phase.

You should see `out\tag-map.csv` with `0.0.4` and a `newCommit`.

- If any row is empty, use **Copilot G: "Tag map has gaps"** with `tag-map.csv` attached.

**5. Tag, copy and convert (Terminal).** Run `.\Invoke-SpnMigration.ps1`. It stops after the convert phase.

You should see `out\convert-report.md` showing the manifest kept at `0.0.4`, the backend set to `use_oidc`, and tag `v0.0.4` present.

- If anything is left over, use **Copilot G: "Convert left something"**.

**6. Workflows and OIDC files (Terminal).** Run `.\Invoke-SpnMigration.ps1`. It stops at push.

You should see three files in `spn-work\deploy-...\.github\workflows\`: `spn-terraform.yml`, `oidc-test.yml` and `runner-test.yml`.

- **Copilot G: "ADO task not converted"** with `out\pipeline-compare.md` covers any ADO task that wasn't carried over.

**7. Push (Terminal).** Type `PUSH` when the script asks.

You should see the `v0.0.x` tags on `ADHPlatform/SPN`, plus a draft PR "Move SPN deployment from Azure DevOps" in the deploy repo.

**8. GitHub settings (Terminal).** Run `.\out\github-setup.ps1`.

You should see `gh api repos/ADHPlatform/<deploy repo>/environments` list `nonprod` and `prod`.

- **Copilot P7** with `docs\MANUAL-STEPS.md` attached writes the messages for the people who need to act: Entra, the subscription owner, the firewall team and the runner group owner.

**9. Test the runners (Terminal).**

```powershell
gh run list --repo <deploy repo> --workflow runner-test
```

You should see that the `cencora-vnet` job's egress IP is **52.242.194.21** and that storage is "allowed".

**10. Test OIDC (Terminal).**

```powershell
gh run rerun <oidc-test run id> --failed
```

You should see `az account show` print the subscription.

- If it fails, use **Copilot G: "OIDC login fails"** and paste the AADSTS line.

**11. Plan SBX NonProd (Terminal).**

```powershell
gh pr checks <pr> --repo <deploy repo>
```

If the plan ran before step 8, rerun it with `gh run rerun <id> --failed`.

You should see the `checks` job green, and the summary for `plan nonprod CoreInfra/SBX/NonProd/SPN.tfvars` saying **No changes**.

- If it shows changes, use **Copilot G: "Plan shows changes"** and paste the `Plan:` line.

**12. Merge and run from main (Terminal).**

```powershell
gh pr ready <pr>
gh pr merge <pr> --squash
gh workflow run spn-terraform -f environment=nonprod -f tfvars=CoreInfra/SBX/NonProd/SPN.tfvars -f action=apply
```

You should see the plan run on `main`. With no changes, apply is skipped, which is correct.

**13. Release test (Terminal, or Copilot P4).** Tag `v0.0.5` on `SPN`, then open a PR in the deploy repo that sets the SBX NonProd manifest to `0.0.5`. The commands are in `docs\DEMO-RUNBOOK.md` step 10.

You should see the PR plan print "SPN module v0.0.5 for SBX".

## When something fails

The script prints `FAILED`, the last 20 lines, and the log path (`out\logs\<phase>.log`). Use **Copilot G: "A phase failed"** and paste those lines. Apply the fix, then run `.\Invoke-SpnMigration.ps1` again; it resumes where it stopped. To see where you are, run `.\Invoke-SpnMigration.ps1 -Status`.

Never paste tokens, keys or secret values into Copilot.
