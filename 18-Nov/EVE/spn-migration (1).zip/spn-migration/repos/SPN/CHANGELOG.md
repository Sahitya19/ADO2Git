# Changelog

All notable changes to the SPN module. One section per published version, newest first.
Each version is a git tag `vX.Y.Z` (it replaces the feed package `adh-iac-terraform-spn` X.Y.Z).
Add the section in your pull request, then run **Module Release** with the same version.

## [0.0.4] - 2026-10-12

### Changed
- Last version published to ADH-IAC-MODULES from module_publish_prd (build SPN-SBX-NonProd-20261012.1, commit 6816b050). Tagged v0.0.4 during the migration.
