# Called by action.yml. Picks the backend_config.csv row for this run; prints why it picked it.
import csv, os, re, sys

E = os.environ.get
def norm(s): return re.sub(r'[^a-z0-9]', '', (s or '').lower())
ALIASES = {
    'custodian': ['adhgroup', 'custodian', 'custodianshortname', 'custodianname', 'cust', 'shortname', 'custodiancode'],
    'env':       ['env', 'environment', 'deploymentenvironment', 'envtype', 'environmenttype', 'stage'],
    'subgroup':  ['subgroup', 'subgrp', 'group'],
    'pipeline':  ['pipelinename', 'pipeline', 'module', 'modulename', 'component', 'deployment', 'stack'],
    'rg':        ['backendresourcegroupname', 'backendrgname', 'rg', 'resourcegroup', 'resourcegroupname', 'backendazurermresourcegroupname', 'tfstaterg', 'staterg', 'staterresourcegroup'],
    'sa':        ['backendstorageaccountname', 'backendsaname', 'sa', 'storageaccount', 'storageaccountname', 'backendazurermstorageaccountname', 'tfstatesa', 'statesa', 'stateaccount'],
    'container': ['backendcontainername', 'container', 'containername', 'backendazurermcontainername', 'tfstatecontainer', 'statecontainer'],
    'key':       ['backendkey', 'key', 'statekey', 'tfstatekey', 'backendazurermkey', 'statefile', 'statefilename', 'keyname'],
    'kv':        ['keyvault', 'keyvaultname', 'kv', 'kvname', 'vault', 'vaultname'],
    'sub':       ['subscriptionid', 'subscription', 'subid', 'azuresubscriptionid', 'armsubscriptionid', 'backendazurermsubscriptionid', 'statesubscriptionid'],
    'client':    ['clientid', 'azureclientid', 'armclientid', 'appid', 'applicationid', 'spnclientid', 'serviceprincipalid'],
    'tenant':    ['tenantid', 'azuretenantid', 'armtenantid', 'tenant'],
}
ENV_ALIAS = {'nonprod': {'nonprod', 'np', 'nprd', 'nonproduction', 'sbx', 'sandbox', 'dev', 'test', 'tst', 'qa', 'uat'}, 'prod': {'prod', 'prd', 'production', 'p'}}
# ADO backend_config.csv uses long custodian names (sandbox) where the run form uses short ones (SBX). Add pairs here when needed.
CUST_ALIAS = [{'sbx', 'sandbox'}, {'test', 'tst'}]
def cust_ok(v, want):
    a, b = norm(v), norm(want)
    return a == b or any(a in g and b in g for g in CUST_ALIAS)

def out(**kv):
    with open(E('GITHUB_OUTPUT', '/dev/stdout'), 'a') as f:
        for k, v in kv.items(): f.write(f"{k}={v}\n")
def summary(line):
    p = E('GITHUB_STEP_SUMMARY')
    if p:
        with open(p, 'a') as f: f.write(line + '\n')

# first file that exists: common/terraform.backend_config.csv (AdhGroup,environment,backendResourceGroupName,
# backendStorageAccountName,subscriptionId - the file the ADO custodian pipelines use), then .global/backend_config.csv
path = next((f for f in E('FILE', '').split() if os.path.isfile(f)), (E('FILE', '').split() or ['common/terraform.backend_config.csv'])[0])
rows, col = [], {}
if os.path.isfile(path):
    with open(path, newline='', encoding='utf-8-sig') as f:
        rd = csv.DictReader(f)
        hdr = [h for h in (rd.fieldnames or []) if h]
        for want, names in ALIASES.items():
            for h in hdr:
                if norm(h) in names: col[want] = h; break
        rows = [{k: (v or '').strip().strip('"') for k, v in r.items() if k} for r in rd]
    print(f"{path}: {len(rows)} rows; columns found: " + ', '.join(f"{k}={v}" for k, v in col.items()))
else:
    print(f"::warning::{path} not found in the repo; using the TF_STATE_* variables")

def get(r, k): return r.get(col[k], '') if k in col else ''

# .global/global.variables.yml (ADO variables template, same folder): used for values the CSV does not have,
# e.g. the subscription id or state container. Reads "- name: X / value: Y" and "X: Y" forms.
gvars = {}
gpath = os.path.join(os.path.dirname(path) or '.', 'global.variables.yml')
if os.path.isfile(gpath):
    txt = open(gpath, encoding='utf-8-sig').read()
    for m in re.finditer(r'(?m)^\s*-?\s*name:\s*[\'"]?([\w.-]+)[\'"]?\s*\n\s*value:\s*[\'"]?([^\'"\n#]*)', txt): gvars[m.group(1)] = m.group(2).strip()
    for m in re.finditer(r'(?m)^\s+([A-Za-z_][\w.-]*):\s*[\'"]?([^\'"\n#{}\[\]]+?)[\'"]?\s*$', txt):
        if m.group(1) not in ('name', 'value', 'template', 'group'): gvars.setdefault(m.group(1), m.group(2).strip())
def gvar(k):
    hits = [v for n, v in gvars.items() if norm(n) in ALIASES[k] and v and '$(' not in v]
    return hits[0] if hits else ''

if E('MODE') == 'list':
    sas = sorted({get(r, 'sa') for r in rows if get(r, 'sa')} | ({E('FB_SA')} if E('FB_SA') else set()))
    kvs = sorted({get(r, 'kv') for r in rows if get(r, 'kv')} | ({E('FB_KV')} if E('FB_KV') else set()))
    print('storage accounts:', ' '.join(sas) or '-'); print('key vaults:', ' '.join(kvs) or '-')
    out(all_sa=' '.join(sas), all_kv=' '.join(kvs), source=path if rows else 'variables')
    sys.exit(0)

cust, envf = E('CUST', ''), E('ENVF', '')
subg = '' if norm(E('SUBG', '')) in ('', 'na') else E('SUBG', '')
def env_ok(v):
    a, b = norm(v), norm(envf)
    if not b or not a: return True
    if a == b: return True
    return any(a in s and b in s for s in ENV_ALIAS.values())
cand = rows
if 'custodian' in col: cand = [r for r in cand if cust_ok(get(r, 'custodian'), cust)]
if 'env' in col:
    exact = [r for r in cand if norm(get(r, 'env')) == norm(envf)]
    cand = exact or [r for r in cand if env_ok(get(r, 'env'))]
if 'subgroup' in col:  cand = [r for r in cand if norm(get(r, 'subgroup')) in ((norm(subg),) if subg else ('', 'na'))]
if 'pipeline' in col and cand:
    for want in (E('PIPE', ''), E('MODULE', '')):
        hit = [r for r in cand if want and norm(get(r, 'pipeline')) == norm(want)]
        if hit: cand = hit; break
    else:
        blank = [r for r in cand if not get(r, 'pipeline')]
        if blank: cand = blank
row = cand[0] if cand else None
if rows and not row:
    print(f"::warning::No row in {path} for custodian={cust} env={envf} subgroup={subg or 'NA'}; using the TF_STATE_* variables")
if row and len(cand) > 1:
    print(f"::notice::{len(cand)} rows match; using the first: {row}")

def pick(k, fb):
    v = get(row, k) if row else ''
    return v or gvar(k) or E(fb, '')
key = get(row, 'key') if row else ''
if not key:
    key = E('KEY_PATTERN', '').replace('{custodian}', cust).replace('{env}', envf).replace('{subgroup}', subg)
res = dict(rg=pick('rg', 'FB_RG'), sa=pick('sa', 'FB_SA'), container=pick('container', 'FB_CT'), key=key, kv=pick('kv', 'FB_KV'),
           subscription=pick('sub', 'FB_SUB'), client=pick('client', 'FB_CLIENT'), tenant=pick('tenant', 'FB_TENANT'),
           source=(path if row else 'variables'))
for k in ('rg', 'sa', 'container', 'subscription', 'client', 'tenant'):
    if not res[k]: print(f"::warning::{k} is empty (not in {path} and no variable set)")
print(res)
out(**res)
summary(f"Backend from `{res['source']}`: subscription `{res['subscription']}`, state `{res['rg']}` / `{res['sa']}` / `{res['container']}` / key `{res['key']}`" + (f", Key Vault `{res['kv']}`" if res['kv'] else ''))
