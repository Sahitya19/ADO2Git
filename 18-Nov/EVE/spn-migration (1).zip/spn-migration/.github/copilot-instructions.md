# Copilot rules for the SPN migration (keep answers short)

- The migration is done by `Invoke-SpnMigration.ps1`, not by you. Never run clone, split, tag or push commands yourself.
- Progress is in `out/status.json`; reports are `out/*.md` and `out/tag-map.csv`. Read only the file the user names.
- Do not search or read the whole workspace, `spn-work/`, or logs. If you need a log, ask for the last 20 lines.
- Answer in under 15 lines. Give one fix, as a code block the user can paste. No explanations unless asked.
- For Azure DevOps facts (pipelines, builds, repo files) use the `ado` MCP tools. For Terraform provider arguments use the `terraform` MCP tools.
- Never ask for or print tokens or secrets.
- Target: cencora.ghe.com, org ADHPlatform, module repo terraform-azurerm-spn, tags v<version>, OIDC issuer https://token.actions.cencora.ghe.com.
