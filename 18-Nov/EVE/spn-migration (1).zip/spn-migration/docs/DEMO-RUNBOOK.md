# SPN end-to-end demo (SBX NonProd)

This demo moves the SPN module and its pipeline from Azure DevOps to GitHub, then shows them running live. It covers the module repo with version tags, the deploy workflow on the Cencora runners, a pull request that plans, merge, a manual run, and a module release by tag.

Run everything from the VDI in PowerShell. Nothing in Azure DevOps is changed, so the ADO pipeline keeps working throughout.

Each step has three parts:

- **Run**: the commands.
- **Good**: what success looks like.
- **If not ready**: the fallback, so the demo keeps moving.

## 0. Before the call (15 min)

**Run**

```powershell
cd C:\repos\mix\ADO-GIT\spn-migration
gh auth login --hostname cencora.ghe.com --web --git-protocol https   # once; no PAT
gh auth status --hostname cencora.ghe.com
az login
$org  = 'ADHPlatform'
$repo = "$org/Custodian_Infrastructure_Deployment_Terraform"          # DeployRepoName in the config
$env:GH_HOST = 'cencora.ghe.com'                                      # gh commands below then target cencora.ghe.com
```

In `spn-migration.config.psd1`, set the following for the demo, so the PR only plans SBX NonProd and never waits on a prod approval. These values are already set in the kit's config:

```powershell
PrPlanInclude = @('CoreInfra/SBX/NonProd/**')
DefaultTfvars = 'CoreInfra/SBX/NonProd/SPN.tfvars'
```

**CHECK:** the folder name `SBX` is a guess from the feed build name `SPN-SBX-NonProd`. Run `git -C C:\repos\mix\ADO-GIT\spn-work\src-pipelines ls-tree -d --name-only HEAD CoreInfra/` after step 2, or look in ADO. If the folder is named differently, change both lines and every `CoreInfra/SBX/NonProd` below.

Then check which of the other people's steps are done (`docs/MANUAL-STEPS.md` rows 4, 6, 7 and 8). These are the federated credential, the Storage Blob role, the 52.242.194.21 allowlist and the runner group.

**Good:** `gh auth status` shows you logged in to cencora.ghe.com, and `az account show` shows the subscription.

**If not ready:** if rows 4, 6 or 7 are open, plan to demo steps 1 to 6 and the `checks` job. Show steps 7 to 10 as "next, once access lands".

## 1. Architecture (2 min)

**Run:** open `docs\CALL-BRIEF.pdf`. Page 1 is ADO today for SPN, page 2 the GitHub target, page 3 the whole platform side by side (all modules and custodians, promotion NonProd to Prod), page 4 who does what.

**Good:** the audience sees the same two-repo split. Feed versions become tags, the service connection becomes OIDC, and ADO agents become Cencora runners.

## 2. Discover and map versions to tags (5 min)

**Run**

```powershell
.\Invoke-SpnMigration.ps1            # stops after discover
notepad .\out\discovery.md
.\Invoke-SpnMigration.ps1            # stops after tagmap
Import-Csv .\out\tag-map.csv | Format-Table version, sourceCommit, newCommit, note
```

**Good:** `discovery.md` lists `CoreInfra/SBX/NonProd/SPN.tfvars`, its `modules_manifest.csv` row and the backend key. `tag-map.csv` maps `0.0.4` to a commit in `ADHPlatform/SPN`.

**If not ready:** if the feed call fails (no feed access through `az login`), write `versions.csv` with the header `version,sourceCommit` and the row `0.0.4,6816b050...`. Then set `VersionSource = 'csv'` and `VersionsCsv = '.\versions.csv'` and run `.\Invoke-SpnMigration.ps1 -Phase tagmap -Force`.

## 3. Convert and write the workflows (2 min)

**Run**

```powershell
.\Invoke-SpnMigration.ps1            # tags, copy, convert; stops after convert
notepad .\out\convert-report.md
.\Invoke-SpnMigration.ps1            # workflow, validate, oidc; stops at push
```

**Good:**

- `convert-report.md` shows that the manifest keeps `0.0.4`, the backend gets `use_oidc`, and tag `v0.0.4` exists.
- `spn-work\deploy-...\.github\workflows\` contains `spn-terraform.yml`, `oidc-test.yml` and `runner-test.yml`.

## 4. Push: module tags, deploy branch, draft PR (3 min)

**Run:** at the prompt, type `PUSH`.

```powershell
git ls-remote --tags https://cencora.ghe.com/ADHPlatform/SPN.git
gh pr list --repo $repo
```

**Good:** the `v0.0.x` tags are on `ADHPlatform/SPN`, and there is a draft PR "Move SPN deployment from Azure DevOps". The PR starts `checks`, `runner-test` and `oidc-test` right away.

**If not ready:** if creating the deploy repo is refused, an owner has to create it empty (row 1). Meanwhile push only the tags with `git -C C:\repos\mix\ADO-GIT\spn-work\SPN push origin --tags`, and demo steps 6 and 10 on the module repo.

## 5. Environments, variables, deploy key (2 min)

**Run**

```powershell
.\out\github-setup.ps1
gh api "repos/$repo/environments" --jq '.environments[].name'
gh variable list --repo $repo --env nonprod
```

Then open Settings > Environments > prod > Required reviewers in the browser and add the approvers.

**Good:** the environments `nonprod` and `prod` exist, with `AZURE_*` and `TF_STATE_*` set and the deploy key `MODULES_DEPLOY_KEY` present.

## 6. Runners: connectivity test (no OIDC needed) (3 min)

**Run**

```powershell
gh run list --repo $repo --workflow runner-test --limit 1
gh run view <run id> --repo $repo --log | Select-String 'Egress IP|open|BLOCKED|firewall'
```

**Good:**

- The `cencora-vnet` job shows egress IP **52.242.194.21**, `cencora.ghe.com:22 open`, the storage account on 443 open, and "Storage firewall: this IP is allowed".
- The `standard` job shows a different IP. This is why Azure jobs need the VNET runner.

**If not ready:**

- If the `cencora-vnet` job stays queued, the deploy repo is not in runner group `cencora` (row 8). Show the `standard` job and say this is the open item.
- If the job says "NOT allowed", the firewall request (row 7) is still open.

## 7. OIDC sign-in (2 min)

**Run**

```powershell
gh run list --repo $repo --workflow oidc-test --limit 1
gh run view <run id> --repo $repo --log | Select-String 'subscription|AADSTS|Storage'
```

The run started in step 4, before step 5 set the variables. If it failed, rerun it with `gh run rerun <run id> --repo $repo --failed`.

**Good:** `az account show` prints the subscription and the state blobs are listed. Azure was reached with no secret stored anywhere.

**If not ready:**

- `AADSTS70021` or `AADSTS700213`: the federated credential is missing or its subject is wrong (row 4). Show `out\fic-nonprod.json` and explain.
- "Cannot list state blobs": the Storage Blob role is missing (row 6).

## 8. Pull request plan: SBX NonProd (5 min)

**Run**

```powershell
gh pr checks --repo $repo
gh run rerun <spn-terraform run id> --repo $repo --failed      # if it ran before step 5
```

Open the PR, then Checks > spn-terraform > Summary.

**Good:**

- `checks` (fmt and validate) is green on ubuntu-latest.
- `plan nonprod CoreInfra/SBX/NonProd/SPN.tfvars` runs on the Cencora runner, prints "SPN module v0.0.x for SBX", and the summary says **No changes**. GitHub is using the same state as ADO.

**If not ready:**

- If OIDC or the firewall is pending, show the green `checks` job only.
- "Plan has CHANGES" usually means the state key is wrong. Compare the "State key" line in the summary with `backend_config.csv`, fix `StateKeyPattern`, then run `.\Invoke-SpnMigration.ps1 -Phase workflow -Force`, then `-Phase push -Force`.

## 9. Merge, then run from main (3 min)

**Run**

```powershell
gh pr ready <pr number> --repo $repo
gh pr merge <pr number> --repo $repo --squash --delete-branch
gh workflow run spn-terraform --repo $repo -f environment=nonprod -f tfvars=CoreInfra/SBX/NonProd/SPN.tfvars -f action=apply
gh run watch --repo $repo
```

**Good:** the plan runs on `main`. If it says No changes, the `apply` job is skipped, which is correct because there is nothing to apply. If there are changes, `apply` applies the reviewed plan file. For prod it waits for a reviewer.

**If not ready:** if merging to `main` is blocked by a ruleset, a reviewer approves the PR. Until then the PR plan from step 8 is the demo of the pipeline.

## 10. Module release by tag (git workflow) (5 min)

**Run**

```powershell
cd C:\repos\mix\ADO-GIT\spn-work\SPN
git switch -c demo/readme ; Add-Content README.md "`nDemo change." ; git commit -am "docs: demo change" ; git push -u origin demo/readme
gh pr create --repo $org/SPN --fill ; gh pr merge --repo $org/SPN --squash --delete-branch
git switch main ; git pull ; git tag -a v0.0.5 -m "SPN 0.0.5" ; git push origin v0.0.5
```

Then, in the deploy repo, make a PR that changes `CoreInfra/SBX/NonProd/modules_manifest.csv` from `0.0.4` to `0.0.5`.

**Good:** that PR's plan shows "SPN module v0.0.5 for SBX". This replaces the ADO publish pipeline and the feed: the tag is the release, and the manifest pins it per custodian.

**If not ready:** the `ADHPlatform/SPN` repo still has a failing check on its last commit (e60d447). Show the run with `gh run list --repo $org/SPN --limit 3` and `gh run view <id> --repo $org/SPN --log-failed`. Explain that it gets fixed before the first real release.

## Wrap-up (1 min)

Open `docs\MANUAL-STEPS.md` and name the open rows, their owners and the dates. After the first GitHub apply in each environment, an ADO admin disables the ADO SPN pipeline (row 11).
