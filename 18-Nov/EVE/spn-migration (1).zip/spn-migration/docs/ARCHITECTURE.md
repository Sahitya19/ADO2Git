# Terraform delivery: Azure DevOps today, GitHub target

The GitHub setup keeps the same two-repo split and the same per-custodian manifest. What changes is how module versions are stored (git tags in place of feed artifacts), how pipelines sign in to Azure (OIDC in place of a service connection secret), and where jobs run (Cencora VNET runners).

## Today: Azure DevOps (dev.azure.com/AnalyticsDataHub/Platform)

```mermaid
flowchart LR
  subgraph MT["Repo: Modernization_Terraform"]
    MOD["Modules/SPN<br/>Modules/&lt;other modules&gt;"]
    DEP["Deployments/SPN<br/>source = ../../Modules/SPN"]
    GLB[".global<br/>backend_config.csv<br/>global.variables.yml<br/>PipelineLibrary, PipelineTemplates"]
  end
  PUB["Module publish pipeline<br/>branch module_publish_prd"]
  FEED[("Azure Artifacts feed<br/>ADH-IAC-MODULES<br/>adh-iac-terraform-spn 0.0.x")]
  subgraph CID["Repo: Custodian_Infrastructure_Deployment_Terraform (develop)"]
    TFV["CoreInfra/&lt;custodian&gt;/&lt;NonProd|Prod&gt;lt;NonProd or Prod&lt;NonProd|Prod&gt;gt;/<br/>SPN.tfvars<br/>modules_manifest.csv"]
    YML[".azure-pipelines/<br/>Pipeline.ServicePrincipal.yaml<br/>parameter custodianShortName"]
  end
  SC["Service connection<br/>(app registration + secret)"]
  AG["ADO agents"]
  AZ[("Azure<br/>tfstate storage, Key Vault,<br/>Entra app registrations")]

  MOD --> PUB --> FEED
  YML -- "uses templates" --> GLB
  YML -- "reads version" --> TFV
  FEED -- "download artifact into Modules/SPN" --> AG
  DEP --> AG
  YML --> AG
  AG -- "init / plan / apply" --> SC --> AZ
```

## Target: GitHub (cencora.ghe.com, org ADHPlatform)

```mermaid
flowchart LR
  subgraph MR["Repo: SPN (one repo per module)"]
    MODG["module code<br/>history kept<br/>tags v0.0.1 ... v0.0.4"]
    CI["ci.yml: fmt + validate<br/>runs-on ubuntu-latest"]
  end
  subgraph DR["Repo: Custodian_Infrastructure_Deployment_Terraform"]
    TFVG["CoreInfra/&lt;custodian&gt;/&lt;NonProd|Prod&gt;lt;NonProd or Prod&lt;NonProd|Prod&gt;gt;/<br/>SPN.tfvars<br/>modules_manifest.csv (same versions)"]
    DEPG["Deployments/SPN"]
    WF[".github/workflows/spn-terraform.yml<br/>checks, plan, apply<br/>(reusable workflows later replace PipelineTemplates)"]
  end
  ENV["GitHub environments nonprod / prod<br/>variables AZURE_*, TF_STATE_*<br/>required reviewers on prod"]
  PUBR["ubuntu-latest<br/>checks job (no Azure)"]
  VNET["Cencora VNET runners<br/>group cencora, linux-x64-ubuntu-latest<br/>egress 52.242.194.21"]
  OIDC["OIDC federated credential<br/>repo:ADHPlatform/&lt;repo&gt;:environment:&lt;env&gt;<br/>no secret"]
  AZG[("Azure<br/>tfstate storage, Key Vault,<br/>Entra app registrations<br/>firewall allows 52.242.194.21")]

  WF --> PUBR
  WF --> VNET
  VNET -- "reads version from manifest,<br/>clones SPN at tag vX<br/>(read-only deploy key)" --> MODG
  TFVG --> VNET
  DEPG --> VNET
  ENV --> VNET
  VNET -- "init / plan / apply" --> OIDC --> AZG
```

## What maps to what

| Azure DevOps today | GitHub target | Notes |
|---|---|---|
| `Modernization_Terraform` monorepo, `Modules/SPN` | Repo `ADHPlatform/SPN` | One repo per module. History of `Modules/SPN` kept |
| Feed `ADH-IAC-MODULES`, package `adh-iac-terraform-spn` 0.0.x | Git tags `v0.0.x` on `SPN` | Each tag sits on the commit the artifact was built from (`out/tag-map.csv`) |
| Module publish pipeline (`module_publish_prd`) | Pushing a tag `vX.Y.Z` | No package to build or upload |
| `modules_manifest.csv` per custodian and environment | Same file, same versions | Workflow reads it and clones the module at `v<version>` |
| Artifact download into `Modules/SPN` | `git clone --branch v<version>` into `Modules/SPN` | `Deployments/SPN` keeps its local `source` |
| `Deployments/SPN` | Same folder in the deploy repo | Unchanged code |
| `CoreInfra/<custodian>/<env>/SPN.tfvars` | Same paths | Unchanged |
| `Pipeline.ServicePrincipal.yaml`, parameter `custodianShortName` | `spn-terraform.yml`, input `tfvars` (the path names the custodian) | PRs plan each tfvars file in scope |
| `.global/PipelineTemplates`, `PipelineLibrary` | Reusable workflows in a shared repo | Later step, once a second module moves |
| `.global/backend_config.csv` | Variables `TF_STATE_RG`, `TF_STATE_SA`, `TF_STATE_CONTAINER` and the state key pattern | Same state file, so the first plan must say **No changes** |
| `global.variables.yml`, variable groups | Environment variables and secrets | Values are recreated by hand |
| Service connection (app registration + secret) | Same app registration, federated credential per environment | No client secret stored in GitHub |
| ADO agents | Cencora VNET runners for Azure work, `ubuntu-latest` for checks | VNET egress IP is allowed on state storage and Key Vault |
| Stage approvals / checks | Environment required reviewers on `prod` | Apply only from `main` |

## Platform-wide: all modules and custodians

The SPN diagrams above are one slice. The same pattern repeats for every module and every custodian.

### Today: Azure DevOps

```mermaid
flowchart TB
  subgraph MT["Modernization_Terraform (monorepo)"]
    M["Modules/<br/>SPN, KeyVault, Storage, ... (all modules)"]
    D["Deployments/<br/>one root per module"]
    G[".global<br/>PipelineTemplates, PipelineLibrary<br/>backend_config.csv, global.variables.yml"]
  end
  PUB["Publish pipeline per module<br/>branch module_publish_prd"]
  FEED[("Feed ADH-IAC-MODULES<br/>adh-iac-terraform-&lt;module&gt; x.y.z")]
  subgraph CID["Custodian_Infrastructure_Deployment_Terraform"]
    C["CoreInfra/&lt;custodian&gt; (AHP, SBX, ...)<br/>NonProd / Prod<br/>&lt;Module&gt;.tfvars + modules_manifest.csv"]
    P[".azure-pipelines/Pipeline.&lt;Module&gt;.yaml<br/>parameter custodianShortName"]
  end
  VG["Variable groups<br/>service connections (secret)"]
  AG["ADO agents"]
  NP[("Azure NonProd")]
  PR[("Azure Prod")]
  M --> PUB --> FEED
  P -- "extends templates" --> G
  C -- "version pin + tfvars" --> P
  FEED -- "artifact download" --> AG
  D --> AG
  P --> AG
  VG --> AG
  AG -- "NonProd run" --> NP
  AG -- "Prod run after approval" --> PR
```

### Target: GitHub

```mermaid
flowchart TB
  subgraph MRS["Module repos: one per module"]
    MR["ADHPlatform/SPN, /KeyVault, /Storage, ...<br/>tags vX.Y.Z = releases<br/>CI fmt + validate on ubuntu-latest"]
  end
  subgraph PW["ADHPlatform/platform-workflows"]
    RW["Reusable workflows<br/>terraform plan / apply<br/>(replace PipelineTemplates)"]
  end
  subgraph DR["Custodian_Infrastructure_Deployment_Terraform"]
    C2["CoreInfra/&lt;custodian&gt;/NonProd, Prod<br/>&lt;Module&gt;.tfvars + modules_manifest.csv (vX.Y.Z)"]
    D2["Deployments/&lt;module&gt;"]
    W2[".github/workflows/&lt;module&gt;-terraform.yml<br/>thin callers, PR = plan"]
  end
  RUN["Cencora VNET runners<br/>group cencora, egress 52.242.194.21"]
  ENVN["Environment nonprod<br/>OIDC ...:environment:nonprod"]
  ENVP["Environment prod<br/>required reviewers<br/>OIDC ...:environment:prod"]
  NP2[("Azure NonProd")]
  PR2[("Azure Prod")]
  C2 --> W2
  D2 --> W2
  W2 -- "uses @sha" --> RW
  RW --> RUN
  MR -- "clone tag from manifest" --> RUN
  RUN --> ENVN --> NP2
  RUN --> ENVP --> PR2
  ENVN -. "promote: PR sets the Prod manifest<br/>to the tag proven in NonProd" .-> ENVP
```

### Platform mapping

| Azure DevOps today | GitHub target |
|---|---|
| One monorepo, all modules | One repo per module (`ADHPlatform/<Module>`), history kept, moved one at a time with the same script |
| Publish pipeline per module, feed `ADH-IAC-MODULES` | A `vX.Y.Z` tag on the module repo is the release |
| `.global/PipelineTemplates`, `PipelineLibrary` | `ADHPlatform/platform-workflows` reusable workflows, called by SHA |
| `Pipeline.<Module>.yaml` per module, custodian as a parameter | `<module>-terraform.yml` per module. The custodian comes from the tfvars path; a PR plans every changed custodian |
| `modules_manifest.csv` per custodian and environment | Same file, versions are git tags |
| Promotion: run the Prod stage | A PR that sets the Prod manifest to the tag already applied in NonProd, then apply with prod reviewers |
| Service connection per environment (secret) | OIDC federated credential per GitHub environment (no secret) |
| Variable groups | Environment variables and secrets; org variables for shared values |
| ADO agents | Cencora VNET runners for Azure work, `ubuntu-latest` for checks |
