# SPN module migration flow (one page)

GitHub and VS Code render these Mermaid diagrams directly. Names in `<...>` are from `spn-migration.config.psd1`.

## 1. What moves where

```mermaid
flowchart LR
  subgraph ADO["Azure DevOps: AnalyticsDataHub / Platform"]
    M["Modules monorepo<br/>modules/spn + other modules"]
    P["Pipelines repo<br/>SPN tfvars, root .tf, manifest, pipeline YAML"]
    F["Azure Artifacts feed<br/>spn 1.0.0, 1.1.0, 1.2.0"]
    SC["Service connection<br/>(app registration + secret)"]
    VG["Variable groups<br/>(values re-entered, not exported)"]
  end
  subgraph GH["GitHub: cencora.ghe.com / ADHPlatform"]
    MR["terraform-azurerm-spn<br/>module code with history"]
    T["Tags v1.0.0, v1.1.0, v1.2.0<br/>on the matching commits"]
    DR["DeployRepoName branch migrate/spn<br/>deployments/spn: tfvars, root .tf, manifest"]
    WF["spn-terraform.yml<br/>plan on PR, apply on approval"]
    EV["Environments dev / test / prod<br/>variables + reviewers"]
  end
  AZ["Entra ID + Azure<br/>federated credential per environment"]

  M -- "split with history" --> MR
  F -- "version -> build -> commit" --> T
  MR --- T
  P -- "copy SPN files" --> DR
  P -- "pipeline YAML converted" --> WF
  SC -- "same app, secret replaced by OIDC" --> AZ
  VG --> EV
  DR -- "source = git::...?ref=v1.1.0" --> T
  WF -- "OIDC token, no secret" --> AZ
  EV --- WF
```

## 2. Artifacts become tags

```mermaid
flowchart TD
  A["Feed package spn 1.1.0"] --> B["Provenance: built by ADO build 4711"]
  B --> C["Build 4711 sourceVersion = commit abc123<br/>in the monorepo (may only touch other modules)"]
  C --> D["Last commit at or before abc123 that changed modules/spn<br/>git rev-list -1 abc123 -- modules/spn"]
  D --> E{"Split method"}
  E -- "git filter-repo" --> F["commit-map: old -> new<br/>(0000 = commit was dropped, which is why step D is needed)"]
  E -- "git subtree (Portable Git)" --> G["find the new commit whose files<br/>equal modules/spn at abc123 (tree match)"]
  F --> H["check: files identical (tree match)"]
  G --> I["out/tag-map.csv<br/>you review it"]
  H --> I
  I --> J["git tag -a v1.1.0 new commit"]
  J --> K["Consumers: source = git::https://cencora.ghe.com/ADHPlatform/terraform-azurerm-spn.git?ref=v1.1.0<br/>manifest line 'spn': '1.1.0' gets the same git ref"]
```

A version gets no tag when its build was deleted by retention (fill `sourceCommit` by hand), when it was built from a branch that never reached main, or when the version is not semver. The report says which.

## 3. The new workflow

```mermaid
flowchart LR
  PR["Pull request on migrate/spn"] --> PL["plan job, environment dev<br/>azure/login OIDC (az CLI fallback)<br/>init with use_oidc + Entra state auth<br/>fmt, validate, plan -detailed-exitcode"]
  PL --> S["Run summary: 'No changes' expected<br/>against the existing ADO state"]
  WD["Manual run: environment + tfvars + action=apply<br/>(from main)"] --> PL2["plan job in that environment<br/>saves the plan for 1 day"]
  PL2 --> AP{"Plan has changes?"}
  AP -- no --> END["Nothing to apply"]
  AP -- yes --> RV["Environment reviewers approve<br/>(test, prod)"]
  RV --> AJ["apply job: applies the saved plan"]
  REL["Module change merged in terraform-azurerm-spn"] --> NT["New tag v1.3.0"] --> UP["PR in deploy repo bumps ?ref=v1.3.0"]
```

## 4. Script phases (Invoke-SpnMigration.ps1)

```mermaid
flowchart LR
  pre[preflight] --> dis["discover<br/>stop: fill config"] --> spl[split] --> tm["tagmap<br/>stop: review CSV"] --> tg[tags] --> mf[modulefiles] --> dc[deploycopy] --> cv["convert<br/>stop: review report"] --> wf[workflow] --> va[validate] --> oi[oidc] --> pu["push<br/>type PUSH"] --> ve[verify]
```

Every phase writes to `out/status.json`; running the script again resumes at the first phase that is not done. Nothing is pushed and nothing in Azure DevOps changes before `push`.
