# Steps the script cannot do

Harsha has repo-level rights in ADHPlatform. These need someone else. Send each person their row.

| # | Who | What | When | Ready-made input |
|---|---|---|---|---|
| 1 | GitHub org owner | Create **empty** repos `ADHPlatform/terraform-azurerm-spn` and the deploy repo (no README), give Harsha admin | before `push` (only if `gh repo create` fails) | names in the config |
| 2 | GitHub org owner | Actions policy allows `actions/*`, `azure/login`, `hashicorp/setup-terraform` | before the first PR plan | the workflow files |
| 3 | GitHub org owner (or App manager role) | Create an **org-owned** GitHub App (owner: ADHPlatform, not a personal account), with Repository contents: read-only, installed on the module repos. Save the app ID as org variable `MODULES_APP_ID` and the private key as org secret `MODULES_APP_KEY`, available to the deploy repo. The pipelines then read the modules without any user credential. Until then, the pilot uses repo-owned read-only deploy keys (secret `MODULES_DEPLOY_KEYS`), which need **port 22 open from the runner subnet 10.242.132.0/25 to cencora.ghe.com** | before the first plan (pilot can start with the deploy key) | `repos/Custodian_Infrastructure_Deployment_Terraform/.github/actions/terraform-prepare/action.yml` |
| 4 | Entra admin or owner of the app registration behind the ADO service connection | Add one federated credential per environment | before the first PR plan | `out/oidc-setup.md` step 1 and `out/fic-<env>.json` |
| 5 | Entra admin | Confirm the same app keeps its Microsoft Graph permissions (an SPN module creates app registrations, e.g. `Application.ReadWrite.OwnedBy`) | with 4 | service connection name in the config |
| 6 | Azure subscription owner | **Storage Blob Data Contributor** for that app on the Terraform state storage account (Entra auth to state, no keys) | with 4 | state account from `out/discovery.md` |
| 7 | Network / storage owner (ServiceNow "Firewall rule request" if the path is not open yet) | Allow the Cencora VNET runner egress IP **52.242.194.21** on the Terraform state storage account and on any Key Vault the SPN deployment reads. For internal targets the runner subnet is **10.242.132.0/25** | before the first PR plan | state account from `out/discovery.md`; Key Vault names from the tfvars |
| 8 | GitHub org owner | Let the deploy repo use the org runner group **cencora** (Settings > Actions > Runner groups > Repository access) | before the first PR plan | deploy repo name in the config |
| 9 | Copilot admin | Enable the **MCP servers in Copilot** policy | only for MCP | `docs/COPILOT-GUIDE.md` |
| 10 | Network team | Allow `registry.npmjs.org`, `releases.hashicorp.com`, `registry.terraform.io` from the VDI | only for MCP | same |
| 11 | ADO project admin | After cutover: disable the ADO SPN pipeline and deny Contribute on `modules/spn` | after the first GitHub apply | - |

## Harsha's own steps (repo admin is enough)

1. `out/github-setup.ps1`: environments, `AZURE_*` and `TF_STATE_*` variables, read-only deploy key in secret `MODULES_DEPLOY_KEYS` (all through gh, no PAT).
2. Required reviewers on `test` and `prod` (Settings > Environments).
3. Recreate the variable-group values listed in `out/pipeline-compare.md` (values cannot be exported from ADO).
4. Open the draft PR, check the plan summary says **No changes** for each tfvars file, then mark it ready and merge.
5. After merge, run `oidc-test` once per environment, then the first `apply` from `main`.
