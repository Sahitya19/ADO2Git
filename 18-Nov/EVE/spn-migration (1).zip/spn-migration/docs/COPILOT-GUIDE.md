# Using Copilot for the SPN migration (minimal tokens)

The script does the migration. Copilot is only for small questions. Rules that keep the cost down:

1. **Ask mode** (not Agent) for anything about a script, YAML or error. Ask mode does not read files or run commands on its own.
2. **New chat per question.** Old history is resent with every message.
3. **Attach one file or paste the 20 lines that matter.** Never `#codebase` or `@workspace`.
4. **Pick a standard model**, not a premium one. None of these questions need it.
5. **Agent mode only for MCP lookups**, with the tool picker set to just the `ado` or `terraform` tools (untick the built-in file, search and terminal tools).

## Prompts (copy, fill the `<...>`, paste)

Ask mode, nothing attached unless stated:

| When | Prompt |
|---|---|
| A phase failed | `Invoke-SpnMigration.ps1 phase <name> failed with this error. Give the one fix, max 10 lines:` then paste the FAILED line and the tail it shows |
| Tag map has gaps | Attach `out/tag-map.csv`. `Which rows have no newCommit and what should I put in sourceCommit for each? Table only.` |
| Fill the config | Attach `out/discovery.md`. `Give me the values for PipelinesInclude, ManifestPath, AdoPipelineYamlPath, DeployStyle, StateKeyPattern. Psd1 lines only.` |
| Convert left something | Attach `out/convert-report.md`. `For each line under "Artifact references still left", give the replacement line. Code only.` |
| ADO task not converted | Attach `out/pipeline-compare.md`. `Write the GitHub Actions step for each NOT CONVERTED task. YAML only.` |
| Plan shows changes | Paste the `Plan:` line and the first changed resource block. `Why would this differ after moving from ADO to GitHub with the same state? Most likely cause only.` |
| OIDC login fails | Paste the AADSTS line. `What is wrong with the federated credential? One line fix.` |

Agent mode, only `ado` tools ticked:

| When | Prompt |
|---|---|
| Find the SPN pipeline id | `List pipelines in project Platform whose name contains spn, with their definition id. Table only.` |
| Find the build for a version | `For pipeline <name>, list succeeded builds with buildNumber and sourceVersion, newest 20. Table only.` |
| Find the SPN pipeline YAML | `In repo <pipelines repo>, which YAML files under pipelines/ mention spn? Paths only.` |

Agent mode, only `terraform` tools ticked:

| When | Prompt |
|---|---|
| Provider argument | `In the azuread provider, which arguments does azuread_application_federated_identity_credential take? Table only.` |

## MCP setup (answers "how do I add Azure DevOps and Terraform MCP")

`.vscode/mcp.json` in this kit has both servers. Open the kit folder (or copy the file into `C:\repos\mix\ADO-GIT\.vscode\`), then run **MCP: List Servers** and start `ado` and `terraform`.

**Prerequisites**

| Need | Why | Who |
|---|---|---|
| Copilot policy **"MCP servers in Copilot"** enabled for your Copilot Business/Enterprise seat | Off by default for organisations; without it the servers do not start | Copilot admin (enterprise or org owner) |
| VS Code 1.99 or newer, Copilot Chat extension | MCP support | you |
| Node.js 20+ (`node -v`) | `npx` runs `@azure-devops/mcp` | you (portable zip works without admin) |
| Network: `registry.npmjs.org` (or your npm mirror via `npm config set registry`), `dev.azure.com`, `login.microsoftonline.com` | download and sign-in for the ADO server | network team if blocked |
| Network: `releases.hashicorp.com` once, `registry.terraform.io` at use | binary download and registry docs | network team if blocked |
| `tools\Install-TerraformMcp.ps1` run once | puts `terraform-mcp-server.exe` in `tools\` (checks its SHA256); no Docker needed | you |
| Behind a proxy: add `"HTTPS_PROXY": "http://<proxy>:<port>"` to each server's `env` | servers do not read VS Code's proxy setting | you |

**How MCP saves tokens.** Without MCP the agent learns facts by reading files and terminal output: a `git log`, a 300-line pipeline YAML or a JSON API dump goes into the context in full, and stays there for every later message. An MCP tool returns only the answer (for example 20 build numbers and commits), so the context stays small. Two limits: every enabled tool's description is sent with each agent request, which is why `mcp.json` loads only the `core`, `repositories` and `pipelines` domains and the `registry` toolset, and you should untick tools you do not need; and a tool result still costs tokens, so ask for "names only" or "table only".

The ADO MCP server has no Azure Artifacts domain, so feed versions still come from the script (`VersionSource = feed`).
